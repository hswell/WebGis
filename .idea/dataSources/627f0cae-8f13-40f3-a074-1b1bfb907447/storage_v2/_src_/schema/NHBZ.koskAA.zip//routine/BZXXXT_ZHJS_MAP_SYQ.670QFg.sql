create PROCEDURE      BZXXXT_ZHJS_MAP_SYQ(VSTNM    VARCHAR2,
                                                VTYPE    int,
                                                BGDATE   VARCHAR2,
                                                ENDDATE  VARCHAR2,
                                                VCODE     varchar2,
                                                ISWARING VARCHAR2,
                                                GRADE    VARCHAR2,

                                                VSTNMHD VARCHAR2,

                                                minx     number,
                                                miny     number,
                                                maxx     number,
                                                maxy     number,
                                                Vmaxscale number,
                                                VMAPTYPE VARCHAR2,
                                                CURR     OUT PLATFORM.CURSOR,
                                                CURR1     OUT PLATFORM.CURSOR,
                                                CURR2     OUT PLATFORM.CURSOR) IS

  RED VARCHAR(10);

  ORANGE VARCHAR(10);
  NORMAL VARCHAR(10);
  RANGE  numeric(5, 1);
  Tminx  numeric(18, 9);
  Tminy  numeric(18, 9);
  Tmaxx  numeric(18, 9);
  Tmaxy  numeric(18, 9);
BEGIN

  begin
    SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR
      INTO RED, ORANGE, RANGE, NORMAL
      FROM DSE_WARNING_PARAM;
    --雨量站测报的水库水情实时信息
    --ISWARING 用于判断是否报警，''所有，1报警，0非报警。

    Tminx := minx;
    Tmaxx := maxx;
    Tminy := miny;
    Tmaxy := maxy;

    --查询雨量数据
    IF VTYPE <> 0 THEN
      OPEN CURR FOR
        select ttttt.*
          from (SELECT ttt.*,
                       case
                         when DRP <= 10 then
                          'A'
                         when DRP > 10 and DRP <= 25 then
                          'B'
                         when DRP > 25 and DRP <= 50 then
                          'C'
                         when DRP > 50 and DRP <= 100 then
                          'D'
                         when DRP > 100 and DRP <= 250 then
                          'E'
                         when DRP > 250 then
                          'F'
                         else
                          'A'
                       end DRPGRADE
                  FROM (SELECT NVL(T2.STNM, T2.STCD) STNM,
                               TO_CHAR(getadnm(T2.ADDVCD)) ADNM,
                               T2.ADDVCD,
                               T2.STCD,
                               'PP' STTP,
                               case
                                 when VMAPTYPE = '2' then
                                  func_gis_lonmercator(T2.LGTD)
                                 else
                                  T2.LGTD
                               end LGTD,
                               case
                                 when VMAPTYPE = '2' then
                                  func_gis_latmercator(T2.LTTD)
                                 else
                                  T2.LTTD
                               end LTTD,
                               T4.MAXSCALE,
                               T4.MINSCALE,
                               T4.VIFL,
                               t4.showlabelscale SHOWLABELSCALE,

                               TO_CHAR(MAX(T1.TM), 'yyyy-mm-dd hh24:mi') TM,

                               case
                                 when ROUND(SUM(DRP)) is not null then
                                  TRIM(TO_CHAR(ROUND(SUM(DRP), 1), '99999999990.9'))
                                 else
                                  '0.0'
                               end DRP,
                               T5.TM TMWARING,
                               T5.WINFO,
                               CASE
                                 WHEN T5.WINFO IS NULL THEN
                                  '0'
                                 ELSE
                                  '1'
                               END WARNING,
                               CASE
                                 WHEN T5.WINFO IS NULL THEN
                                  NORMAL
                                 ELSE
                                  RED

                               END COLOR

                          FROM (SELECT T2.*
                                  FROM DSE_ST_PPTN_REAL T1, ST_STBPRP_B T2
                                 WHERE T1.STCD = T2.STCD
                                   and t2.usfl = '1') T2
                          LEFT JOIN DSE_ST_PPTN_R T1
                            ON T1.STCD = T2.STCD
                           AND T1.TM >= SYSDATE - VTYPE / 24
                          LEFT JOIN DSE_ST_LABEL_SET T4
                            ON RTRIM(T4.STCD) = RTRIM(T2.STCD)
                           AND T4.LAYERID = 1

                          LEFT JOIN (SELECT STCD,
                                           TM,
                                           SUBSTR(MAX(SYS_CONNECT_BY_PATH(WINFO,
                                                                          '；')),
                                                  2) WINFO
                                      FROM (SELECT STCD,
                                                   TM,
                                                   WINFO,
                                                   RANK() OVER(PARTITION BY STCD ORDER BY TO_NUMBER(INDEXW)) RN
                                              FROM (SELECT STCD,
                                                           TM,

                                                           WINFO,
                                                           CASE
                                                             WHEN FUNC_ISNUMBER(SUBSTR(WINFO, 1, 2)) = 1 THEN
                                                              SUBSTR(WINFO, 1, 2)
                                                             ELSE
                                                              SUBSTR(WINFO, 1, 1)
                                                           END INDEXW,
                                                           RANK() OVER(PARTITION BY STCD ORDER BY TM DESC) ROWN
                                                      FROM DSE_WARN_INFO
                                                     WHERE TM >=
                                                           SYSDATE - VTYPE / 24
                                                       AND STINDEX = 'PP') T
                                             WHERE T.ROWN = 1)
                                     START WITH RN = 1
                                    CONNECT BY RN - 1 = PRIOR RN
                                     GROUP BY STCD, TM) T5
                            ON T5.STCD = T1.STCD

                         WHERE (VSTNM IS NULL OR
                               T2.STNM LIKE '%' || VSTNM || '%')
                        -- AND TM >= SYSDATE - INTERVAL VTYPE HOUR
                         GROUP BY NVL(T2.STNM, T2.STCD),
                                  T2.STCD,
                                  LGTD,
                                  LTTD,
                                  T4.MAXSCALE,
                                  T4.VIFL,
                               t4.SHOWLABELSCALE,
                                  T4.MINSCALE,
                                  T5.WINFO,
                                  T5.TM,
                                  TO_CHAR(getadnm(T2.ADDVCD)),
                                  T2.ADDVCD)ttt
                 WHERE WARNING LIKE '%' || ISWARING || '%'
                   AND ADDVCD LIKE nvl(VCODE, '') || '%' ) ttttt
         where (instr(GRADE, DRPGRADE, 1, 1) > 0 or GRADE is null )
           and (LGTD > tminx and LGTD < tmaxx and LTTD > tminy and
               LTTD < tmaxy)
           and (MAXSCALE is null or MAXSCALE >= Vmaxscale - 1 or WARNING>0)
          -- and (DRP > 0 or WARNING > 0)
         ORDER BY WARNING DESC, DRP DESC;
    ELSE
      OPEN CURR FOR
        select ttttt.*
          from (SELECT ttt.*,
                       case
                         when DRP <= 10 then
                          'A'
                         when DRP > 10 and DRP <= 25 then
                          'B'
                         when DRP > 25 and DRP <= 50 then
                          'C'
                         when DRP > 50 and DRP <= 100 then
                          'D'
                         when DRP > 100 and DRP <= 250 then
                          'E'
                         when DRP > 250 then
                          'F'
                         else
                          'A'
                       end DRPGRADE
                  FROM (
          SELECT NVL(T2.STNM, T2.STCD) STNM,
                       TO_CHAR(getadnm(T2.ADDVCD)) ADNM,
                       T2.ADDVCD,
                       T2.STCD,
                       'PP' STTP,
                       --TO_CHAR(getadnm(T2.ADDVCD)) ADNM,
                       case
                         when VMAPTYPE = '2' then
                          func_gis_lonmercator(T2.LGTD)
                         else
                          T2.LGTD
                       end LGTD,
                       case
                         when VMAPTYPE = '2' then
                          func_gis_latmercator(T2.LTTD)
                         else
                          T2.LTTD
                       end LTTD,
                       T4.MAXSCALE,
                       T4.MINSCALE,
                       T4.VIFL,
                               t4.showlabelscale SHOWLABELSCALE,
                       TO_CHAR(MAX(T1.TM), 'yyyy-mm-dd hh24:mi') TM,
                       case
                         when ROUND(SUM(DRP)) is not null then
                          TRIM(TO_CHAR(ROUND(SUM(DRP), 1), '99999999990.9'))
                         else
                          '0.0'
                       end DRP,
                       TO_CHAR(T5.TM, 'hh24:mi') TMWARING,
                       T5.WINFO,
                       CASE
                         WHEN T5.WINFO IS NULL THEN
                          '0'
                         ELSE
                          '1'
                       END WARNING,
                       CASE
                         WHEN T5.WINFO IS NULL THEN
                          NORMAL
                         ELSE
                          RED
                       END COLOR
                  FROM (SELECT T2.*
                          FROM DSE_ST_PPTN_REAL T1, ST_STBPRP_B T2
                         WHERE T1.STCD = T2.STCD
                           and t2.usfl = '1') T2
                  LEFT JOIN DSE_ST_PPTN_R T1
                    ON T1.STCD = T2.STCD
                   AND T1.TM > TO_DATE(BGDATE, 'yyyy-mm-dd hh24:mi:ss')
                   AND T1.TM <= TO_DATE(ENDDATE, 'yyyy-mm-dd hh24:mi:ss')
                  LEFT JOIN DSE_ST_LABEL_SET T4
                    ON RTRIM(T4.STCD) = RTRIM(T2.STCD)
                   AND T4.LAYERID = 1

                  LEFT JOIN (SELECT STCD,
                                   TM,
                                   SUBSTR(MAX(SYS_CONNECT_BY_PATH(WINFO,
                                                                  '；')),
                                          2) WINFO
                              FROM (SELECT STCD,
                                           TM,
                                           WINFO,
                                           RANK() OVER(PARTITION BY STCD ORDER BY TO_NUMBER(INDEXW)) RN
                                      FROM (SELECT STCD,
                                                   TM,
                                                   WINFO,
                                                   CASE
                                                     WHEN FUNC_ISNUMBER(SUBSTR(WINFO,
                                                                               1,
                                                                               2)) = 1 THEN
                                                      SUBSTR(WINFO, 1, 2)
                                                     ELSE
                                                      SUBSTR(WINFO, 1, 1)
                                                   END INDEXW,
                                                   RANK() OVER(PARTITION BY STCD ORDER BY TM DESC) ROWN
                                              FROM DSE_WARN_INFO
                                             WHERE TM >
                                                   TO_DATE(BGDATE,
                                                           'yyyy-mm-dd hh24:mi:ss')
                                               AND TM <=
                                                   TO_DATE(ENDDATE,
                                                           'yyyy-mm-dd hh24:mi:ss')
                                               AND STINDEX = 'PP') T
                                     WHERE T.ROWN = 1)
                             START WITH RN = 1
                            CONNECT BY RN - 1 = PRIOR RN
                             GROUP BY STCD, TM) T5
                    ON T5.STCD = T1.STCD
                 WHERE (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')
                 GROUP BY NVL(T2.STNM, T2.STCD),
                          T2.STCD,
                          LGTD,
                          LTTD,
                          T4.MAXSCALE,
                          T4.VIFL,
                               t4.SHOWLABELSCALE,
                          T4.MINSCALE,
                          T5.WINFO,
                          T5.TM,
                          TO_CHAR(getadnm(T2.ADDVCD)),
                          T2.ADDVCD)ttt
         WHERE WARNING LIKE '%' || ISWARING || '%'
           AND ADDVCD LIKE nvl(VCODE, '') || '%')ttttt where (instr(GRADE, DRPGRADE, 1, 1) > 0 or GRADE is null)
           and (LGTD > tminx and LGTD < tmaxx and LTTD > tminy and
               LTTD < tmaxy)
           and (MAXSCALE is null or MAXSCALE >= Vmaxscale - 1 or WARNING > 0)
          -- and (DRP > 0 or WARNING > 0)
           ;
    END IF;



    --查询河道数据
     OPEN CURR1 FOR
    SELECT tt.*
      FROM (SELECT NVL(T2.STNM, T1.STCD) STNM,
                   T1.STCD,
                   'ZZ' STTP,
                   CASE
                     WHEN VMAPTYPE = '2' THEN
                      FUNC_GIS_LONMERCATOR(T2.LGTD)
                     ELSE
                      T2.LGTD
                   END LGTD,
                   CASE
                     WHEN VMAPTYPE = '2' THEN
                      FUNC_GIS_LATMERCATOR(T2.LTTD)
                     ELSE
                      T2.LTTD
                   END LTTD,
                    T2.ADDVCD,
                   T4.MAXSCALE,
                   T4.MINSCALE,
                   T4.SHOWLABELSCALE,
                   T4.VIFL,
                   TO_CHAR(T1.TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(T1.Z, 2), '99999999990.99')) Z,
                   TRIM(TO_CHAR(ROUND(T3.WRZ, 2), '99999999990.99')) WRZ,
                   FUNC_NUMERIC(T1.Q, 3) Q,
                   CASE
                     WHEN T1.Z IS NULL OR T3.WRZ IS NULL THEN
                      NULL
                     WHEN T1.Z >= T3.WRZ OR T3.WRZ - T1.Z <= RANGE THEN
                      TRIM(TO_CHAR(ROUND(T1.Z - T3.WRZ, 2), '99999999990.99'))
                     ELSE
                      NULL
                   END CWRZ,
                   CASE
                     WHEN T1.Z IS NULL OR T3.WRZ IS NULL THEN
                      NORMAL
                     WHEN T1.Z >= T3.WRZ THEN
                      RED
                     WHEN T3.WRZ - T1.Z <= RANGE THEN
                      ORANGE
                     ELSE
                      NORMAL
                   END COLOR,
                   CASE
                     WHEN T1.Z IS NULL OR T3.WRZ IS NULL THEN
                      0
                     WHEN T1.Z >= T3.WRZ THEN
                      1
                     WHEN T3.WRZ - T1.Z <= RANGE THEN
                      2
                     ELSE
                      0
                   END WARNING,
                   CASE
                   -- WHEN T1.Z >= T3.WRZ OR (T3.WRZ - T1.Z) <= RANGE THEN
                     WHEN T1.Z >= T3.WRZ THEN
                      '1'
                     ELSE
                      '0'
                   END WARNINGBJ,
                   --WRZ为空时，按rz排序
                   -- ORDER BY NVL(T1.Z - T3.WRZ, Z) DESC;
                   CASE
                     WHEN T1.Z >= T3.WRZ OR T3.WRZ - T1.Z <= RANGE THEN
                      Z - T3.WRZ + 9999999
                     ELSE
                      T1.Z
                   END ORDERBYINDEX,
                   --是否测了雨量
                   DECODE(T5.STCD, NULL, 0, 1) YQ,
                   DECODE(T1.WPTN, '4', '↓', '5', '↑', '6', '→', '--') WPTN,
                   TO_CHAR(getadnm(T2.ADDVCD)) ADNM
              FROM DSE_ST_RIVER_REAL T1
            -- LEFT JOIN ST_STBPRP_B T2 ON T1.STCD = T2.STCD
              LEFT JOIN ST_RVFCCH_B T3 ON T1.STCD = T3.STCD
              LEFT JOIN DSE_ST_LABEL_SET T4 ON RTRIM(T4.STCD) =
                                               RTRIM(T1.STCD)
                                           AND T4.LAYERID = 1
              LEFT JOIN DSE_ST_PPTN_REAL T5 ON T1.STCD = T5.STCD,
             ST_STBPRP_B T2
             WHERE T1.STCD = T2.STCD
               and t2.usfl = '1'
               and (VSTNMHD IS NULL OR T2.STNM LIKE '%' || VSTNMHD || '%')
               AND (VCODE IS NULL OR T2.ADDVCD LIKE VCODE || '%')
              ) tt
     WHERE WARNINGBJ LIKE '%' || ISWARING || '%'
     and (LGTD > tminx and LGTD < tmaxx and LTTD > tminy and LTTD < tmaxy)
     and (MAXSCALE is null or MAXSCALE >= Vmaxscale - 1 or WARNINGBJ is not null);
    --查询水库实时数据
    OPEN CURR2 FOR select * from dual where 1=2;
  end;

END;


/

