create function      func_rsvr_area_mm_avz_avq_avw(p_stcd varchar,p_tm  date)
 return PLATFORM_RIVER_RSVR_TYPE is
  result_value PLATFORM_RIVER_RSVR_TYPE;--返回结果值表

   AVRZVAL number(7,3);	 --平均水位
	 AVINQVAL number(9,3);--平均入流量
	 AVOTQVAL number(9,3);	 --平均入流量
	 AVWVAL number(9,3)	; --平均蓄水量
    check_count int;--用于检测表中记录是否存在
  --临时数据表
   temp_table PLATFORM_RIVER_RSVR_TYPE;
   --统计区间计算水位和
	 vag_rz number(18,3);
	 --统计区间计算流量和
	 vag_inq number(18,3);
	--统计区间计算流量和
	 vag_otq number(18,3);
	 --统计区间计算流量和
	 vag_w number(18,3);
   START_TIME date; --查询开始时间 0-0时
   END_TIME date;--查询时间前一天时间点
	 q_rz number(7,3);
	 q_inq number(9,3);
	 q_otq number(9,3);
	 q_w number(9,3);

   tj_num int; --统计区间 旬开始时间和结束时间相差的天数
begin

    temp_table:= PLATFORM_RIVER_RSVR_TYPE();
    result_value:=PLATFORM_RIVER_RSVR_TYPE();
    vag_rz:=0;
    vag_inq:=0;
    vag_otq:=0;
    vag_w:=0;

   IF p_stcd IS NULL OR p_tm IS NULL THEN
       result_value.EXTEND;
       result_value(result_value.count):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,p_tm,null,null,null,null);
      return(result_value);
   END IF;

   START_TIME :=add_months(TO_DATE(TO_CHAR(p_tm, 'YYYY-MM') || '-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss'),-1);
   END_TIME:=TO_DATE(TO_CHAR(p_tm, 'YYYY-MM') || '-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss') ;

   tj_num:=trunc(END_TIME-START_TIME);

  declare cursor  cursor_data  is  select STCD,IDTM,AVRZ,AVINQ,AVOTQ,AVW from DSE_ST_RSVRAV_R where  STTDRCD='1'  and stcd=p_stcd and idtm>=START_TIME and idtm <=END_TIME order by idtm asc;
      begin
          FOR data_row IN cursor_data LOOP
               temp_table.EXTEND;
               temp_table(temp_table.COUNT):=PLATFORM_RIVER_RSVR_TABLE(data_row.stcd,data_row.IDTM,data_row.AVRZ,data_row.AVINQ,data_row.AVOTQ,data_row.AVW);
          END LOOP;
      end;
   --起始时间不存在
    select count(1) into check_count from table(temp_table) where TM=START_TIME;
    if check_count=0 then
       begin
            declare time_rz number(7,3); --线性插值获得水位
          			time_inq number(9,3); --线性插值获得流量
          			time_otq number(9,3); --线性插值获得流量
          			time_w number(9,3); --线性插值获得蓄水量

          			qs_bf_tm date;  --起始时间前一条记录时间
          			qs_bf_rz number(7,3);--起始时间前一条记录水位
          			qs_bf_inq number(9,3); --起始时间前一条记录流量
          			qs_bf_otq number(9,3); --起始时间前一条记录流量
          			qs_bf_w number(9,3); --起始时间前一条记录流量

          			qs_af_tm date;    --起始时间后一条记录时间
          			qs_af_rz number(7,3);--起始时间后一条记录水位
          			qs_af_inq number(9,3);--起始时间后一条记录流量
          			qs_af_otq number(9,3);--起始时间后一条记录流量
          			qs_af_w number(9,3);--起始时间后一条记录流量
            begin
                  --起始时间前一条记录
                   select max(IDTM),max(AVRZ),max(AVINQ),max(AVOTQ) ,max(AVW)  into qs_bf_tm,qs_bf_rz,qs_bf_inq,qs_bf_otq,qs_bf_w from (
                       select STCD,IDTM,AVRZ,AVINQ,AVOTQ,AVW,row_number() over(order by idtm desc) rown from DSE_ST_RSVRAV_R where   idtm>add_months(START_TIME,-1) and idtm <START_TIME and STTDRCD='1' and stcd=p_stcd
			             )t  where t.rown=1 ;
                   --起始时间后一条记录
                   select max(IDTM),max(AVRZ),max(AVINQ),max(AVOTQ) ,max(AVW)  into qs_af_tm,qs_af_rz,qs_af_inq,qs_af_otq,qs_af_w from (
                       select STCD,IDTM,AVRZ,AVINQ,AVOTQ,AVW,row_number() over(order by idtm asc) rown from DSE_ST_RSVRAV_R where  idtm>START_TIME and idtm <add_months(START_TIME,1) and STTDRCD='1' and stcd=p_stcd
			             )t  where t.rown=1 ;

                   	--前后水位不记录存在
              			if 	qs_bf_rz is not null and qs_af_rz is not null then
              				begin
              				    --线性插值发获取到当前水位流量值
              				    --y=y0+(x-x0)(y1-y0)/x1-x0
              				    time_rz :=qs_bf_rz+(qs_af_rz-qs_bf_rz)*(START_TIME-qs_bf_tm)/(qs_af_tm-qs_bf_tm);

              				    if time_rz is not null then
                  						begin
                  							 time_rz:=round(time_rz,2);
                  						end;
                          end if;
              					--线性插值取得流量
                          time_inq :=qs_bf_inq+(qs_af_inq-qs_bf_inq)*(START_TIME-qs_bf_tm)/(qs_af_tm-qs_bf_tm);
              				    if time_inq is not null then
                  						begin
                  							time_inq :=round(time_inq,3);
                  						end;
                           end if;
              					--线性插值取得流量
              					  time_otq:=qs_bf_otq+(qs_af_otq-qs_bf_otq)*(START_TIME-qs_bf_tm)/(qs_af_tm-qs_bf_tm);
              				    if time_otq is not null then
                  						begin
                  							time_otq:=round(time_otq,3);
                  						end;
                          end if;
              						--线性插值取得流量
              					  time_w:=qs_bf_w+(qs_af_w-qs_bf_w)*(START_TIME-qs_bf_tm)/(qs_af_tm-qs_bf_tm);
              				    if time_w is not null then
                  						begin
                  							 time_w :=round(time_w,3);
                  						end;
                          end if;
              				end;
                  end if;


                   --无法计算到起始水位
          			  if time_rz is null then
            				 begin
                      select round(avg(AVRZ),2),round(avg(AVINQ),3),round(avg(AVOTQ),3),round(avg(AVW),3) into vag_rz,vag_inq,vag_otq,vag_w
                      from DSE_ST_RSVRAV_R where  STTDRCD='1'  and stcd=p_stcd and idtm>START_TIME and idtm <=END_TIME ;
            					  result_value.EXTEND;
                        result_value(result_value.count):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,END_TIME,vag_rz,vag_inq,vag_otq,vag_w);
                        return(result_value);
            				 end;
          			  else
            				 begin
                        temp_table.EXTEND;
                        temp_table(temp_table.COUNT):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,START_TIME,time_rz,time_inq,time_otq,time_w);
            				 end;
                  end if;

            end;

       end;
    end if;

     --截止时间记录不存在
    select count(1) into check_count from table(temp_table) where TM=END_TIME;
    if check_count=0 then
       begin
        		declare end_time_rz number(7,3); --线性插值获得水位
            			end_time_inq number(9,3); --线性插值获得流量
            			end_time_otq number(9,3); --线性插值获得流量
            			end_time_w number(9,3); --线性插值获得蓄水量

            			end_qs_bf_tm date;  --起始时间前一条记录时间
            			end_qs_bf_rz number(7,3);--起始时间前一条记录水
            			end_qs_bf_inq number(9,3); --起始时间前一条记录
            			end_qs_bf_otq number(9,3); --起始时间前一条记录
            			end_qs_bf_w number(9,3); --起始时间前一条记录流

            			end_qs_af_tm date;    --起始时间后一条记录时
            			end_qs_af_rz number(7,3);--起始时间后一条记录水
            			end_qs_af_inq number(9,3);--起始时间后一条记录流
            			end_qs_af_otq number(9,3);--起始时间后一条记录流
            			end_qs_af_w number(9,3);--起始时间后一条记录流量
            begin
                  --起始时间前一条记录
                   select  max(IDTM),max(AVRZ),max(AVINQ),max(AVOTQ) ,max(AVW)  into end_qs_bf_tm,end_qs_bf_rz,end_qs_bf_inq,end_qs_bf_otq,end_qs_bf_w from (
                       select STCD,IDTM,AVRZ,AVINQ,AVOTQ,AVW,row_number() over(order by idtm desc) rown from DSE_ST_RSVRAV_R where idtm>add_months(END_TIME,-1) and idtm <END_TIME and STTDRCD='1' and stcd=p_stcd
			             )t  where t.rown=1 ;
                   --起始时间后一条记录
                   select  max(IDTM),max(AVRZ),max(AVINQ),max(AVOTQ) ,max(AVW) into end_qs_af_tm,end_qs_af_rz,end_qs_af_inq,end_qs_af_otq,end_qs_af_w from (
                       select STCD,IDTM,AVRZ,AVINQ,AVOTQ,AVW,row_number() over(order by idtm asc) rown from DSE_ST_RSVRAV_R where  idtm>END_TIME and idtm <add_months(END_TIME,1) and STTDRCD='1' and stcd=p_stcd
			             )t  where t.rown=1 ;
                   --前后水位不记录存在
            			if 	end_qs_bf_rz is not null and end_qs_af_rz is not null then
            			  	begin
            				    --线性插值发获取到当前水位流量值
            				    --y=y0+(x-x0)(y1-y0)/x1-x0
            				     end_time_rz :=end_qs_bf_rz+(end_qs_af_rz-end_qs_bf_rz)*(END_TIME-end_qs_bf_tm)/(end_qs_af_tm-end_qs_bf_tm);


            				    if end_time_rz is not null then
                						begin
                							end_time_rz:=round(end_time_rz,2);
                						end;
                         end if;
            					--线性插值取得流量
            					 end_time_inq :=end_qs_bf_inq+(end_qs_af_inq-end_qs_bf_inq)*(END_TIME-end_qs_bf_tm)/(end_qs_af_tm-end_qs_bf_tm);
            				   if end_time_inq is not null then
              						begin
              							  end_time_inq :=round(end_time_inq,3);
              						end;
                        end if;
            					--线性插值取得流量
            					  end_time_otq :=end_qs_bf_otq+(end_qs_af_otq-end_qs_bf_otq)*(END_TIME-end_qs_bf_tm)/(end_qs_af_tm-end_qs_bf_tm);
            				    if end_time_otq is not null then
                						begin
                							  end_time_otq:=round(end_time_otq,3);
                						end;
                        end if;
            						--线性插值取得流量
            					 end_time_w:=end_qs_bf_w+(end_qs_af_w-end_qs_bf_w)*(END_TIME-end_qs_bf_tm)/(end_qs_af_tm-end_qs_bf_tm);
            				    if end_time_w is not null then
                						begin
                							end_time_w :=round(end_time_w,3);
                						end	;
                         end if;
            				end;
                 end if;

                  --无法计算到起始水位
          			  if end_time_rz is null then
            				 begin
                      select round(avg(AVRZ),2),round(avg(AVINQ),3),round(avg(AVOTQ),3),round(avg(AVW),3) into vag_rz,vag_inq,vag_otq,vag_w
                      from DSE_ST_RSVRAV_R where  STTDRCD='1'  and stcd=p_stcd and idtm>START_TIME and idtm <=END_TIME ;
            					  result_value.EXTEND;
                        result_value(result_value.count):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,END_TIME,vag_rz,vag_inq,vag_otq,vag_w);
                        return(result_value);
            				 end;
          			  else
            				 begin
                        temp_table.EXTEND;
                        temp_table(temp_table.COUNT):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,END_TIME,end_time_rz,end_time_inq,end_time_otq,end_time_w);
            				 end;
                  end if;


            end;

       end;
    end if;

  FOR cur_temp in (select TM,AVZ,AVQ,AVOTQ,AVW from table(temp_table) order by tm asc) LOOP
      BEGIN

         declare bf_time date;
				         af_time date;
             begin
                   select max(tm) into bf_time from (
                       select tm,row_number() over(order by tm desc) rown from table(temp_table) where  tm <cur_temp.tm
			             )t  where t.rown=1 ;

                   select max(tm) into af_time from (
                       select tm,row_number() over(order by tm asc) rown from table(temp_table) where  tm>cur_temp.tm
			             )t  where t.rown=1 ;

                   if bf_time is null then
            					begin
            						 bf_time:=cur_temp.tm;
            					end;
                   end if;

            			if af_time is null then
            					begin
            						  af_time:=cur_temp.tm;
            					end;
                   end if;
                 q_rz:= cur_temp.avz;
                 q_inq:=cur_temp.AVQ;
                 q_otq:=cur_temp.AVOTQ;
                 q_w:=cur_temp.AVW;
                if q_rz is not null and q_rz>0 then
          					begin
                      --乘时间分钟差
          						 vag_rz:=vag_rz+q_rz*(af_time-bf_time);
          					end;
          			end if;
      				 if q_inq is not null and q_inq>0 then
        					begin
        						 vag_inq:=vag_inq+q_inq*(af_time-bf_time);
        					end	;
      				 end if;
      				 if q_otq is not null and q_otq>0 then
        					begin
        						 vag_otq:=vag_otq+q_otq*(af_time-bf_time);
        					end;
      				  end if;
      				 if q_w is not null and q_w>0 then
        					begin
        						 vag_w:=vag_w+q_w*(af_time-bf_time);
        					end;
               end if;

           end;


      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
   END LOOP;

  if vag_rz >0 then
  		begin
  			  AVRZVAL:=round(vag_rz/(2*tj_num),2);
  		end;
   end if;
   if vag_inq >0 then
  		begin
  			 AVINQVAL:=round(vag_inq/(2*tj_num),3);
  		end;
    end if;
   if vag_otq >0 then
  		begin
  			 AVOTQVAL:=round(vag_otq/(2*tj_num),3);
  		end;
    end if;
  if vag_w >0 then
  		begin
  			 AVWVAL:=round(vag_w/(2*tj_num),3);
  		end	;
  end if;


  result_value.EXTEND;
  result_value(result_value.count):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,END_TIME,AVRZVAL,AVINQVAL,AVOTQVAL,AVWVAL);
    return(result_value);
end func_rsvr_area_mm_avz_avq_avw;


/

