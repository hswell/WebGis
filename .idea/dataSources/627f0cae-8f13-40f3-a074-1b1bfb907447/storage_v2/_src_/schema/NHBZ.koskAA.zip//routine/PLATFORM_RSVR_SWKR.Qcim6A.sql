create PROCEDURE      PLATFORM_RSVR_SWKR(VSTCD VARCHAR,
                                               CURR1 OUT PLATFORM.CURSOR) IS
BEGIN
  --返回水库的静态水位库容关系数据
  OPEN CURR1 FOR
    SELECT TT.*, ROWNUM
      FROM (SELECT TRIM(TO_CHAR(ROUND(RZ, 2), '99999999990.99')) RZ,
                   FUNC_NUMERIC(W, 3) W
              FROM ST_ZVARL_B
             WHERE STCD = VSTCD
             ORDER BY TO_NUMBER(RZ) DESC) TT;

END PLATFORM_RSVR_SWKR;


/

