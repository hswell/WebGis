create PROCEDURE      PLATFORM_BZ_STATE2(VSTCD VARCHAR,
                                               ST    VARCHAR,
                                               ET    VARCHAR,
                                                CUR1 OUT PLATFORM.CURSOR,
                                               CUR2 OUT PLATFORM.CURSOR) IS
  VST DATE;
  VET DATE;
BEGIN
  VST := TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss');
  VET := TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss');
   --船闸状态

  --查询闸门数量
  OPEN CUR1 FOR
       SELECT max(B.UNNB) as ZMNUM FROM DSE_TB0001_REMARK_B R,TB1502_MEIDSBI_044 B WHERE  R.ENNMCD = B.ENNMCD and r.STCD = VSTCD;

    --查询闸门开关数据
  OPEN CUR2 FOR
        SELECT TO_CHAR(TT.TM, 'YYYY-MM-DD HH24:MI:SS') TM,
       TT.STCD,
       TT.STATE,
       TT.N1,
       TT.N2,
       TT.N3,
       TT.N4,
       TT.N5,
       TT.N6
  FROM dse_bz_runstate_r TT
        WHERE TT.STCD = VSTCD   AND TT.TM>=VST AND TT.TM<=VET  ORDER BY TT.TM ASC;


END PLATFORM_BZ_STATE2;


/

