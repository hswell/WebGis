create procedure      PLATFORM_BZ_JZYXJS(ENNMCDS    VARCHAR,
                                               STCDS      VARCHAR,
                                               AIRCREWNMS VARCHAR,
                                               CUR1       OUT PLATFORM.CURSOR) is
  TMGSTR VARCHAR(20);
  TMG DATE;
  STAT VARCHAR(10);
  STR VARCHAR(500);
  ZD  VARCHAR(20);
begin
  IF AIRCREWNMS = '1#' THEN
    ZD := 'N1';
  ELSIF AIRCREWNMS = '2#' THEN
    ZD := 'N2';
  ELSIF AIRCREWNMS = '2#' THEN
    ZD := 'N2';
  ELSIF AIRCREWNMS = '3#' THEN
    ZD := 'N3';
  ELSIF AIRCREWNMS = '4#' THEN
    ZD := 'N4';
  ELSIF AIRCREWNMS = '5#' THEN
    ZD := 'N5';
  ELSIF AIRCREWNMS = '6#' THEN
    ZD := 'N6';
  ELSIF AIRCREWNMS = '7#' THEN
    ZD := 'N7';
  ELSIF AIRCREWNMS = '8#' THEN
    ZD := 'N8';
  ELSIF AIRCREWNMS = '9#' THEN
    ZD := 'N9';
  ELSIF AIRCREWNMS = '10#' THEN
    ZD := 'N10';
  ELSIF AIRCREWNMS = '11#' THEN
    ZD := 'N11';
  ELSIF AIRCREWNMS = '12#' THEN
    ZD := 'N12';
  END IF;

  --查询最新一条N#状态为0的记录,如果没有,则给TMG赋值到一年前
  STR := 'SELECT * FROM (SELECT TO_CHAR(R.TM,''YYYY-MM-DD HH24:MI:SS'') FROM DSE_BZ_RUNSTATE_R R WHERE R.STCD = ''' ||
         STCDS || ''' AND R.' || ZD || ' = ''0'' ORDER BY R.TM DESC) T WHERE ROWNUM = 1 ';
  EXECUTE IMMEDIATE STR
    INTO TMGSTR ;
    BEGIN
      --查询N#对应的最早开机时间(最新一条状态为1)
      STR := 'SELECT * FROM (SELECT R.TM,R.' || ZD ||' FROM DSE_BZ_RUNSTATE_R R WHERE R.STCD = ''' ||
         STCDS || ''' AND TO_CHAR(R.TM,''YYYY-MM-DD HH24:MI:SS'')>'''||TMGSTR||''' ORDER BY R.TM ASC) T WHERE ROWNUM = 1 ';
      EXECUTE IMMEDIATE STR
        INTO TMG,STAT;
          IF STAT = '1' THEN
          BEGIN
            OPEN CUR1 FOR
            SELECT T.*,
                   P.PPATH,
                   A.PATH,
                   TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') TMNM,
                   CASE T.AIRCREWSTATE
                     WHEN '1' THEN
                      '开'
                     ELSE
                      '关'
                   END AIRCREWSTATENM,
                   ROUND((SYSDATE - TMG) * 24 * 60) KJSC
              FROM DSE_BZ_RUNINFO_REAL T
              LEFT JOIN DSE_BZ_PUMB B
                ON (B.ENNMCD = ENNMCDS AND B.AIRCREWNM = AIRCREWNMS)
              LEFT JOIN TB0003_PRGL_044 P
                ON (P.ENNMCD = ENNMCDS AND P.FGMR = B.FGMR)
              LEFT JOIN DSE_ATTACHMENT A
                ON (B.FPATH = A.BSNUM)
             WHERE T.STCD = STCDS
               AND T.AIRCREWNM = AIRCREWNMS;
          END;
        ELSE
          BEGIN
            OPEN CUR1 FOR
            SELECT T.*,
                   P.PPATH,
                   A.PATH,
                   TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') TMNM,
                   CASE T.AIRCREWSTATE
                     WHEN '1' THEN
                      '开'
                     ELSE
                      '关'
                   END AIRCREWSTATENM,
                   0 KJSC
              FROM DSE_BZ_RUNINFO_REAL T
              LEFT JOIN DSE_BZ_PUMB B

                ON (B.ENNMCD = ENNMCDS AND B.AIRCREWNM = AIRCREWNMS)
              LEFT JOIN TB0003_PRGL_044 P
                ON (P.ENNMCD = ENNMCDS AND P.FGMR = B.FGMR)
              LEFT JOIN DSE_ATTACHMENT A
                ON (B.FPATH = A.BSNUM)
             WHERE T.STCD = STCDS
               AND T.AIRCREWNM = AIRCREWNMS;
          END;
        END IF;
      EXCEPTION WHEN NO_DATA_FOUND THEN
          OPEN CUR1 FOR
          SELECT T.*,
                 P.PPATH,
                 A.PATH,
                 TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') TMNM,
                 CASE T.AIRCREWSTATE
                   WHEN '1' THEN
                    '开'
                   ELSE
                    '关'
                 END AIRCREWSTATENM,
                 0 KJSC
            FROM DSE_BZ_RUNINFO_REAL T
            LEFT JOIN DSE_BZ_PUMB B
              ON (B.ENNMCD = ENNMCDS AND B.AIRCREWNM = AIRCREWNMS)
            LEFT JOIN TB0003_PRGL_044 P
              ON (P.ENNMCD = ENNMCDS AND P.FGMR = B.FGMR)
            LEFT JOIN DSE_ATTACHMENT A
              ON (B.FPATH = A.BSNUM)
           WHERE T.STCD = STCDS
             AND T.AIRCREWNM = AIRCREWNMS;
    END;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
    BEGIN
      TMGSTR := TO_CHAR(SYSDATE - 365,'YYYY-MM-DD HH24:MI:SS');
      --查询N#对应的最早开机时间(最新一条状态为1)
      STR := 'SELECT * FROM (SELECT R.TM,R.' || ZD ||' FROM DSE_BZ_RUNSTATE_R R WHERE R.STCD = ''' ||
             STCDS || ''' AND TO_CHAR(R.TM,''YYYY-MM-DD HH24:MI:SS'')>'''||TMGSTR||''' ORDER BY R.TM ASC) T WHERE ROWNUM = 1 ';
      EXECUTE IMMEDIATE STR
        INTO TMG,STAT;
          IF STAT = '1' THEN
          BEGIN
            OPEN CUR1 FOR
            SELECT T.*,
                   P.PPATH,
                   A.PATH,
                   TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') TMNM,
                   CASE T.AIRCREWSTATE
                     WHEN '1' THEN
                      '开'
                     ELSE
                      '关'
                   END AIRCREWSTATENM,
                   ROUND((SYSDATE - TMG) * 24 * 60) KJSC
              FROM DSE_BZ_RUNINFO_REAL T
              LEFT JOIN DSE_BZ_PUMB B
                ON (B.ENNMCD = ENNMCDS AND B.AIRCREWNM = AIRCREWNMS)
              LEFT JOIN TB0003_PRGL_044 P
                ON (P.ENNMCD = ENNMCDS AND P.FGMR = B.FGMR)
              LEFT JOIN DSE_ATTACHMENT A
                ON (B.FPATH = A.BSNUM)
             WHERE T.STCD = STCDS
               AND T.AIRCREWNM = AIRCREWNMS;
          END;
        ELSE
          BEGIN
            OPEN CUR1 FOR
            SELECT T.*,
                   P.PPATH,
                   A.PATH,
                   TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') TMNM,
                   CASE T.AIRCREWSTATE
                     WHEN '1' THEN
                      '开'
                     ELSE
                      '关'
                   END AIRCREWSTATENM,
                   0 KJSC
              FROM DSE_BZ_RUNINFO_REAL T
              LEFT JOIN DSE_BZ_PUMB B

                ON (B.ENNMCD = ENNMCDS AND B.AIRCREWNM = AIRCREWNMS)
              LEFT JOIN TB0003_PRGL_044 P
                ON (P.ENNMCD = ENNMCDS AND P.FGMR = B.FGMR)
              LEFT JOIN DSE_ATTACHMENT A
                ON (B.FPATH = A.BSNUM)
             WHERE T.STCD = STCDS
               AND T.AIRCREWNM = AIRCREWNMS;
          END;
        END IF;
      EXCEPTION WHEN NO_DATA_FOUND THEN
          OPEN CUR1 FOR
          SELECT T.*,
                 P.PPATH,
                 A.PATH,
                 TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') TMNM,
                 CASE T.AIRCREWSTATE
                   WHEN '1' THEN
                    '开'
                   ELSE
                    '关'
                 END AIRCREWSTATENM,
                 0 KJSC
            FROM DSE_BZ_RUNINFO_REAL T
            LEFT JOIN DSE_BZ_PUMB B
              ON (B.ENNMCD = ENNMCDS AND B.AIRCREWNM = AIRCREWNMS)
            LEFT JOIN TB0003_PRGL_044 P
              ON (P.ENNMCD = ENNMCDS AND P.FGMR = B.FGMR)
            LEFT JOIN DSE_ATTACHMENT A
              ON (B.FPATH = A.BSNUM)
           WHERE T.STCD = STCDS
             AND T.AIRCREWNM = AIRCREWNMS;
    END;
end PLATFORM_BZ_JZYXJS;


/

