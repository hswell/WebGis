create function      getLabelByCode(vcode  in varchar2,myval in varchar2) return varchar2
as
vlable  varchar2(200) ;

begin

     if(myval is not null and length(myval) >0) then
        select label into vlable from SYS_COMMONCODE where code = vcode and val=myval;
     end if;
     return vlable;
end getLabelByCode;


/

