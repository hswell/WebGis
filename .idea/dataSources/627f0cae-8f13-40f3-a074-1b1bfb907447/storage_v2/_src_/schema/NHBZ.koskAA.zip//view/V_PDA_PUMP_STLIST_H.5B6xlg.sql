create view V_PDA_PUMP_STLIST_H as
select B1.STCD,B1.TM,
  getXqName()||'|内水位(m):' ||nvl(to_char(B1.NSW, 'fm99990.00'),'0')
  || '|-|外水位(m):'||nvl(to_char(B1.WSW, 'fm99990.00'),'0') || '|-|' ||
  '状态:'
|| '|机组台数:' || (select count(*) from DSE_BZ_RUNINFO_R where stcd = b1.stcd and B1.TM=tm group by stcd )
|| '|机组状态:'
 ||
 sum(decode(AIRCREWNM,'1#', AIRCREWSTATE,''))
  ||':' ||  sum(decode(AIRCREWNM,'2#',  AIRCREWSTATE,''))
  ||':' ||  sum(decode(AIRCREWNM,'3#',  AIRCREWSTATE,''))
  ||':' ||  sum(decode(AIRCREWNM,'4#',  AIRCREWSTATE,''))
  ||':' ||  sum(decode(AIRCREWNM,'5#',  AIRCREWSTATE,''))
  ||':' ||  sum(decode(AIRCREWNM,'6#',  AIRCREWSTATE,''))
  ||':' ||  sum(decode(AIRCREWNM,'7#',  AIRCREWSTATE,''))
  ||':' ||  sum(decode(AIRCREWNM,'8#',  AIRCREWSTATE,''))
  ||':' ||  sum(decode(AIRCREWNM,'9#',  AIRCREWSTATE,''))
     || '|A相电压(KV):'
     ||



 sum(decode(AIRCREWNM,'1#',VOLTAGEA,''))
 ||':' || sum(decode(AIRCREWNM,'2#',VOLTAGEA,''))
   ||':' ||  sum(decode(AIRCREWNM,'3#',VOLTAGEA,''))
    ||':' || sum(decode(AIRCREWNM,'4#',VOLTAGEA,''))
     ||':' || sum(decode(AIRCREWNM,'5#',VOLTAGEA,''))
      ||':' ||  sum(decode(AIRCREWNM,'6#',VOLTAGEA,''))
       ||':' ||   sum(decode(AIRCREWNM,'7#',VOLTAGEA,''))
        ||':' ||   sum(decode(AIRCREWNM,'8#',VOLTAGEA,''))
         ||':' ||   sum(decode(AIRCREWNM,'9#',VOLTAGEA,''))
   ||  '|B相电压(KV):'
   ||

    sum(decode(AIRCREWNM,'1#',VOLTAGEB,''))
  ||':' || sum(decode(AIRCREWNM,'2#',VOLTAGEB,''))
   ||':' || sum(decode(AIRCREWNM,'3#',VOLTAGEB,''))
   ||':' ||sum(decode(AIRCREWNM,'4#',VOLTAGEB,''))
   ||':' || sum(decode(AIRCREWNM,'5#',VOLTAGEB,''))
   ||':' ||  sum(decode(AIRCREWNM,'6#',VOLTAGEB,''))
   ||':' ||   sum(decode(AIRCREWNM,'7#',VOLTAGEB,''))
   ||':' ||    sum(decode(AIRCREWNM,'8#',VOLTAGEB,''))
    ||':' ||    sum(decode(AIRCREWNM,'9#',VOLTAGEB,''))

    ||  '|C相电压(KV):'
    ||

     sum(decode(AIRCREWNM,'1#',VOLTAGEC,''))
  ||':' || sum(decode(AIRCREWNM,'2#',VOLTAGEC,''))
  ||':' ||  sum(decode(AIRCREWNM,'3#',VOLTAGEC,''))
  ||':' || sum(decode(AIRCREWNM,'4#',VOLTAGEC,''))
  ||':' ||  sum(decode(AIRCREWNM,'5#',VOLTAGEC,''))
  ||':' ||   sum(decode(AIRCREWNM,'6#',VOLTAGEC,''))
   ||':' ||   sum(decode(AIRCREWNM,'7#',VOLTAGEC,''))
   ||':' ||    sum(decode(AIRCREWNM,'8#',VOLTAGEC,''))
     ||':' ||   sum(decode(AIRCREWNM,'9#',VOLTAGEC,''))

     || '|A相电流(A):'
     ||

       sum(decode(AIRCREWNM,'1#',ECA,''))
   ||':' ||sum(decode(AIRCREWNM,'2#',ECA,''))
  ||':' ||  sum(decode(AIRCREWNM,'3#',ECA,''))
   ||':' ||sum(decode(AIRCREWNM,'4#',ECA,''))
  ||':' ||  sum(decode(AIRCREWNM,'5#',ECA,''))
   ||':' ||  sum(decode(AIRCREWNM,'6#',ECA,''))
   ||':' ||   sum(decode(AIRCREWNM,'7#',ECA,''))
   ||':' ||   sum(decode(AIRCREWNM,'8#',ECA,''))
     ||':' ||   sum(decode(AIRCREWNM,'9#',ECA,''))
   || '|B相电流(A):'
     ||

  sum(decode(AIRCREWNM,'1#',ECB,''))
  ||':' || sum(decode(AIRCREWNM,'2#',ECB,''))
   ||':' || sum(decode(AIRCREWNM,'3#',ECB,''))
   ||':' ||sum(decode(AIRCREWNM,'4#',ECB,''))
   ||':' || sum(decode(AIRCREWNM,'5#',ECB,''))
   ||':' ||  sum(decode(AIRCREWNM,'6#',ECB,''))
   ||':' ||   sum(decode(AIRCREWNM,'7#',ECB,''))
   ||':' ||    sum(decode(AIRCREWNM,'8#',ECB,''))
    ||':' ||    sum(decode(AIRCREWNM,'9#',ECB,''))
      || '|C相电流(A):'
     ||


     sum(decode(AIRCREWNM,'1#',ECC,''))
   ||':' ||sum(decode(AIRCREWNM,'2#',ECC,''))
   ||':' || sum(decode(AIRCREWNM,'3#',ECC,''))
  ||':' || sum(decode(AIRCREWNM,'4#',ECC,''))
   ||':' || sum(decode(AIRCREWNM,'5#',ECC,''))
   ||':' ||  sum(decode(AIRCREWNM,'6#',ECC,''))
    ||':' ||  sum(decode(AIRCREWNM,'7#',ECC,''))
    ||':' ||   sum(decode(AIRCREWNM,'8#',ECC,''))
     ||':' ||   sum(decode(AIRCREWNM,'9#',ECC,''))
    || '|功率(KW):' || B1.POWERACTIVE||'|故障:0'
    as stlist

from DSE_BZ_RUNINFO_R  B1
group by B1.STCD,B1.TM,B1.NSW,B1.WSW,B1.POWERACTIVE


/

