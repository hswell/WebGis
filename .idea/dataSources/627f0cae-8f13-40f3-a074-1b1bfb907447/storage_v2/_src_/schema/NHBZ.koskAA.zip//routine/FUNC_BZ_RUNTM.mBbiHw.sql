create function      FUNC_BZ_RUNTM(VSTCD varchar) return date is
  Result date;
begin
  begin
    select min(tm)
      into Result
      from dse_bz_runstate_r
     where state = 1
       and tm > (select case
                          when max(tm) is not null then
                           max(tm)
                          else
                           to_date('2000-1-1', 'yyyy-mm-dd')
                        end tm
                   from dse_bz_runstate_r
                  where state = 0
                    and stcd = VSTCD)
       and stcd = VSTCD;
  Exception
    when others then
      Result := null;
  end;
  return(Result);

end FUNC_BZ_RUNTM;


/

