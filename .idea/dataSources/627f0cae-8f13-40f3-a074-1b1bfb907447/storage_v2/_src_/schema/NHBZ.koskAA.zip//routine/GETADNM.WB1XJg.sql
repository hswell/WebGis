create function      getAdnm(adcd  in varchar2) return varchar2
as
code  varchar2(15) ;

begin
     code := rtrim(adcd);
     if(code is not null and length(code) >1) then
        select adnm into code from ad_cd_b where adcd = code;
     end if;
     return code;
end getAdnm;


/

