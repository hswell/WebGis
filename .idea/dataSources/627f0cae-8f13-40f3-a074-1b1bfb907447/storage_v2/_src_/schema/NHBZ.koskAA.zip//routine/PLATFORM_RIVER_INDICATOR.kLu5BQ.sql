create procedure      PLATFORM_RIVER_INDICATOR(STCDS  VARCHAR,
                                                PAGEFROM  INT,
                                                PAGETO   INT,
                                                cursor1 OUT PLATFORM.CURSOR) is
begin
    open cursor1 for
      select * from (
        SELECT t2.STCD,t2.STNM,t2.stlc
         ,t3.LDKEL
         ,t3.RDKEL
         ,t3.WRZ
         ,t3.WRQ
         ,t3.GRZ
         ,t3.GRQ
         ,t3.FLPQ
         ,t3.OBHTZ
         ,t3.OBHTZTM
         ,t3.IVHZ
         ,t3.IVHZTM
         ,t3.OBMXQ
         ,t3.OBMXQTM
         ,t3.IVMXQ
         ,t3.HMXS
         ,t3.HMXSTM
         ,t3.HMXAVV
         ,t3.HMXAVVTM
         ,t3.HLZ
         ,t3.HLZTM
         ,t3.HMNQ
         ,t3.HMNQTM
         ,t3.TAZ
         ,t3.TAQ
         ,t3.LAZ
         ,t3.LAQ
         ,t3.SFZ
         ,t3.SFQ
         ,t3.MODITIME
         ,t3.IVMXQTM,row_number() over(order by t2.stcd) as rn
        FROM ST_STBPRP_B t2
        INNER JOIN (SELECT * FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS  PLATFORM_STCD_TYPE))) t4 ON t4.STCD = t2.STCD
        left join st_rvfcch_b t3 on t3.stcd=t2.stcd
        WHERE (t2.sttp='ZZ' OR t2.sttp='ZQ')
      ) t4 where rn>PAGEFROM and rn<=PAGETO;

end PLATFORM_RIVER_INDICATOR;


/

