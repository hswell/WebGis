create PROCEDURE      PLATFORM_SS_SSTJ_CX(vstcd varchar,
                                                st    varchar,
                                                et    varchar,
                                                CURR  OUT PLATFORM.CURSOR) IS

BEGIN

  OPEN CURR FOR
    select TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
           TRIM(TO_CHAR(ROUND(SLM10, 1), '99999999990.9')) SLM10,
           TRIM(TO_CHAR(ROUND(STEMP, 1), '99999999990.9')) STEMP,
           TRIM(TO_CHAR(ROUND(SLM20, 1), '99999999990.9')) SLM20,
           TRIM(TO_CHAR(ROUND(SLM30, 1), '99999999990.9')) SLM30,
           ROWNUM
      from DSE_ST_SOIL_R t1
     where t1.STCD = vstcd
       and t1.TM >= to_date(st, 'YYYY-MM-DD HH24:MI:SS')
       and t1.tm <= to_date(et, 'YYYY-MM-DD HH24:MI:SS')
     order by tm desc;
END PLATFORM_SS_SSTJ_CX;


/

