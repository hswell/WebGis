create procedure      PLATFORM_SZ_GQTJ(STCDS    VARCHAR,
                                             ST       VARCHAR,
                                             ET       VARCHAR,
                                             PAGEFROM INT,
                                             PAGETO   INT,
                                             CUR      OUT PLATFORM.CURSOR) is

  tbout        platform_sz_runstatetb1 := platform_sz_runstatetb1(null);
  tb           platform_sz_runstate1 := platform_sz_runstate1(null,
                                                              null,
                                                              null,
                                                              null,
                                                              null,
                                                              null,
                                                              null,
                                                              null);
  STCDA        VARCHAR(8);
  KTMA         DATE; --开闸时间
  K_IN_WATERA  numeric(8, 3); --开闸内水位
  K_OUT_WATERA numeric(8, 3); --开闸外水位
  GTMA         DATE; --关闸时间
  G_IN_WATERA  numeric(8, 3); --关闸内水位
  G_OUT_WATERA numeric(8, 3); --关闸外水位
  FLAGA        CHAR(1); -- 判断是否插入完成 1:完成，0:未完成
  lv_l         number;
begin
  lv_l := 0;
  for tt in (SELECT T.TM, T.STCD, T.STATE, T.IN_WATER, T.OUT_WATER
               FROM DSE_SZ_RUNSTATE_R T
              INNER JOIN (SELECT *
                           FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                           PLATFORM_STCD_TYPE))) T2
                 ON T2.STCD = T.STCD
              WHERE T.TM >= TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss')
                AND T.TM < TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss')
              ORDER BY T.STCD, T.TM ASC) loop
    if TT.STATE = '0' THEN
      BEGIN
        SELECT AA.STCD,
               AA.KTM,
               AA.K_IN_WATER,
               AA.K_OUT_WATER,
               AA.GTM,
               AA.G_IN_WATER,
               AA.G_OUT_WATER,
               AA.FLAG
          INTO STCDA,
               KTMA,
               K_IN_WATERA,
               K_OUT_WATERA,
               GTMA,
               G_IN_WATERA,
               G_OUT_WATERA,
               FLAGA
          FROM (SELECT A.*
                  FROM TABLE(CAST(TBOUT AS platform_sz_runstatetb1)) A
                 WHERE TT.STCD = A.STCD
                   AND A.STCD IS NOT NULL
                   AND A.FLAG = '0'
                 ORDER BY A.KTM DESC) AA
         WHERE ROWNUM = 1;
        IF STCDA IS NOT NULL AND KTMA < TT.TM THEN
          BEGIN
            TB.STCD        := STCDA;
            TB.KTM         := KTMA;
            TB.K_IN_WATER  := K_IN_WATERA;
            TB.K_OUT_WATER := K_OUT_WATERA;
            TB.GTM         := TT.TM;
            TB.G_IN_WATER  := TT.IN_WATER;
            TB.G_OUT_WATER := TT.OUT_WATER;
            TB.FLAG        := '1';
            lv_l           := lv_l;
            --TBOUT.EXTEND(1);
            TBOUT(lv_l) := TB;
            --UPDATE TABLE (CAST(TBOUT AS platform_sz_runstatetb1))D SET D.GTM = TT.TM,D.G_IN_WATER = TT.IN_WATER,
            --D.G_OUT_WATER = TT.OUT_WATER,D.FLAG = '1' WHERE D.STCD = TT.STCD AND D.FLAG = '0';
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        ELSIF STCDA IS NULL THEN
          BEGIN
            tb.STCD        := TT.STCD;
            TB.GTM         := TT.TM;
            TB.G_IN_WATER  := TT.IN_WATER;
            TB.G_OUT_WATER := TT.OUT_WATER;
            TB.KTM         := NULL;
            TB.K_IN_WATER  := NULL;
            TB.K_OUT_WATER := NULL;
            TB.FLAG        := '1';
            lv_l           := lv_l + 1;
            TBOUT.EXTEND(1);
            TBOUT(lv_l) := TB;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
      EXCEPTION
       WHEN NO_DATA_FOUND THEN
          BEGIN
            tb.STCD        := TT.STCD;
            TB.GTM         := TT.TM;
            TB.G_IN_WATER  := TT.IN_WATER;
            TB.G_OUT_WATER := TT.OUT_WATER;
            TB.KTM         := NULL;
            TB.K_IN_WATER  := NULL;
            TB.K_OUT_WATER := NULL;
            TB.FLAG        := '1';
            lv_l           := lv_l + 1;
            TBOUT.EXTEND(1);
            TBOUT(lv_l) := TB;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
      END;
    ELSIF TT.STATE = '1' THEN
      BEGIN
        SELECT AA.STCD,
               AA.KTM,
               AA.K_IN_WATER,
               AA.K_OUT_WATER,
               AA.GTM,
               AA.G_IN_WATER,
               AA.G_OUT_WATER,
               AA.FLAG
          INTO STCDA,
               KTMA,
               K_IN_WATERA,
               K_OUT_WATERA,
               GTMA,
               G_IN_WATERA,
               G_OUT_WATERA,
               FLAGA
          FROM (SELECT A.*
                  FROM TABLE(CAST(TBOUT AS platform_sz_runstatetb1)) A
                 WHERE TT.STCD = A.STCD
                   AND A.STCD IS NOT NULL
                   AND A.FLAG = '0'
                 ORDER BY A.KTM DESC) AA
         WHERE ROWNUM = 1;
         IF STCDA IS NULL THEN
           BEGIN
           tb.STCD        := TT.STCD;
          TB.KTM         := TT.TM;
          TB.K_IN_WATER  := TT.IN_WATER;
          TB.K_OUT_WATER := TT.OUT_WATER;
          TB.GTM         := NULL;
          TB.G_IN_WATER  := NULL;
          TB.G_OUT_WATER := NULL;
          TB.FLAG        := '0';
          lv_l           := lv_l + 1;
          TBOUT.EXTEND(1);
          TBOUT(lv_l) := TB;

          EXCEPTION
        WHEN OTHERS THEN
          NULL;
          END;
          END IF;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
            tb.STCD        := TT.STCD;
          TB.KTM         := TT.TM;
          TB.K_IN_WATER  := TT.IN_WATER;
          TB.K_OUT_WATER := TT.OUT_WATER;
          TB.GTM         := NULL;
          TB.G_IN_WATER  := NULL;
          TB.G_OUT_WATER := NULL;
          TB.FLAG        := '0';
          lv_l           := lv_l + 1;
          TBOUT.EXTEND(1);
          TBOUT(lv_l) := TB;
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
      END;
    END IF;
  end loop;

  OPEN CUR FOR
    SELECT ROWNUM,
           TTT.STCD,
           TRIM(TTT.STNM) STNM,
           TO_CHAR(TTT.KTM, 'YYYY-MM-DD HH24:MI') KTM,
           TTT.K_IN_WATER,
           TTT.K_OUT_WATER,
           TO_CHAR(TTT.GTM, 'YYYY-MM-DD HH24:MI') GTM,
           ROUND((TTT.GTM - TTT.KTM) * 24 * 60) YXSJ,
           TTT.G_IN_WATER,
           TTT.G_OUT_WATER
      FROM (SELECT E.*
              FROM (SELECT C.*, S.STNM, ROWNUM ROWNUM_
                      FROM TABLE(CAST(TBOUT AS platform_sz_runstatetb1)) C,
                           ST_STBPRP_B S
                     WHERE S.STCD = TRIM(C.STCD)
                       AND C.STCD IS NOT NULL

                     ORDER BY C.STCD, C.KTM DESC NULLS LAST) E) TTT
     WHERE TTT.ROWNUM_ > PAGEFROM
       AND TTT.ROWNUM_ <= PAGETO;

EXCEPTION
  WHEN OTHERS THEN
    NULL;

end PLATFORM_SZ_GQTJ;


/

