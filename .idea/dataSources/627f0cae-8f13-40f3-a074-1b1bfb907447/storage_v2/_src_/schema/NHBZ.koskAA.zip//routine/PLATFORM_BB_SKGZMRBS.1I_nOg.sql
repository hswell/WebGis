create PROCEDURE      PLATFORM_BB_SKGZMRBS(STCDS VARCHAR,
                                                 DT    VARCHAR,
                                                 CUR1  OUT PLATFORM.CURSOR) IS

BEGIN
  -- 各站每日8时水情表（水位、蓄水量）
  OPEN CUR1 FOR
    SELECT T2.STNM,
           TRIM(TO_CHAR(ROUND(T1.RZ, 2), '99999999990.99')) RZ,
           FUNC_NUMERIC(T1.W, 3) W
      FROM (SELECT * FROM TABLE(FUNC_SPLITSTRING(STCDS))) T3
      LEFT JOIN DSE_ST_RSVR_R T1 ON T1.STCD = T3.STCD
                                AND T1.TM >=
                                    TO_DATE(DT || ' 08:00:00',
                                            'yyyy-mm-dd hh24:mi:ss')
                                AND T1.TM <
                                    TO_DATE(DT || ' 08:01:00',
                                            'yyyy-mm-dd hh24:mi:ss'),
     ST_STBPRP_B T2
     WHERE T3.STCD = T2.STCD
     ORDER BY T3.STCD;
END PLATFORM_BB_SKGZMRBS;


/

