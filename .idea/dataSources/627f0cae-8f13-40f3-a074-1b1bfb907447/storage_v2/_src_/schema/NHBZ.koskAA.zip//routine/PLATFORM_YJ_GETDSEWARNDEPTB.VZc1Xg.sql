create procedure      PLATFORM_YJ_GETDSEWARNDEPTB(STCDS    VARCHAR, --测站编码串
                                               VJTYPE CHAR,
                                               CURR1     OUT PLATFORM.CURSOR ) is
  /**
  *AUTHOR:TICHSTAR
  *DESCRIPTION:预警短信规则
  *DATE:2013年7月23日10:20:50
  */

begin
  OPEN CURR1 FOR
        select tt.* from (
           select rtrim(t.stcd) as STCD,
                  sy.label as YJTYPENM,
                  ST.STNM as STNM,
                  d.deptnm as DEPTNM ,
                  b.name as NAME,
                  T.YJTYPE as YJTYPE,
                  T.YJBMID as YJBMID,
                  T.YJRYID as YJRYID,
                  b.MBLPHN as MBLPHN
           from DSE_WARN_DEPT_B T INNER JOIN (SELECT *
                            FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                            PLATFORM_STCD_TYPE))) STT
                  ON T.STCD = STT.STCD
          left join sys_commoncode sy on sy.val = t.yjtype and sy.code = 'yjtype'
          left join st_stbprp_b st on t.stcd = st.stcd
          left join person_b b on b.personcd = t.yjryid
          left join dept_b d on d.deptcd =t.yjbmid
          where 1=1 and t.YJTYPE like '%' || YJTYPE || '%' )  tt order by tt.stcd;
end PLATFORM_YJ_GETDSEWARNDEPTB;


/

