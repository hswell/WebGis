create procedure      PLATFORM_PPTN_YQCX_SS(
  p_stcds VARCHAR,
	p_pageFrom int,
	p_pageTo int,
  result_cursor    OUT PLATFORM.CURSOR
)  AS
-- 雨情查询  今日雨量，昨天雨量查询  zouwei
   dt1 date;
	 dt2 date;
	 d_hour int;--分钟24小时格式
	 d_min int;--分钟24小时格式

begin
  d_hour:=to_number(to_char(sysdate,'hh24'));
  d_min:=to_number(to_char(sysdate,'mi'));

  if (d_hour <=7) or ( d_hour=8 and d_min=0) then
	   begin
      dt1:=TO_DATE(TO_CHAR(sysdate-1, 'YYYY-MM-DD')||' 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
	   end;
	else --08点 到23点
	   begin
			    dt1:=TO_DATE(TO_CHAR(sysdate, 'YYYY-MM-DD')||' 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
	   end;
   end if;

   dt2:=dt1-1;


--今天8时到现在，昨日雨量的累计雨量,不含8时

  OPEN result_cursor FOR

  select  t.stcd,TRIM(TO_CHAR(ROUND(t.drp1, 1), '99999999990.9')) drp1 ,TRIM(TO_CHAR(ROUND(t.drp2, 1), '99999999990.9')) drp2
  ,trim(t.stnm)stnm,t.name,trim(t.stlc) stlc,to_char(t.tm,'yyyy-mm-dd hh24:mi:ss')tm ,t.drp,t.rownum_ rown from (
          select qt.stcd,st.stnm ,nvl(tt.drp1,0) as drp1,nvl(tt.drp2,0) as drp2,dist.name,stlc,sysdate tm,nvl(tt.drp,0) as drp, ROW_NUMBER() OVER(ORDER BY drp1 DESC) AS rownum_ from
           (SELECT * FROM TABLE(CAST(FUNC_SPLITSTRING(p_stcds) AS PLATFORM_STCD_TYPE))) qt left join
          (
              select t1.stcd,
              	     sum(
                       case  when ((sysdate-t1.tm)*24*60)>-60 and ((sysdate-t1.tm)*24*60)<60 then drp else 0 end) drp
            			,sum(
                       case  when ((t1.tm -dt1)*24)>0 and ((t1.tm -dt1)*24)<=24 then drp else 0 end) drp1
            			,sum(
            				   case when ((t1.tm -dt2)*24)>0 and ((t1.tm -dt2)*24)<=24 then t1.drp else 0 end
            			 ) as drp2
            			from DSE_st_PPTN_R t1 inner join
                   (SELECT * FROM TABLE(CAST(FUNC_SPLITSTRING(p_stcds) AS PLATFORM_STCD_TYPE))) t2 on t1.stcd=t2.stcd
                   where t1.tm >dt2 and t1.tm<=sysdate+1/24
                  group by t1.stcd
          )tt on qt.stcd=tt.stcd inner join  ST_STBPRP_B st on qt.stcd=st.stcd
                  left join sys_district dist on dist.adcode=st.addvcd
                  /*left join (
                    --小时最大时间记录
                    select t.stcd,t.tm,t.drp from (
                      select stcd,drp,tm,ROW_NUMBER() OVER(PARTITION BY stcd ORDER BY tm DESC) row_
                       from dse_st_pptn_h where tm >dt1 and tm<=sysdate+1/24
                    )t where  t.row_=1

                 ) h on tt.stcd=h.stcd*/
        )t  where t.rownum_>p_pageFrom and t.rownum_<=p_pageTo;


end PLATFORM_PPTN_YQCX_SS;


/

