create PROCEDURE      PLATFORM_SSJK_MM(VSTNM    VARCHAR,
                                             VADDVCD  VARCHAR,

                                             VMAPTYPE VARCHAR,
                                             CURR     OUT PLATFORM.CURSOR) IS


  -- =============================================
  -- Author:    chenya
  -- Create date: 2014-08-14
  -- Description: 气象信息查询
  -- =============================================
BEGIN

  OPEN CURR FOR
    SELECT T2.STNM,
           T1.STCD,
           'MM' STTP,

           case
             when VMAPTYPE = '2' then
              func_gis_lonmercator(T2.LGTD)
             else
              T2.LGTD
           end LGTD,
           case
             when VMAPTYPE = '2' then
              func_gis_latmercator(T2.LTTD)
             else
              T2.LTTD
           end LTTD,
           T4.MAXSCALE,
           T4.MINSCALE,
           T4.SHOWLABELSCALE,
           T4.BZDETAILSCALE,
           T4.VIFL,
           TO_CHAR(T1.TM, 'yyyy-mm-dd hh24:mi') TM,

           DRPHOUR,
           DRPDAY,
           WD/10 as WD,
           WDHIGHHOUR/10 as WDHIGHHOUR,
           WDLOWHOUR/10 as WDLOWHOUR,
           WDHIGHDAY/10 as WDHIGHDAY,
           WDLOWDAY/10 as WDLOWDAY,
           WIND2MIN,
           WINDR2MIN,
           WIND10MIN,
           WINDR10MIN,
           WIND10MINH,
           WINDR10MINH,
           WINDMAXH,
           WINDRMAXH,
           WIND10MINDAY,
           WINDR10MINDAY,
           WINDMAXDAY,
           WINDRMAXDAY,
            TO_CHAR(getadnm(T2.ADDVCD)) ADNM

      FROM dse_st_weather_real T1
      LEFT JOIN DSE_ST_LABEL_SET T4
        ON RTRIM(T4.STCD) = RTRIM(T1.STCD)
       AND T4.LAYERID = 4, ST_STBPRP_B T2
     WHERE trim(T1.STCD) = trim(T2.STCD)
       and t2.usfl = '1'
       and T2.STNM LIKE '%' || nvl(VSTNM, '') || '%'
       AND T2.ADDVCD LIKE nvl(VADDVCD, '') || '%';

END PLATFORM_SSJK_MM;


/

