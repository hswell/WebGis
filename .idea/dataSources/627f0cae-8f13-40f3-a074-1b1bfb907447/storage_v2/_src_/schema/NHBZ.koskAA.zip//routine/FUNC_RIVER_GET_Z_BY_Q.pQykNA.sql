create FUNCTION      FUNC_RIVER_GET_Z_BY_Q(STCDVALUE IN varchar2,
                                                 QVALUE    IN NUMERIC /*用于关联的参考数据*/)
  RETURN NUMBER IS
  V         NUMERIC(18, 8);
  X1        NUMERIC(18, 8);
  Y1        NUMERIC(18, 8);
  X2        NUMERIC(18, 8);
  Y2        NUMERIC(18, 8);
  X3        NUMERIC(18, 8);
  Y3        NUMERIC(18, 8);
  X4        NUMERIC(18, 8);
  Y4        NUMERIC(18, 8);
  ROWSIZE   INT := 0;
  VARCURSOR SYS_REFCURSOR;
  CURSOR TMPCURSOR IS
    SELECT Z, Q FROM ST_ZQRL_B WHERE 1 = 2;
  R TMPCURSOR%ROWTYPE;
  --根据河道流量计算水位
BEGIN
  IF STCDVALUE IS NULL OR QVALUE IS NULL THEN
    RETURN NULL;
  END IF;

  --游标大小
  OPEN VARCURSOR FOR
    SELECT B.Z, B.Q --Z为水位,Q为流量
      FROM (SELECT *
              FROM (SELECT Z, Q
                      FROM (SELECT Z, Q
                              FROM ST_ZQRL_B
                             WHERE Q >= QVALUE
                               AND STCD = STCDVALUE
                             ORDER BY Q)
                     WHERE ROWNUM <= 2) A1
            UNION ALL

            SELECT Z,
                   CASE
                     WHEN Q = QVALUE THEN
                      Q
                     ELSE
                      Q
                   END AS Q
              FROM (SELECT Z, Q
                      FROM (SELECT Z, Q
                              FROM ST_ZQRL_B
                             WHERE Q <= QVALUE
                               AND STCD = STCDVALUE
                             ORDER BY Q DESC)
                     WHERE ROWNUM <= 2) A2

            ) B
     WHERE B.Q IS NOT NULL
     ORDER BY B.Q;

  LOOP
    FETCH VARCURSOR
      INTO R;
    EXIT WHEN VARCURSOR%NOTFOUND;
    IF ROWSIZE = 0 THEN
      X1 := R.Q;
      Y1 := R.Z;
    ELSIF ROWSIZE = 1 THEN
      X2 := R.Q;
      Y2 := R.Z;
    ELSIF ROWSIZE = 2 THEN
      X3 := R.Q;
      Y3 := R.Z;
    ELSIF ROWSIZE = 3 THEN
      X4 := R.Q;
      Y4 := R.Z;
    END IF;
    ROWSIZE := ROWSIZE + 1;
  END LOOP;

  IF ROWSIZE = 4 THEN
    IF (ABS(X2 - QVALUE) < ABS(X3 - QVALUE)) THEN
      V := FUNC_THREE_SPOT_METHOD(X1, Y1, X2, Y2, X3, Y3, QVALUE);
    ELSE
      V := FUNC_THREE_SPOT_METHOD(X2, Y2, X3, Y3, X4, Y4, QVALUE);
    END IF;
  ELSIF ROWSIZE = 3 THEN
    V := FUNC_THREE_SPOT_METHOD(X1, Y1, X2, Y2, X3, Y3, QVALUE);
  ELSIF ROWSIZE = 2 THEN
    IF X1 >= QVALUE THEN
      V := Y1;
    ELSE
      V := Y2;
    END IF;
  END IF;

  RETURN V;
END FUNC_RIVER_GET_Z_BY_Q;


/

