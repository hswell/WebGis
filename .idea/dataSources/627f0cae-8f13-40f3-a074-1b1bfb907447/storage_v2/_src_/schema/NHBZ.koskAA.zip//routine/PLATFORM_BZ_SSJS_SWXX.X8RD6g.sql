create procedure      PLATFORM_BZ_SSJS_SWXX(STCDS    VARCHAR,
                                                  ST       VARCHAR,
                                                  ET       VARCHAR,
                                                  PAGEFROM INT,
                                                  PAGETO   INT,
                                                  CUR      OUT PLATFORM.CURSOR) is
  STSTR        VARCHAR(20);
  ETSTR        VARCHAR(20);
begin
  STSTR:= ST||' 00:00:00';
  ETSTR:= ET||' 23:59:59';
  OPEN CUR FOR
    SELECT TTTT.*
      FROM (SELECT TTT.*, ROWNUM ROWNUM_
              FROM (SELECT DISTINCT TT.*
                      FROM (SELECT T.STCD,
                                   TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') TM,
                                   T.NSW,
                                   T.WSW,
                                   B.STNM
                              FROM DSE_BZ_RUNINFO_R T
                             INNER JOIN (SELECT *
                                          FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                                          PLATFORM_STCD_TYPE))) S
                                ON S.STCD = T.STCD
                             INNER JOIN ST_STBPRP_B B
                                ON B.STCD = T.STCD
                             WHERE T.TM > TO_DATE(STSTR, 'YYYY-MM-DD HH24:MI:SS')
                               AND T.TM <= TO_DATE(ETSTR, 'YYYY-MM-DD HH24:MI:SS')
                             ORDER BY T.TM DESC) TT ORDER BY TT.TM DESC) TTT) TTTT
     WHERE TTTT.ROWNUM_ > PAGEFROM
       AND TTTT.ROWNUM_ <= PAGETO;
end PLATFORM_BZ_SSJS_SWXX;


/

