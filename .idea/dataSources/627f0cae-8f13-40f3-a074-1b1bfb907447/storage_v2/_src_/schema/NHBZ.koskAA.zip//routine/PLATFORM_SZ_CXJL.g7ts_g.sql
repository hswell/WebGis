create procedure      PLATFORM_SZ_CXJL(szcode    varchar,
                                             xqfl     varchar,
                                             bgtm     varchar,
                                             entm     varchar,
                                             PAGEFROM INT,
                                             PAGETO   INT,
                                             cursor1  OUT PLATFORM.CURSOR) is
begin
  open cursor1 for
    select * from (

         select t1.ennm,t.ennmcd,to_char(t.dntm,'yyyy-mm-dd') dntm,t.dnincd,t.dnincl,t.dninnm
               ,t.dnpr, t.dnds
               , t.rmdnms,t.atid,t.sdfl,t.rma,t.mdps,t.mddt
                ,DECODE(t.dnincd, 'D001','决口','D002','漫溢(漫堤、漫顶)','D003','漏洞','D004','管涌 (泡泉、翻砂、鼓水)',
                        'D005','陷坑(跌窝、塌坑)','D006','滑坡(脱坡)','D007','淘刷','D008','裂缝','D009','崩岸' ,'D010',
                        '渗水(散浸)','D011','浪坎(风浪)','D012','滑动','D013','启闭失灵','D014','闸门破坏','D015',
                        '溃坝','D016','倾覆','D017','应力过大','D018','坍塌','D019','堵塞','D020','基础破坏','D021','消能工破坏',
                        'D022','基础排水失效','D023','洞身破坏','D024','控导') dnincdname
                ,ROW_NUMBER() over(order by t.MDDT) rn
         from TB0908_SLIGVL_044 t ,TB0001_PRNMSR_044 t1 ,TB0901_SLCMIN_044 t2
         where t.ennmcd=t1.ennmcd and t.ennmcd=t2.ennmcd
               and t1.ennm  like '%'||szcode||'%'
               and t.dntm>=to_date(bgtm,'yyyy-mm-dd HH24:MI:SS')
               and t.dntm<=to_date(entm,'yyyy-mm-dd HH24:MI:SS')
               and (xqfl is null or rtrim(t.dnincd)=rtrim(xqfl))
     ) t1 where t1.rn>PAGEFROM and t1.rn<=PAGETO;

end PLATFORM_SZ_CXJL;


/

