create PROCEDURE      PLATFORM_RSVR_WARN_INFO(LV_STCD CHAR,
                                                    LV_TM   DATE,
                                                    LV_RZ   number,
                                                    LV_OTQ  number,
                                                    LV_W    number,
                                                    LV_TYPE CHAR) --A 新增 U 为修改 D为删除
 AS
  -- =============================================
  -- Author:    zouwei
  -- Create date: 2013-06-09
  -- Description: 处理水库站水位报警信息
  -- =============================================
  LV_CKFLZ  number(7, 3); --校核洪水位
  LV_DSFLZ  number(7, 3); --设计洪水位
  LV_HHRZ   number(7, 3); --历史最高库水位
  LV_NORMZ  number(7, 3); --正常高水位
  LV_FSLTDZ number(7, 3); --汛限水位
  LV_HLRZ   number(7, 3); --历史最低库水位
  LV_LAZ    number(7, 3); --低水位告警值 (低于枯警)

  LV_WTYPE VARCHAR(50); --报警类型
  /* LV_CVAL  VARCHAR(10); --当前值字符型值
  LV_WVAL  VARCHAR(10); --报警字符串型*/
  LV_WINFO VARCHAR(100); --报警信息

  LV_CURVAL  number(10, 3); --当前值数字型值
  LV_WARNVAL number(10, 3); --报警数字型

  LV_SNUM_WARN INT;
  LV_STNM      VARCHAR(30);
  LV_STLC      VARCHAR(50);
BEGIN
  IF LV_STCD IS NOT NULL AND LV_TM IS NOT NULL THEN
    BEGIN
      IF LV_TYPE = 'A' OR LV_TYPE = 'U' THEN
        BEGIN
          --修改时先删除原预警记录
          IF LV_TYPE = 'U' THEN
            BEGIN
              DELETE FROM DSE_WARN_INFO
               WHERE STINDEX = 'RR'
                 AND STCD = LV_STCD
                 AND TM = LV_TM;
            END;
          END IF;

          SELECT FSLTDZ, NORMZ, CKFLZ, DSFLZ, HHRZ, HLRZ, LAZ
            INTO LV_FSLTDZ,
                 LV_NORMZ,
                 LV_CKFLZ,
                 LV_DSFLZ,
                 LV_HHRZ,
                 LV_HLRZ,
                 LV_LAZ
            FROM V_RSVR_ST_RSVRFSR_B
           WHERE STCD = LV_STCD;

          --如果汛限水位为null 使用正常高水位代替
          IF LV_FSLTDZ IS NULL THEN
            LV_FSLTDZ := LV_NORMZ;
          END IF;

          --水位大于汛限水位
          IF LV_FSLTDZ IS NOT NULL AND LV_FSLTDZ > 0 AND LV_RZ > LV_FSLTDZ THEN
            BEGIN
              IF LV_CKFLZ IS NOT NULL AND LV_CKFLZ > 0 AND LV_RZ > LV_CKFLZ THEN
                BEGIN
                  LV_WINFO := '超校核洪水位' ||
                              TRIM(TO_CHAR(ROUND(LV_RZ - LV_FSLTDZ, 2),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'C_CKFLZ';
                  /* LV_WVAL    := TRIM(TO_CHAR(ROUND(LV_CKFLZ, 2),
                  '99999999990.99'));*/
                  LV_WARNVAL := LV_CKFLZ;
                END;
              ELSIF LV_DSFLZ IS NOT NULL AND LV_DSFLZ > 0 AND
                    LV_RZ > LV_DSFLZ THEN
                BEGIN
                  LV_WINFO := '超设计洪水位' ||
                              TRIM(TO_CHAR(ROUND(LV_RZ - LV_DSFLZ, 2),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'C_DSFLZ';
                  /*LV_WVAL    := TRIM(TO_CHAR(ROUND(LV_DSFLZ, 2),
                  '99999999990.99'));*/
                  LV_WARNVAL := LV_DSFLZ;
                END;
              ELSIF LV_HHRZ IS NOT NULL AND LV_HHRZ > 0 AND LV_RZ > LV_HHRZ THEN
                BEGIN
                  LV_WINFO := '超历史最高库水位' ||
                              TRIM(TO_CHAR(ROUND(LV_RZ - LV_HHRZ, 2),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'C_HHRZ';
                  /*  LV_WVAL    := TRIM(TO_CHAR(ROUND(LV_HHRZ, 2),
                  '99999999990.99'));*/
                  LV_WARNVAL := LV_HHRZ;
                END;
              ELSIF LV_NORMZ IS NOT NULL AND LV_NORMZ > 0 AND
                    LV_RZ > LV_NORMZ THEN
                BEGIN
                  LV_WINFO := '超正常高水位' ||
                              TRIM(TO_CHAR(ROUND(LV_RZ - LV_NORMZ, 2),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'C_NORMZ';
                  /*LV_WVAL    := TRIM(TO_CHAR(ROUND(LV_NORMZ, 2),
                  '99999999990.99'));*/
                  LV_WARNVAL := LV_NORMZ;
                END;
              ELSE
                BEGIN
                  LV_WINFO := '超汛限水位' ||
                              TRIM(TO_CHAR(ROUND(LV_RZ - LV_FSLTDZ, 2),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'C_FSLTDZ';
                  /*LV_WVAL    := TRIM(TO_CHAR(ROUND(LV_FSLTDZ, 2),
                  '99999999990.99'));*/
                  LV_WARNVAL := LV_FSLTDZ;
                END;
              END IF;
            END;
          ELSE
            BEGIN
              IF LV_HLRZ IS NOT NULL AND LV_HLRZ > 0 AND LV_HLRZ > LV_RZ THEN
                BEGIN
                  LV_WINFO := '低于历史最低库水位' ||
                              TRIM(TO_CHAR(ABS(ROUND(LV_RZ - LV_HLRZ, 2)),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'D_HLRZ';
                  /*  LV_WVAL    := TRIM(TO_CHAR(ROUND(LV_HLRZ, 2),
                  '99999999990.99'));*/
                  LV_WARNVAL := LV_HLRZ;
                END;
              END IF;
              IF LV_LAZ IS NOT NULL AND LV_LAZ > 0 AND LV_LAZ > LV_RZ THEN
                BEGIN
                  LV_WINFO := '低于枯警' ||
                              TRIM(TO_CHAR(ABS(ROUND(LV_RZ - LV_LAZ, 2)),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'D_LAZ';
                  /*LV_WVAL    := TRIM(TO_CHAR(ROUND(LV_LAZ, 2),
                  '99999999990.99'));*/
                  LV_WARNVAL := LV_LAZ;
                END;
              END IF;
            END;
          END IF;

          IF LV_WTYPE IS NOT NULL THEN
            BEGIN
              /*LV_CVAL   := TRIM(TO_CHAR(ROUND(LV_RZ, 2), '99999999990.99'));*/
              LV_CURVAL := LV_RZ;

              SELECT COUNT(STCD)
                INTO LV_SNUM_WARN
                FROM DSE_WARN_INFO
               WHERE STINDEX = 'RR'
                 AND WTYPE = LV_WTYPE
                 AND STCD = LV_STCD
                 AND TM = LV_TM;

              IF LV_SNUM_WARN <= 0 THEN
                BEGIN
                  SELECT STNM, STLC
                    INTO LV_STNM, LV_STLC
                    FROM ST_STBPRP_B
                   WHERE STCD = LV_STCD;
                  INSERT INTO DSE_WARN_INFO
                    (STCD,
                     STNM,
                     STLC,
                     TM,
                     STINDEX,
                     WTYPE,
                     /*CVAL,
                                                               WVAL,*/
                     WINFO,
                     Q,
                     W,
                     CURVAL,
                     WARNVAL)
                  VALUES
                    (LV_STCD,
                     LV_STNM,
                     LV_STLC,
                     LV_TM,
                     'RR',
                     LV_WTYPE,
                     /* LV_CVAL,
                                                               LV_WVAL,*/
                     LV_WINFO,
                     LV_OTQ,
                     LV_W,
                     LV_CURVAL,
                     LV_WARNVAL);
                END;
              END IF;

            END;
          END IF;

          -- DBMS_OUTPUT.PUT_LINE('222');
        END;

        --删除预警信息
      ELSIF LV_TYPE = 'D' THEN
        DELETE FROM DSE_WARN_INFO
         WHERE STINDEX = 'RR'
           AND STCD = LV_STCD
           AND TM = LV_TM;
      END IF;
    END;
  END IF;

EXCEPTION
  --没有配置汛限水位记录时
  WHEN NO_DATA_FOUND THEN
    NULL;

END PLATFORM_RSVR_WARN_INFO;


/

