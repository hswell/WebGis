create procedure      PLATFORM_BZ_PUMPQ(vmodal    varchar,
                                              vangel    varchar,
                                              PAGEFROM INT,
                                             PAGETO   INT,
                                             cursor1   OUT PLATFORM.CURSOR) is
                                             --?? 2014-07-08?? ????????
begin
  open cursor1 for
      select * from(
           select t.waterpump_modal as waterpumpmodal,
                  t.angle,
                  t.praise,
                  t.q,
                  row_number() over( partition by t.waterpump_modal order by t.angle desc) m
                  from dse_pumpq t
                 where  t.waterpump_modal like '%' || vmodal || '%'
                        and t.angle like '%' || vangel || '%'
                 )t
       where   t.m > PAGEFROM
       and t.m <= PAGETO;


        end PLATFORM_BZ_PUMPQ;


/

