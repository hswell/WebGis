create procedure      PLATFORM_BZ_JBXX2(tcode    varchar,
                                             cursor1   OUT PLATFORM.CURSOR) is

                                             --???? 2014-07-08???? ??????????????????
begin
  open cursor1 for
  select a.ennmcd,
                --   to_char(a.infndt, 'yyyy-mm-dd') infndt,
                   a.infndt,
                   a.aduncd,
                   a.adunnm,
                   a.enpl,
                   a.oppr,
                   a.type,
                   a.adunmobile,
                   a.angel,
                   a.lvbslv,
                   a.dlblp,
                   a.bldt,
                   a.opbgtm,
                 --  to_char(a.bldt, 'yyyy-mm-dd HH24:MI:SS') bldt,
                 --  to_char(a.opbgtm, 'yyyy-mm-dd HH24:MI:SS') opbgtm,
                   b.dsincp*1000 as dsincp,
                   b.acincp*1000 as acincp,
                   b.unnb,
                   b.pmtp,
                   b.ddfwlv,
                   b.ddpwlv,
                   b.pmpnmtel,
                   b.dsdrfl,
                   b.avdrfl,
                   b.acdrar,
                   b.iddfwlv,
                   b.iddpwlv,
                   b.dsirdrfl,
                   b.axirdrfl,
                   b.dsirar,
                   b.acirar,
                   b.jscsize,
                   b.cscsize,
                   b.qcsize,
                   c.ogid,
                   c.ennm,
                   c.entyced,m.STCD,r.SZSTCD SZCD,
                   f.id as bsnum,f.filename,f.filepath as newfilepath,ca.filepath,ca.bhid,
                   row_number() over( partition by a.ennmcd order by a.infndt desc) m

              from tb1501_meidscin_044 a left join DSE_TB0001_REMARK_B m on a.ENNMCD=m.ENNMCD left join DSE_BZSZ_REMARK r on m.STCD=r.BZSTCD
               left join sys_common_file f on trim(a.ennmcd) = trim(f.bid)
               left join dse_filecate_com_b ca on f.id = ca.upfileid,
               tb1502_meidsbi_044  b,
               TB0001_PRNMSR_044   c

             where a.ennmcd = b.ennmcd
               and a.infndt = b.infndt
               and a.ennmcd = c.ennmcd
               and a.ennmcd like '%' || tcode || '%';

        end PLATFORM_BZ_JBXX2;


/

