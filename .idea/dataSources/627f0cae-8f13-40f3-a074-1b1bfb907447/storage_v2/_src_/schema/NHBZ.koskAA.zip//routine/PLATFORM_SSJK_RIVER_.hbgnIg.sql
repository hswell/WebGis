create PROCEDURE      PLATFORM_SSJK_RIVER_(VSTNM    VARCHAR,
                                                 VADDVCD  VARCHAR,
                                                 VQY      VARCHAR,
                                                 VTYPE    INTEGER,
                                                 ISWARING VARCHAR,
                                                 CURR     OUT PLATFORM.CURSOR) IS
  RED      VARCHAR(10);
  ORANGE   VARCHAR(10);
  NORMAL   VARCHAR(10);
  RANGE    NUMBER(5, 1);
  VMAPTYPE VARCHAR(20) := '1';
BEGIN

  SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR, maptype
    INTO RED, ORANGE, RANGE, NORMAL, VMAPTYPE
    FROM DSE_WARNING_PARAM;
  --河道水文（水位）站测报的河道水情实时信息
  --ISWARING 用于判断是否报警，''所有，1报警，0非报警。
  --珠三角需求，返回内外江水位流量
  OPEN CURR FOR
    select *
      from (SELECT t8.name STNM,
                    T1.STCD,
                    'ZZ_' STTP,
                    CASE
                      WHEN VMAPTYPE = '2' THEN
                       FUNC_GIS_LONMERCATOR(T2.LGTD)
                      ELSE
                       T2.LGTD
                    END LGTD,
                    CASE
                      WHEN VMAPTYPE = '2' THEN
                       FUNC_GIS_LATMERCATOR(T2.LTTD)
                      ELSE
                       T2.LTTD
                    END LTTD,
                    T4.MAXSCALE,
                    T4.MINSCALE,
                    T4.SHOWLABELSCALE,
                    T4.VIFL,
                    DECODE(T1.in_wptn, '4', '↓', '5', '↑', '6', '→', '--') in_wptn,
                    DECODE(T1.out_wptn, '4', '↓', '5', '↑', '6', '→', '--') out_wptn,
                    TO_CHAR(T1.TM, 'yyyy-mm-dd hh24:mi') TM,
                    TRIM(TO_CHAR(ROUND(T1.in_Z, 2), '99999999990.99')) in_Z,
                    TRIM(TO_CHAR(ROUND(T1.out_z, 2), '99999999990.99')) out_z,
                    FUNC_NUMERIC(T1.in_Q, 3) in_Q,
                    FUNC_NUMERIC(T1.out_Q, 3) out_Q,
                    TRIM(TO_CHAR(ROUND(t3.wrz, 2), '99999999990.99')) wrz,
                    CASE
                      WHEN T1.in_Z IS NULL OR T3.WRZ IS NULL THEN
                       NULL
                      WHEN T1.in_Z >= T3.WRZ OR T3.WRZ - T1.in_Z <= RANGE THEN
                       TRIM(TO_CHAR(ROUND(T1.in_Z - T3.WRZ, 2),
                                    '99999999990.99'))
                      ELSE
                       NULL
                    END CWRZ,
                    CASE
                      WHEN T1.in_Z IS NULL OR T3.WRZ IS NULL THEN
                       NORMAL
                      WHEN T1.in_Z >= T3.WRZ THEN
                       RED
                      WHEN T3.WRZ - T1.in_Z <= RANGE THEN
                       ORANGE
                      ELSE
                       NORMAL
                    END COLOR,
                    case
                     WHEN T1.in_Z >= T3.WRZ THEN
                      '1'
                     ELSE
                      '0'
                   END WARNINGBJ,
                    CASE
                      WHEN T1.in_Z >= T3.WRZ OR T3.WRZ - T1.in_Z <= RANGE THEN
                       t1.in_Z - T3.WRZ + 9999999
                      ELSE
                       T1.in_Z
                    END ORDERBYINDEX
               FROM dse_st_river_kz_real T1
             -- LEFT JOIN ST_STBPRP_B T2 ON T1.STCD = T2.STCD
             --   LEFT JOIN ST_RVFCCH_B T3 ON T1.STCD = T3.STCD
               LEFT JOIN DSE_ST_LABEL_SET T4 ON RTRIM(T4.STCD) =
                                                RTRIM(T1.STCD)
                                            AND T4.LAYERID = 1
             --LEFT JOIN DSE_ST_PPTN_REAL T5 ON T1.STCD = T5.STCD
              , ST_STBPRP_B T2,
              dse_st_stbprp_b_kz t8
               LEFT JOIN ST_RVFCCH_B T3 ON T8.STCD = T3.STCD
              WHERE --T1.id = T8.id
             --关联内江的经伟度、警戒水位
              t1.stcd = t8.newstcd
           and t8.type = '1'
           and t8.stcd = t2.stcd
           and t2.usfl = '1'
           and (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')
           AND (VADDVCD IS NULL OR T2.ADDVCD LIKE VADDVCD || '%')
           AND (T2.RVNM LIKE '%' || CASE VTYPE WHEN 1 THEN NVL(VQY, '') ELSE ''
               END || '%' OR T2.HNNM LIKE '%' || CASE VTYPE WHEN 2 THEN
               NVL(VQY, '') ELSE '' END || '%' OR T2.BSNM LIKE '%' || CASE
               VTYPE WHEN 3 THEN NVL(VQY, '') ELSE ''
               END || '%' OR '10' = '1' || CASE WHEN VQY IS NULL THEN '0' ELSE '' END))
     WHERE WARNINGBJ LIKE '%' || ISWARING || '%'
     ORDER BY ORDERBYINDEX DESC;
END PLATFORM_SSJK_RIVER_;


/

