create PROCEDURE      PLATFORM_RSVR_SS_SQ(STCDS    VARCHAR,
                                                PAGEFROM INT,
                                                PAGETO   INT,
                                                CURR1    OUT PLATFORM.CURSOR) AS
  --水库水情实时信息
  RED    VARCHAR(10);
  ORANGE VARCHAR(10);
  NORMAL VARCHAR(10);
  RANGE  NUMERIC(5, 1);
BEGIN
  SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR
    INTO RED, ORANGE, RANGE, NORMAL
    FROM DSE_WARNING_PARAM;

  OPEN CURR1 FOR
    SELECT TTTTTT.*, ROWNUM
      FROM (SELECT STCD,
                   TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(RZ, 2), '99999999990.99')) RZ,
                   FUNC_NUMERIC(W, 3) W,
                  rtrim(STNM) STNM,
                   ROWNUM ROWNUM_,
                   TRIM(TO_CHAR(ROUND(FSLTDZ, 2), '99999999990.99')) FSLTDZ,
                   TRIM(TO_CHAR(ROUND(CFSLTDZ, 2), '99999999990.99')) CFSLTDZ,
                   COLOR
              FROM (SELECT T1.STCD,
                           T1.TM,
                           T1.RZ,
                           T1.W,
                           NVL(T3.STNM, T1.STCD) STNM,
                           T2.FSLTDZ FSLTDZ,
                           CASE
                             WHEN T1.RZ IS NULL OR T2.FSLTDZ IS NULL THEN
                              NORMAL
                             WHEN T1.RZ >= T2.FSLTDZ THEN
                              RED
                             WHEN T2.FSLTDZ - T1.RZ <= RANGE THEN
                              ORANGE
                             ELSE
                              NORMAL
                           END COLOR,
                           CASE
                             WHEN T1.RZ IS NULL OR T2.FSLTDZ IS NULL THEN
                              NULL
                             WHEN T1.RZ >= T2.FSLTDZ OR
                                  T2.FSLTDZ - T1.RZ <= RANGE THEN
                              TRIM(TO_CHAR(ROUND(T1.RZ - T2.FSLTDZ, 2),
                                           '99999999990.99'))
                             ELSE
                              NULL
                           END CFSLTDZ
                      FROM DSE_ST_RSVR_REAL T1
                     INNER JOIN (SELECT *
                                  FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                                  PLATFORM_STCD_TYPE))) T4 ON T4.STCD =
                                                                              T1.STCD
                      LEFT JOIN ST_STBPRP_B T3 ON T1.STCD = T3.STCD
                      LEFT JOIN V_RSVR_ST_RSVRFSR_B T2 ON T1.STCD = T2.STCD
                     ORDER BY CASE
                                WHEN RZ IS NULL OR FSLTDZ IS NULL THEN
                                 RZ
                                WHEN RZ >= FSLTDZ OR FSLTDZ - RZ <= RANGE THEN
                                 RZ - FSLTDZ + 9999999
                                ELSE
                                 RZ
                              END DESC) TT) TTTTTT
     WHERE ROWNUM_ > PAGEFROM
       AND ROWNUM_ <= PAGETO;

END PLATFORM_RSVR_SS_SQ;


/

