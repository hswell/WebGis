create PROCEDURE      PLATFORM_RIVER_SS_SQ(STCDS    VARCHAR,
                                                 PAGEFROM INT,
                                                 PAGETO   INT,
                                                 CURR1    OUT PLATFORM.CURSOR) AS
  --河道水情实时信息
  RED    VARCHAR(10);
  ORANGE VARCHAR(10);
  NORMAL VARCHAR(10);
  RANGE  NUMERIC(5, 1);
BEGIN

  SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR
    INTO RED, ORANGE, RANGE, NORMAL
    FROM DSE_WARNING_PARAM;

  OPEN CURR1 FOR
    SELECT TTTTTT.*, ROWNUM
      FROM (SELECT WPTN,
                   STCD,
                   TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(Z, 2), '99999999990.99')) Z,
                   FUNC_NUMERIC(Q, 3) Q,
                   rtrim(STNM) STNM,
                   DECODE(WRZ,
                          NULL,
                          '--',
                          TRIM(TO_CHAR(ROUND(WRZ, 2), '99999999990.99'))) WRZ,
                   CASE
                     WHEN WRZ IS NULL THEN
                      ''
                     WHEN Z - WRZ > 0 THEN
                      TRIM(TO_CHAR(ROUND(Z - WRZ, 2), '99999999990.99'))
                     WHEN WRZ - Z > 0 AND WRZ - Z <= RANGE THEN
                      TRIM(TO_CHAR(ROUND(Z - WRZ, 2), '99999999990.99'))
                     ELSE
                      ''
                   END WRZ_,
                   CASE
                     WHEN Z IS NULL OR WRZ IS NULL THEN
                      NORMAL
                     WHEN Z >= WRZ THEN
                      RED
                     WHEN WRZ - Z <= RANGE THEN
                      ORANGE
                     ELSE
                      NORMAL
                   END COLOR,
                   ROWNUM ROWNUM_
              FROM (SELECT DECODE(T1.WPTN,
                                  '4',
                                  '↓',
                                  '5',
                                  '↑',
                                  '6',
                                  '→',
                                  '--') WPTN,
                           T1.STCD,
                           T1.TM,
                           T1.Z,
                           T1.Q,
                           T2.STNM,
                           ROWNUM ROWNUM_,
                           WRZ
                      FROM DSE_ST_RIVER_REAL T1
                     INNER JOIN (SELECT *
                                  FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                                  PLATFORM_STCD_TYPE))) T4 ON T4.STCD =
                                                                              T1.STCD
                      LEFT JOIN ST_RVFCCH_B T3 ON T1.STCD = T3.STCD,
                     ST_STBPRP_B T2
                     WHERE T1.STCD = T2.STCD
                    --ORDER BY NVL(T1.Z - WRZ, T1.Z) DESC) TT
                     ORDER BY CASE
                                WHEN Z IS NULL OR WRZ IS NULL THEN
                                 Z
                                WHEN Z >= WRZ OR WRZ - Z <= RANGE THEN
                                 Z - WRZ + 9999999
                                ELSE
                                 Z
                              END DESC) TTT) TTTTTT
     WHERE ROWNUM_ <= PAGETO
       AND ROWNUM_ > PAGEFROM;

END PLATFORM_RIVER_SS_SQ;


/

