create FUNCTION      FUNC_LKRES_GET_RZ_BY_W(STCDVALUE varchar2,
                                                  WVALUE   /*用于关联的参考数据*/    NUMERIC)
  RETURN NUMBER IS
  V NUMBER(7, 3);
  --根据库容计算水位
  X1        NUMERIC(18, 8);
  Y1        NUMERIC(18, 8);
  X2        NUMERIC(18, 8);
  Y2        NUMERIC(18, 8);
  X3        NUMERIC(18, 8);
  Y3        NUMERIC(18, 8);
  X4        NUMERIC(18, 8);
  Y4        NUMERIC(18, 8);
  ROWSIZE   INT := 0;
  VARCURSOR SYS_REFCURSOR;
  CURSOR TMPCURSOR IS
    SELECT RZ, W FROM ST_ZVARL_B WHERE 1 = 2;
  R TMPCURSOR%ROWTYPE;
BEGIN
  --获取数值对应关系曲线的相关值
  IF WVALUE IS NULL OR STCDVALUE IS NULL THEN
    RETURN NULL;
  END IF;

  OPEN VARCURSOR FOR
    SELECT B.RZ, B.W
      FROM (SELECT RZ, W
              FROM (SELECT RZ, W
                      FROM (SELECT RZ, W
                              FROM ST_ZVARL_B
                             WHERE W >= WVALUE
                               AND STCD = STCDVALUE
                             ORDER BY W)
                     WHERE ROWNUM <= 2) A1
            UNION ALL
            SELECT RZ,
                   CASE
                     WHEN W = WVALUE THEN
                      NULL
                     ELSE
                      W
                   END AS W
              FROM (SELECT *
                      FROM (SELECT RZ, W
                              FROM ST_ZVARL_B
                             WHERE W <= WVALUE
                               AND STCD = STCDVALUE
                             ORDER BY W DESC)
                     WHERE ROWNUM <= 2) A2

            ) B
     WHERE B.W IS NOT NULL
     ORDER BY B.W;

  LOOP
    FETCH VARCURSOR
      INTO R;
    EXIT WHEN VARCURSOR%NOTFOUND;
    IF ROWSIZE = 0 THEN
      X1 := R.W;
      Y1 := R.RZ;
    ELSIF ROWSIZE = 1 THEN
      X2 := R.W;
      Y2 := R.RZ;
    ELSIF ROWSIZE = 2 THEN
      X3 := R.W;
      Y3 := R.RZ;
    ELSIF ROWSIZE = 3 THEN
      X4 := R.W;
      Y4 := R.RZ;
    END IF;
    ROWSIZE := ROWSIZE + 1;
  END LOOP;

  IF ROWSIZE = 4 THEN
    IF (ABS(X2 - WVALUE) < ABS(X3 - WVALUE)) THEN
      V := FUNC_THREE_SPOT_METHOD(X1, Y1, X2, Y2, X3, Y3, WVALUE);
    ELSE
      V := FUNC_THREE_SPOT_METHOD(X2, Y2, X3, Y3, X4, Y4, WVALUE);
    END IF;
  ELSIF ROWSIZE = 3 THEN
    V := FUNC_THREE_SPOT_METHOD(X1, Y1, X2, Y2, X3, Y3, WVALUE);
  ELSIF ROWSIZE = 2 THEN
    IF X1 >= WVALUE THEN
      V := Y1;
    ELSE
      V := Y2;
    END IF;

  END IF;

  RETURN(V);
END FUNC_LKRES_GET_RZ_BY_W;


/

