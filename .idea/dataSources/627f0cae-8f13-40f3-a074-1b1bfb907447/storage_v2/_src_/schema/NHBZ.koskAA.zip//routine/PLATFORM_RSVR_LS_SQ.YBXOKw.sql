create PROCEDURE      PLATFORM_RSVR_LS_SQ(STCDS    VARCHAR,
                                                ST       VARCHAR,
                                                ET       VARCHAR,
                                                PAGEFROM INT,
                                                PAGETO   INT,
                                                CURR1    OUT PLATFORM.CURSOR) AS
  --水库水情历史信息
BEGIN
  OPEN CURR1 FOR
    SELECT TTT.*, NVL(SYS_DISTRICT.NAME, TTT.ADDVCD) ADDVNM, ROWNUM
      FROM (SELECT TT.STCD,
                   TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(RZ, 2), '99999999990.99')) RZ,
                   FUNC_NUMERIC(W, 3) W,
                   NVL(T2.STNM, TT.STCD) STNM,
                   T2.ADDVCD,
                   ROWNUM_
              FROM (SELECT T1.STCD,
                           T1.TM,
                           T1.RZ,
                           T1.W,

                           ROWNUM ROWNUM_
                      FROM DSE_ST_RSVR_R T1
                     INNER JOIN (SELECT *
                                  FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                                  PLATFORM_STCD_TYPE))) T4 ON T4.STCD =
                                                                              T1.STCD
                     WHERE T1.TM >= TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss')
                       AND T1.TM < TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss')

                     ORDER BY T1.STCD, T1.TM DESC) TT
              LEFT JOIN ST_STBPRP_B T2 ON TT.STCD = T2.STCD
             WHERE ROWNUM_ <= PAGETO) TTT
      LEFT JOIN SYS_DISTRICT ON TTT.ADDVCD = SYS_DISTRICT.ADCODE
     WHERE ROWNUM_ > PAGEFROM;

END PLATFORM_RSVR_LS_SQ;


/

