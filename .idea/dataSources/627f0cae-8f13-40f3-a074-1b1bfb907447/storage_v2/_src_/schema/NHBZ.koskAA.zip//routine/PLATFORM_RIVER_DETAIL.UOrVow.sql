create PROCEDURE      PLATFORM_RIVER_DETAIL(VSTCD VARCHAR,
                                                  ST    VARCHAR,
                                                  ET    VARCHAR,
                                                  CURR1 OUT PLATFORM.CURSOR,
                                                  CURR2 OUT PLATFORM.CURSOR,
                                                  CURR3 OUT PLATFORM.CURSOR) IS
  VST DATE;
  VET DATE;
BEGIN
  VST := TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss');
  VET := TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss');
  --河道站测报的水情信息
  OPEN CURR1 FOR
    SELECT TTT.*, ROWNUM
      FROM (SELECT TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(Z, 2), '99999999990.99')) Z,
                   FUNC_NUMERIC(Q, 3) Q
              FROM DSE_ST_RIVER_R
             WHERE TM >= VST
               AND TM <= VET
               AND STCD = VSTCD
             ORDER BY TM DESC) TTT;

  --河道站测报的雨量信息
  OPEN CURR2 FOR
    SELECT TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
           TRIM(TO_CHAR(ROUND(DRP, 1), '99999999990.9')) DRP
      FROM DSE_ST_PPTN_H
     WHERE TM > VST
       AND TM <= VET
       AND STCD = VSTCD
     ORDER BY TM DESC;

  --警戒水位
  OPEN CURR3 FOR
    SELECT WRZ FROM ST_RVFCCH_B T WHERE STCD = VSTCD;
END PLATFORM_RIVER_DETAIL;


/

