create procedure      PLATFORM_RIVER_MOD_DAYH_Z
(
	D_TIME  date
)
-- =============================================
-- Author:		zouwei
-- Create date: 2013-09-13
-- Description:	修补河道前3日各小时水位
-- =============================================
is
H_TIME  date;
START_TIME  date;--开始时间
END_TIME  date;--结束时间
begin


	if D_TIME is null then
        begin
  			    H_TIME:=to_date(to_char(sysdate,'yyyy-mm-dd hh24')||':00:00','yyyy-mm-dd hh24:mi:ss');
        end;
    else
    		begin
    			  H_TIME:=to_date(to_char(D_TIME,'yyyy-mm-dd hh24')||':00:00','yyyy-mm-dd hh24:mi:ss');
    		end;
    end if;

	END_TIME:=H_TIME-1;
	START_TIME:=END_TIME-3;

  while START_TIME<=END_TIME LOOP
		begin
  			insert into DSE_ST_RIVER_H(stcd,tm,z,q)
    				select tab.STCD,START_TIME,tab.Z,tab.Q from (
    					select tb.*,ROW_NUMBER() OVER (PARTITION BY tb.stcd ORDER BY tb.IDX asc) AS ROWN  from (
    					 select rsv.STCD,rsv.Z,rsv.Q,rsv.TM,abs((START_TIME-TM)*24*60)IDX
    						from  DSE_ST_RIVER_R  rsv inner join
    						(
    							select t.STCD from
    							(
    								 select r.STCD,h.stcd STCDH from dse_st_river_real r
    								  inner join ST_STBPRP_B b on r.STCD=b.STCD and b.USFL='1'
    									  left join
    										 (
    										   select stcd from DSE_ST_RIVER_H where  TM=START_TIME group by stcd
    										 ) h on r.STCD=h.stcd
    							) t where t.STCDH is null
    						) st on rsv.STCD= st.STCD where TM >START_TIME-1/24
    								 and TM <START_TIME+1/24
    								  and rsv.Z is not null

    					)  tb
    				) tab  where tab.ROWN=1 ;

  			START_TIME:=START_TIME+1/24;
      end;
		end LOOP;

end PLATFORM_RIVER_MOD_DAYH_Z;


/

