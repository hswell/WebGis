create view V_TB1502_MEIDSBI as
select
  /**
    *AUTHOR:CHENHX
    *CTEATEDATE:2013年7月12日18:00:46
    *DESCRIPTION:查询泵站最新资料时间
  */
   tt."ENNMCD",tt."INFNDT",tt."DSINCP",tt."ACINCP",tt."UNNB",tt."PMTP",tt."DDFWLV",tt."DDPWLV",tt."PMPNMTEL",tt."DSDRFL",tt."AVDRFL",tt."ACDRAR",tt."IDDFWLV",tt."IDDPWLV",tt."DSIRDRFL",tt."AXIRDRFL",tt."DSIRAR",tt."ACIRAR",tt."RM",tt."ATID",tt."SDFL",tt."RMA",tt."MDPS",tt."MDDT",tt."RNUM",b.stcd from (select t.*,row_number()over(partition by t.ennmcd order by t.INFNDT desc)rnum from TB1502_MEIDSBI_044 t)tt
    ,DSE_TB0001_REMARK_B b where tt.ennmcd = b.ennmcd and tt.rnum = 1


/

