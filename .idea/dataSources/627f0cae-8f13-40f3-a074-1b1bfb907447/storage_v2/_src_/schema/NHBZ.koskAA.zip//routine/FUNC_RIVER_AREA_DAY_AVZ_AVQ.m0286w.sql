create function      func_river_area_day_avz_avq(p_stcd varchar,P_TM date)
  return PLATFORM_RIVER_RSVR_TYPE is
  result_value PLATFORM_RIVER_RSVR_TYPE;--返回结果值表

	V_AVZVAL numeric(7,3);--平均水位
	V_AVQVAL numeric(9,3);--平均流量
	v_time date; --查询时间 0-0时
  v_time_1 date;--查询时间前一天时间点
  check_count int;--用于检测表中记录是否存在
  --临时数据表
  temp_table PLATFORM_RIVER_RSVR_TYPE;


	vag_z numeric(18,3); --统计区间计算水位和

	vag_q numeric(18,3);--统计区间计算流量和


begin
     temp_table:= PLATFORM_RIVER_RSVR_TYPE();
     result_value:=PLATFORM_RIVER_RSVR_TYPE();
     vag_z:=0;
     vag_q:=0;
   IF p_stcd IS NULL OR P_TM IS NULL THEN
       result_value.EXTEND;
       result_value(result_value.count):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,v_time,null,null,null,null);
      return(result_value);
   END IF;

   v_time:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM-dd') || ' 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
   v_time_1:=v_time-1;

   declare cursor  cursor_data  is  select STCD,TM,Z,Q from dse_st_river_r where  stcd=p_stcd and tm>=v_time_1 and tm <=v_time order by tm asc;
      begin
          FOR data_row IN cursor_data LOOP
               temp_table.EXTEND;
               temp_table(temp_table.COUNT):=PLATFORM_RIVER_RSVR_TABLE(data_row.stcd,to_date(to_char(data_row.tm,'yyyy-mm-dd hh24:mi')||':00','yyyy-mm-dd hh24:mi:ss'),data_row.z,data_row.q,null,null);
          END LOOP;
      end;

      --起始时间不存在
      select count(1) into check_count from table(temp_table) where TM=v_time_1;
      if check_count=0 then
         begin
              declare time_z numeric(7,3); --线性插值获得水位
        			        time_q numeric(9,3); --线性插值获得流量
        			        qs_bf_tm date ; --起始时间前一条记录时间
        			        qs_bf_z numeric(7,3);--起始时间前一条记录水位
        			        qs_bf_q numeric(9,3); --起始时间前一条记录流量
        			        qs_af_tm date ;   --起始时间后一条记录时间
        			        qs_af_z numeric(7,3);--起始时间后一条记录水位
        			        qs_af_q numeric(9,3);--起始时间后一条记录流量
               begin
                    --起始时间前一条记录
                   select max(tm),max(z),max(q) into qs_bf_tm,qs_bf_z,qs_bf_q from (
                       select tm,z,q,row_number() over(order by tm desc) rown from dse_st_river_r where  tm>add_months(v_time_1,-1) and tm <v_time_1 and stcd=p_stcd
			             )t  where t.rown=1 ;
                   --起始时间后一条记录
                   select max(tm),max(z),max(q) into qs_af_tm,qs_af_z,qs_af_q from (
                       select tm,z,q,row_number() over(order by tm asc) rown from dse_st_river_r where  tm>v_time_1 and tm <add_months(v_time_1,1) and stcd=p_stcd
			             )t  where t.rown=1 ;

                   --前后水位记录存在
              		 if 	qs_bf_z is not null and qs_af_z is not null then
              				begin
              				    --线性插值发获取到当前水位流量值
              				    --y=y0+(x-x0)(y1-y0)/x1-x0
              				    time_z :=qs_bf_z+(qs_af_z-qs_bf_z)*((v_time_1-qs_bf_tm)*24)/((qs_af_tm-qs_bf_tm)*24);
              				   if time_z is not null then
                						begin
                							time_z :=round(time_z,2);
                						end;
                         end if;
              					--线性插值取得流量
              					 time_q :=qs_bf_q+(qs_af_q-qs_bf_q)*((v_time_1-qs_bf_tm)*24)/((qs_af_tm-qs_bf_tm)*24);
              				   if time_q is not null then
                						begin
                							  time_q :=round(time_q,3);
                						end;
                          end if;
              				end;
                   end if;

                   --无法计算到起始水位
            			 if time_z is null then
              				 begin

                           select round(avg(Z),2),round(avg(Q),3) into vag_z,vag_q from dse_st_river_r where  stcd=p_stcd and tm>v_time_1 and tm <=v_time ;
              					   result_value.EXTEND;
                           result_value(result_value.count):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,v_time,vag_z,vag_q,null,null);
                           return(result_value);
              				 end;
            			  else
            				   begin
            					     temp_table.EXTEND;
                           temp_table(temp_table.COUNT):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,v_time_1,time_z,time_q,null,null);
            				   end;
                   end if;

               end;
         end;
      end if;

     check_count:=null;
     --截止时间记录不存在
      select count(1) into check_count from table(temp_table) where TM=v_time;
      if check_count=0 then
         begin
              declare end_time_z numeric(7,3); --线性插值获得水位
			           end_time_q numeric(9,3); --线性插值获得流量
		          	 end_bf_tm date;  --截止时间前一条记录时间
			           end_bf_z numeric(7,3);--截止时间前一条记录水位
			           end_bf_q numeric(9,3); --截止时间前一条记录流量
			           end_af_tm date;    --截止时间后一条记录时间
			           end_af_z numeric(7,3);--截止时间后一条记录水位
			           end_af_q numeric(9,3);--截止时间后一条记录流量
                 begin
                     --截止时间前一条记录
                   select max(tm),max(z),max(q) into end_bf_tm,end_bf_z,end_bf_q from (
                       select tm,z,q,row_number() over(order by tm desc) rown from dse_st_river_r where  tm>add_months(v_time,-1) and tm <v_time and stcd=p_stcd
			             )t  where t.rown=1 ;
                   --截止时间后一条记录
                   select max(tm),max(z),max(q) into end_af_tm,end_af_z,end_af_q from (
                       select tm,z,q,row_number() over(order by tm asc) rown from dse_st_river_r where  tm>v_time and tm <add_months(v_time,1) and stcd=p_stcd
			             )t  where t.rown=1 ;


			           --前后水位不记录存在
            			if 	end_bf_z is not null and end_bf_z is not null then
            				 begin
            				    --线性插值发获取到当前水位流量值
            				    --y=y0+(x-x0)(y1-y0)/x1-x0
            				    end_time_z :=end_bf_z+(end_af_z-end_bf_z)*((v_time-end_bf_tm)*24)/((end_af_tm-end_bf_tm)*24);
            				   if end_time_z is not null then
              						begin
              							 end_time_z :=round(end_time_z,2);
              						end;
                        end if;
            					--线性插值取得流量
            					   end_time_q :=end_bf_q+(end_af_q-end_bf_q)*((v_time-end_bf_tm)*24)/((end_af_tm-end_bf_tm)*24);
            				     if end_time_q is not null then
              						  begin
              							    end_time_q:=round(end_time_q,3);
              						  end;
                          end if;
            				end;
                  end if;

                   --无法计算到起始水位
            			 if end_time_z is null then
              				 begin
                            select round(avg(Z),2),round(avg(Q),3) into vag_z,vag_q from dse_st_river_r where  stcd=p_stcd and tm>v_time_1 and tm <=v_time ;
              					   result_value.EXTEND;
                           result_value(result_value.count):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,v_time,vag_z,vag_q,null,null);
                           return(result_value);
              				 end;
            			  else
            				   begin
            					     temp_table.EXTEND;
                           temp_table(temp_table.COUNT):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,v_time,end_time_z,end_time_q,null,null);
            				   end;
                   end if;


               end;
         end;
      end if;



   FOR cur_temp in (select TM,AVZ,AVQ from table(temp_table) order by tm asc) LOOP
      BEGIN

         declare bf_time date;
				         af_time date;
             begin
                   select max(tm) into bf_time from (
                       select tm,row_number() over(order by tm desc) rown from table(temp_table) where  tm <cur_temp.tm
			             )t  where t.rown=1 ;

                   select max(tm) into af_time from (
                       select tm,row_number() over(order by tm asc) rown from table(temp_table) where  tm>cur_temp.tm
			             )t  where t.rown=1 ;

                   if bf_time is null then
            					begin
            						 bf_time:=cur_temp.tm;
            					end;
                   end if;

            			if af_time is null then
            					begin
            						  af_time:=cur_temp.tm;
            					end;
                   end if;

               if cur_temp.avz is not null and cur_temp.avz>0 then
        					begin
                       --乘时间分钟差
        						   vag_z:=vag_z+cur_temp.avz*((af_time-bf_time)*24*60);

        					end;
        				end if;
        				if cur_temp.avq is not null and cur_temp.avq>0 then
          					begin
          						vag_q:=vag_q+cur_temp.avq*((af_time-bf_time)*24*60);
          					end;
                end if;

              end;


      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
   END LOOP;

   if vag_z >0 then
		   begin
		       V_AVZVAL:=round(vag_z/(2*60*24),2);
		   end;
   end if;
   if vag_q >0 then
		  begin
			    V_AVQVAL:=round(vag_q/(2*60*24),3);
	    end;
   end if;

   result_value.EXTEND;
   result_value(result_value.count):=PLATFORM_RIVER_RSVR_TABLE(p_stcd,v_time,V_AVZVAL,V_AVQVAL,null,null);

  return(result_value);
end func_river_area_day_avz_avq;


/

