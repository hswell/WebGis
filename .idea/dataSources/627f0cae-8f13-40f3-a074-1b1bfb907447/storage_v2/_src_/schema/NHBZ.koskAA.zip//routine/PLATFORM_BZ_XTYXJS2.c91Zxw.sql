create procedure      PLATFORM_BZ_XTYXJS2(STCDS    VARCHAR, --测站编码串
                                               CURR1     OUT PLATFORM.CURSOR,
                                               CURR2     OUT PLATFORM.CURSOR,
                                               CURR3     OUT PLATFORM.CURSOR,
                                               CURR4     OUT PLATFORM.CURSOR ) is
  /**
  *AUTHOR:TICHSTAR
  *DESCRIPTION:泵站系统运行监视数据查询
  *DATE:2013年7月23日10:20:50
  */
begin
  OPEN CURR1 FOR
    SELECT TT.*
      FROM (SELECT

                   T.JZSTATE,
                   T.STCD
              FROM (SELECT          D.STCD,
                                    D.AIRCREWSTATE as JZSTATE
                      FROM DSE_BZ_RUNINFO_REAL D) T
             INNER JOIN (SELECT *
                          FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                          PLATFORM_STCD_TYPE))) ST
                ON T.STCD = ST.STCD
             INNER JOIN ST_STBPRP_B B
                ON T.STCD = B.STCD
             ) TT;


   OPEN CURR2 FOR
         SELECT TTT.*
         FROM (SELECT
                   NT.TOTALSTCDS AS TOTALSTCDS
              FROM (select count(distinct(A.stcd)) AS TOTALSTCDS
                   from DSE_BZ_RUNINFO_REAL A INNER JOIN (SELECT *
                          FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                          PLATFORM_STCD_TYPE))) ST on st.stcd=a.stcd ) NT
                 ) TTT;

   OPEN CURR3 FOR
        SELECT TT.*
        FROM ( SELECT VT.TOTALDSICP,VT.TOTALDSDRFL
         FROM(SELECT  SUM(V.DSINCP)*1000 AS TOTALDSICP,SUM(V.DSDRFL) AS TOTALDSDRFL
                  FROM  V_TB1502_MEIDSBI V  INNER JOIN (SELECT *
                              FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                              PLATFORM_STCD_TYPE))) ST on V.ENNMCD = ST.STCD) VT
              ) TT;

    OPEN CURR4 FOR
           SELECT TB.*
           FROM(SELECT COUNT(TTT.STCD) AS TOTALOPEN FROM (SELECT ST.STCD FROM
           (select  STCD from DSE_BZ_RUNINFO_REAL t  WHERE aircrewstate=1 GROUP BY STCD)ST
           INNER JOIN  (SELECT *
                          FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                          PLATFORM_STCD_TYPE))) B ON ST.STCD = B.STCD) TTT) TB;
end PLATFORM_BZ_XTYXJS2;


/

