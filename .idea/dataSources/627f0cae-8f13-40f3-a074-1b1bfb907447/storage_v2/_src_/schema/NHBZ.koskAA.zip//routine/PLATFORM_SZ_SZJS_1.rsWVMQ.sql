create procedure      PLATFORM_SZ_SZJS_1(VSTCD VARCHAR,
                                               CUR   OUT PLATFORM.CURSOR,
                                               CUR1   OUT PLATFORM.CURSOR) is
begin
  --返回水闸实时状态信息
  OPEN CUR FOR
    SELECT TT.*
      FROM (SELECT T.*,V.ZMNUM,V.ZM3DURL,B.GTORHG
              FROM DSE_SZ_RUNINFO_REAL T,
                   DSE_TB0001_REMARK_B R,
                   V_TB0901_SLCMIN     V,
                   TB0909_SLIGVL_044 B
             WHERE T.STCD = VSTCD AND T.STCD = R.STCD
               AND V.ENNMCD = R.ENNMCD AND V.ENNMCD = B.ENNMCD(+) AND V.INFNDT = B.INFNDT(+)) TT;

  --返回闸门坐标信息
  OPEN CUR1 FOR
  SELECT TT1.* FROM (SELECT T.* FROM DSE_TB0909_SLZBXX_B T,V_TB0901_SLCMIN V,DSE_TB0001_REMARK_B R
  WHERE R.STCD = VSTCD AND R.STCD = V.STCD AND T.ENNMCD = V.ENNMCD)TT1;
end PLATFORM_SZ_SZJS_1;


/

