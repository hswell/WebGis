create PROCEDURE      PLATFORM_RIVER_CX_YJ(STCDS    VARCHAR,
                                                 ST       VARCHAR,
                                                 ET       VARCHAR,
                                                 PAGEFROM INT,
                                                 PAGETO   INT,
                                                 CURR1    OUT PLATFORM.CURSOR)
--河道预警值查询
 AS
BEGIN

  --pp 雨量报警   RR 水库报警  zz河道报警
  --wtype  报警类型 CURVAL 当前值  WARNVAL 报警值（超过就报警）
  OPEN CURR1 FOR
    SELECT TTTTTT.*, ROWNUM
      FROM (SELECT STCD,
                   rtrim(STNM) STNM,
                   TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                   WINFO,
                   TRIM(TO_CHAR(ROUND(WARNVAL, 2), '99999999990.99')) WVAL,
                   TRIM(TO_CHAR(ROUND(CURVAL, 2), '99999999990.99')) CVAL,
                   FUNC_NUMERIC(Q, 3) Q,
                   ROWNUM_
              FROM (SELECT T1.STCD,
                           T1.STNM,
                           T1.TM,
                           T1.WINFO,
                           T1.WARNVAL,
                           T1.CURVAL,
                           T1.Q,
                           ROWNUM ROWNUM_
                      FROM DSE_WARN_INFO T1
                     INNER JOIN (SELECT *
                                  FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                                  PLATFORM_STCD_TYPE))) T2 ON T2.STCD =
                                                                              T1.STCD
                     WHERE T1.TM >= TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss')
                       AND T1.TM < TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss')
                       AND T1.STINDEX = 'ZZ'
                     ORDER BY T1.STCD, T1.TM DESC)
             WHERE ROWNUM_ <= PAGETO) TTTTTT
     WHERE ROWNUM_ > PAGEFROM;

END PLATFORM_RIVER_CX_YJ;


/

