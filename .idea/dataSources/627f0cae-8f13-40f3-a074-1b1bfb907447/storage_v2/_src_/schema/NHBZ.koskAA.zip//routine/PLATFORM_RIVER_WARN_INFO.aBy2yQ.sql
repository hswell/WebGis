create PROCEDURE      PLATFORM_RIVER_WARN_INFO(LV_STCD CHAR,
                                                     LV_TM   DATE,
                                                     LV_Z    number,
                                                     LV_Q    number,
                                                     LV_TYPE CHAR) --A 新增 U 为修改 D为删除
 AS
  -- Author:   zouwei
  -- Create date: 2013-06-09
  -- Description: 处理河道站水位报警信息
  LV_OBHTZ number(7, 3); --超历史最高水位
  LV_GRZ   number(7, 3); --保证水位
  LV_WRZ   number(7, 3); --警戒水位
  LV_HLZ   number(7, 3); --历史最低水位
  LV_LAZ   number(7, 3); --低水位告警值

  LV_WTYPE VARCHAR(50); --报警类型
  /*  LV_CVAL  VARCHAR(10); --当前值字符型值
  LV_WVAL  VARCHAR(10); --报警字符型*/
  LV_WINFO VARCHAR(100); --报警信息

  LV_CURVAL  number(10, 3); --当前值数字型值
  LV_WARNVAL number(10, 3); --报警数字型

  LV_SNUM_WARN INT;
  LV_STNM      VARCHAR(30);
  LV_STLC      VARCHAR(50);
BEGIN
  IF LV_STCD IS NOT NULL AND LV_TM IS NOT NULL THEN
    BEGIN
      IF LV_TYPE = 'A' OR LV_TYPE = 'U' THEN
        BEGIN
          IF LV_TYPE = 'U' THEN
            DELETE FROM DSE_WARN_INFO
             WHERE STINDEX = 'ZZ'
               AND STCD = LV_STCD
               AND TM = LV_TM;
          END IF;

          SELECT GRZ, OBHTZ, WRZ, HLZ, LAZ
            INTO LV_GRZ, LV_OBHTZ, LV_WRZ, LV_HLZ, LV_LAZ
            FROM ST_RVFCCH_B
           WHERE STCD = LV_STCD;

          IF LV_WRZ IS NOT NULL AND LV_WRZ > 0 AND LV_Z > LV_WRZ THEN
            BEGIN
              IF LV_OBHTZ IS NOT NULL AND LV_OBHTZ > 0 AND LV_Z > LV_OBHTZ THEN
                BEGIN
                  LV_WINFO := '超历史最高水位' ||
                              TRIM(TO_CHAR(ABS(ROUND(LV_Z - LV_OBHTZ, 2)),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'C_OBHTZ';
                  /* set @WVAL = convert(varchar(10),convert(numeric(7,2),@OBHTZ))*/
                  LV_WARNVAL := LV_OBHTZ;
                END;
              ELSIF LV_GRZ IS NOT NULL AND LV_GRZ > 0 AND LV_Z > LV_GRZ THEN
                BEGIN
                  LV_WINFO := '超保证水位' ||
                              TRIM(TO_CHAR(ABS(ROUND(LV_Z - LV_GRZ, 2)),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'C_GRZ';
                  /* set @WVAL = convert(varchar(10),convert(numeric(7,2),@GRZ))*/
                  LV_WARNVAL := LV_GRZ;
                END;
              ELSIF LV_WRZ IS NOT NULL AND LV_WRZ > 0 AND LV_Z > LV_WRZ THEN
                BEGIN
                  LV_WINFO := '超警戒水位' ||
                              TRIM(TO_CHAR(ABS(ROUND(LV_Z - LV_WRZ, 2)),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'C_WRZ';
                  /*set @WVAL = convert(varchar(10),convert(numeric(7,2),@WRZ))*/
                  LV_WARNVAL := LV_WRZ;
                END;
              END IF;
            END;
          ELSE
            BEGIN
              IF LV_HLZ IS NOT NULL AND LV_HLZ > 0 AND LV_HLZ > LV_Z THEN
                BEGIN
                  LV_WINFO := '低于历史最低水位' ||
                              TRIM(TO_CHAR(ABS(ROUND(LV_Z - LV_HLZ, 2)),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'D_HLRZ';
                  /* set @WVAL = convert(varchar(10),convert(numeric(7,2),@HLZ))*/
                  LV_WARNVAL := LV_HLZ;
                END;
              END IF;
              IF LV_LAZ IS NOT NULL AND LV_LAZ > 0 AND LV_LAZ > LV_Z THEN
                BEGIN
                  LV_WINFO := '低于枯警' ||
                              TRIM(TO_CHAR(ABS(ROUND(LV_Z - LV_LAZ, 2)),
                                           '99999999990.99')) || 'm';
                  LV_WTYPE := 'D_LAZ';
                  /* set @WVAL = convert(varchar(10),convert(numeric(7,2),@LAZ))*/
                  LV_WARNVAL := LV_LAZ;
                END;
              END IF;
              DBMS_OUTPUT.PUT_LINE('333');

            END;
          END IF;
        END;
        IF LV_WTYPE IS NOT NULL THEN
          BEGIN
            /*lv_CVAL = convert(varchar(10),convert(numeric(7,2),@Z));*/
            LV_CURVAL := LV_Z;

            SELECT COUNT(STCD)
              INTO LV_SNUM_WARN
              FROM DSE_WARN_INFO
             WHERE STINDEX = 'ZZ'
               AND WTYPE = LV_WTYPE
               AND STCD = LV_STCD
               AND TM = LV_TM;

            IF LV_SNUM_WARN <= 0 THEN
              BEGIN
                SELECT STNM, STLC
                  INTO LV_STNM, LV_STLC
                  FROM ST_STBPRP_B
                 WHERE STCD = LV_STCD;

                INSERT INTO DSE_WARN_INFO
                  (STCD,
                   STNM,
                   STLC,
                   TM,
                   STINDEX,
                   WTYPE,
                   /* CVAL,
                                                                                                                                                                           WVAL,*/
                   WINFO,
                   Q,
                   CURVAL,
                   WARNVAL)
                VALUES
                  (LV_STCD,
                   LV_STNM,
                   LV_STLC,
                   LV_TM,
                   'ZZ',
                   LV_WTYPE,
                   /* LV_@CVAL,
                                                                                                                                                                           LV_@WVAL,*/
                   LV_WINFO,
                   LV_Q,
                   LV_CURVAL,
                   LV_WARNVAL);
              END;
            END IF;
          END;
        END IF;
      ELSIF LV_TYPE = 'D' THEN
        DELETE FROM DSE_WARN_INFO
         WHERE STINDEX = 'ZZ'
           AND STCD = LV_STCD
           AND TM = LV_TM;
      END IF;
    END;
  END IF;
EXCEPTION
  --没有配置防洪指标记录时
  WHEN NO_DATA_FOUND THEN
    NULL;
END PLATFORM_RIVER_WARN_INFO;


/

