create procedure      PLATFORM_SZ_JBXX(tcode    varchar,
                                             tname    varchar,
                                             bgtm     varchar,
                                             entm     varchar,
                                             PAGEFROM INT,
                                             PAGETO   INT,
                                             cursor1  OUT PLATFORM.CURSOR) is
begin
  open cursor1 for
    select *
      from (select t2.ennm,
                   t1.ennmcd,
                   to_char(t1.infndt, 'yyyy-mm-dd hh24:mi:ss') infndt,
                   t1.aduncd,
                   t1.adunnm,
                   to_char(t1.bldt, 'yyyy-mm-dd') bldt,
                   to_char(t1.opbgtm, 'yyyy-mm-dd') opbgtm,
                   t1.gtcl,
                   decode(t1.gtcl,'1','大型','2','中型','3','小型') gtclnm,
                   t1.lvbslv,
                   t1.dlblp,
                   t1.dsin,
                   t1.astkbin,
                   t1.rm,
                   t1.atid,
                   t1.sdfl,
                   t1.rma,
                   t1.mdps,
                   t1.mddt,
                   t1.zmnum,
                   t1.isimp,
                   decode(t1.isimp,'1','是','0','否') ISIMPNM,
                   t1.zm3durl, m.stcd,
                   row_number() over(order by t1.ennmcd) rn
              from TB0901_SLCMIN_044 t1 left join dse_tb0001_remark_b m on t1.ennmcd=m.ennmcd ,TB0001_PRNMSR_044 t2
              where t1.ennmcd=t2.ennmcd  and t1.ennmcd like '%' || tcode || '%'
                    and t2.ennm like '%' || tname || '%'
                    and t1.infndt>=to_date(bgtm,'yyyy-mm-dd HH24:MI:SS')
                    and t1.infndt<=to_date(entm,'yyyy-mm-dd HH24:MI:SS')
              ) t2
     where t2.rn > PAGEFROM
       and t2.rn <= PAGETO;
end PLATFORM_SZ_JBXX;


/

