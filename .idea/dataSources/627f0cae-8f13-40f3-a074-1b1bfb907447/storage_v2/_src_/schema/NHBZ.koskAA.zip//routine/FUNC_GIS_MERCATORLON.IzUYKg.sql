create function      FUNC_GIS_Mercatorlon(x NUMBER) return number is
  Result number;
  --createTime 2013-08-16
  --author chenya
  --墨卡托转经度
begin
  Result:=x/20037508.34*180;
  return(Result);
end FUNC_GIS_Mercatorlon;


/

