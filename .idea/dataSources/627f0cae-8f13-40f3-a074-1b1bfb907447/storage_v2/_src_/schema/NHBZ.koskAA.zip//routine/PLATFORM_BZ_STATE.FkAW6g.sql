create PROCEDURE      PLATFORM_BZ_STATE(VSTCD VARCHAR,
                                               ST    VARCHAR,
                                               ET    VARCHAR,
                                               CURR1 OUT PLATFORM.CURSOR) IS
  VST DATE;
  VET DATE;
BEGIN
  VST := TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss');
  VET := TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss');
   --船闸状态

  OPEN CURR1 FOR
    SELECT TT.*, ROWNUM
      FROM ( SELECT distinct s.STCD,b.STNM, TO_CHAR(TM, 'yyyy-mm-dd hh24:mi:ss') TM,STATE,
            DECODE(STATE, '1', '开', '0', '关', '故障') STATENAME,
              N1 ,
           N2,
           N3 ,
           N4,
           N5 ,
           N6
              FROM dse_bz_runstate_r s, st_stbprp_b b
              where s.stcd=b.stcd
              AND TM >= VST
               AND TM <= VET
              AND s.STCD= VSTCD
             ORDER BY stcd,TM asc) TT;


END PLATFORM_BZ_STATE;


/

