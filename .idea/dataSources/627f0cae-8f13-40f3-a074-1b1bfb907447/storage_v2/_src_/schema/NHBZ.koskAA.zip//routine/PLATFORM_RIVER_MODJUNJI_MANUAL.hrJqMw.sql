create procedure      PLATFORM_RIVER_MODJUNJI_MANUAL (
  STARTTIME  DATE,
  ENDTIME DATE
)
IS
 -- =============================================
-- Author:		zouwei
-- Create date: 2014-01-03
-- Description:	河道水位均值极值数据修复 手动执行以便修补之前遗漏或者统计有
--问题的数据
-- =============================================
startt date;
endt  date;

begin
    if (STARTTIME is null or ENDTIME is null) then
       begin
             return;
       end;
     end if;


     startt:=to_date(to_char(STARTTIME,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss');
     endt:=to_date(to_char(ENDTIME,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss');

     WHILE startt <= endt loop

			  platform_river_jiz_tj(startt);

			  PLATFORM_RIVER_JUNZ_TJ(startt);

			  startt := startt+1;
		END loop;
end PLATFORM_RIVER_MODJUNJI_MANUAL;


/

