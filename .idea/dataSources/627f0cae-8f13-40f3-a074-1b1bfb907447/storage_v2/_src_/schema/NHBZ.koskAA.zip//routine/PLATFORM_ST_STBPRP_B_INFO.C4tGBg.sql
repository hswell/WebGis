create procedure      PLATFORM_ST_STBPRP_B_INFO(

result_pptn_cursor    OUT PLATFORM.CURSOR,
result_river_cursor    OUT PLATFORM.CURSOR,
result_rsvr_cursor    OUT PLATFORM.CURSOR
) is
begin
  --雨量站
  OPEN result_pptn_cursor FOR
  select st.STCD,trim(st.STNM)||'/'||st.STCD STNM,trim(st.RVNM)RVNM,trim(st.HNNM)HNNM,trim(st.BSNM)BSNM,st.LGTD,st.LTTD,st.ADDVCD from
   DSE_ST_PPTN_REAL p inner join ST_STBPRP_B st on p.STCD=st.STCD
   where st.USFL='1';
     --河道站
  OPEN result_river_cursor FOR
   select st.STCD,trim(st.STNM)||'/'||st.STCD STNM,trim(st.RVNM)RVNM,trim(st.HNNM)HNNM,trim(st.BSNM)BSNM,st.LGTD,st.LTTD,st.ADDVCD from
  ST_STBPRP_B st  where (st.STTP='ZZ' or st.STTP='ZQ') and st.USFL='1' ;

    --水库站
   OPEN result_rsvr_cursor FOR
   select st.STCD,trim(st.STNM)||'/'||st.STCD STNM,trim(st.RVNM)RVNM,trim(st.HNNM)HNNM,trim(st.BSNM)BSNM,st.LGTD,st.LTTD,st.ADDVCD from
	 ST_STBPRP_B st  where st.STTP='RR' and st.USFL='1' ;

end PLATFORM_ST_STBPRP_B_INFO;


/

