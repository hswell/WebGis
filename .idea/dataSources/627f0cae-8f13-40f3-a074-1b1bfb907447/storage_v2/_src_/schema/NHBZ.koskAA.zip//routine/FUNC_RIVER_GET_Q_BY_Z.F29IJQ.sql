create FUNCTION      FUNC_RIVER_GET_Q_BY_Z(STCDVALUE IN varchar2,
                                                 ZVALUE    IN NUMERIC /*用于关联的参考数据*/)
  RETURN NUMBER IS
  V         NUMERIC(18, 8);
  X1        NUMERIC(18, 8);
  Y1        NUMERIC(18, 8);
  X2        NUMERIC(18, 8);
  Y2        NUMERIC(18, 8);
  X3        NUMERIC(18, 8);
  Y3        NUMERIC(18, 8);
  X4        NUMERIC(18, 8);
  Y4        NUMERIC(18, 8);
  ROWSIZE   INT := 0;
  VARCURSOR SYS_REFCURSOR;
  CURSOR TMPCURSOR IS
    SELECT Z, Q FROM ST_ZQRL_B WHERE 1 = 2;
  R TMPCURSOR%ROWTYPE;
  --根据河道水位计算流量
BEGIN
  IF STCDVALUE IS NULL OR ZVALUE IS NULL THEN
    RETURN NULL;
  END IF;

  --游标大小
  OPEN VARCURSOR FOR
    SELECT B.Z, B.Q --Z为水位,Q为流量
      FROM (SELECT *
              FROM (SELECT Z, Q
                      FROM (SELECT Z, Q
                              FROM ST_ZQRL_B
                             WHERE Z >= ZVALUE
                               AND STCD = STCDVALUE
                             ORDER BY Z)
                     WHERE ROWNUM <= 2) A1
            UNION ALL

            SELECT CASE
                     WHEN Z = ZVALUE THEN
                      Z
                     ELSE
                      Z
                   END AS Z,
                   Q
              FROM (SELECT Z, Q
                      FROM (SELECT Z, Q
                              FROM ST_ZQRL_B
                             WHERE Z <= ZVALUE
                               AND STCD = STCDVALUE
                             ORDER BY Z DESC)
                     WHERE ROWNUM <= 2) A2

            ) B
     WHERE B.Z IS NOT NULL
     ORDER BY B.Z;

  LOOP
    FETCH VARCURSOR
      INTO R;
    EXIT WHEN VARCURSOR%NOTFOUND;
    IF ROWSIZE = 0 THEN
      X1 := R.Z;
      Y1 := R.Q;
    ELSIF ROWSIZE = 1 THEN
      X2 := R.Z;
      Y2 := R.Q;
    ELSIF ROWSIZE = 2 THEN
      X3 := R.Z;
      Y3 := R.Q;
    ELSIF ROWSIZE = 3 THEN
      X4 := R.Z;
      Y4 := R.Q;
    END IF;
    ROWSIZE := ROWSIZE + 1;
  END LOOP;

  IF ROWSIZE = 4 THEN
    IF (ABS(X2 - ZVALUE) < ABS(X3 - ZVALUE)) THEN
      V := FUNC_THREE_SPOT_METHOD(X1, Y1, X2, Y2, X3, Y3, ZVALUE);
    ELSE
      V := FUNC_THREE_SPOT_METHOD(X2, Y2, X3, Y3, X4, Y4, ZVALUE);
    END IF;
  ELSIF ROWSIZE = 3 THEN
    V := FUNC_THREE_SPOT_METHOD(X1, Y1, X2, Y2, X3, Y3, ZVALUE);
  ELSIF ROWSIZE = 2 THEN
    IF X1 >= ZVALUE THEN
      V := Y1;
    ELSE
      V := Y2;
    END IF;
  END IF;

  RETURN V;
END FUNC_RIVER_GET_Q_BY_Z;


/

