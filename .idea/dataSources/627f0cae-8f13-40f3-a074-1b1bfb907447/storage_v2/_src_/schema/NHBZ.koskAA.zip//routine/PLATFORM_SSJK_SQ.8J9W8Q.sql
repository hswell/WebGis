create PROCEDURE      PLATFORM_SSJK_SQ(VSTNM    VARCHAR,
                                             ISWARING VARCHAR,
                                             CURR     OUT PLATFORM.CURSOR) IS

  RED      VARCHAR(10);
  ORANGE   VARCHAR(10);
  NORMAL   VARCHAR(10);
  RANGE    NUMBER(5, 1);
  VMAPTYPE VARCHAR(20) := '1';
BEGIN
  SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR, maptype
    INTO RED, ORANGE, RANGE, NORMAL, VMAPTYPE
    FROM DSE_WARNING_PARAM;
  OPEN CURR FOR
    SELECT DISTINCT *
      FROM (select aa.*,
                   case aa.WARNINGBJ
                     when 1 then
                      RED
                     else
                      NORMAL
                   end COLOR,
                   'SS' STTP
              from (select t2.STNM,
                           TO_CHAR(T1.TM, 'yyyy-mm-dd hh24:mi') TM,
                           t1.STCD,
                           case
                             when VMAPTYPE = '2' then
                              func_gis_lonmercator(T2.LGTD)
                             else
                              T2.LGTD
                           end LGTD,
                           case
                             when VMAPTYPE = '2' then
                              func_gis_latmercator(T2.LTTD)
                             else
                              T2.LTTD
                           end LTTD,
                           T4.MAXSCALE,
                           T4.MINSCALE,
                           T4.SHOWLABELSCALE,
                           T4.VIFL,
                           VTAVSLM,
                           SRLSLM,
                           SLM10,
                           SLM20,
                           SLM30,
                           SLM40,
                           SLM60,
                           SLM80,
                           SLM100,
                           STEMP,
                           CASE
                             WHEN t1.STEMP > t3.MAXSTEMP or
                                  t1.STEMP < t3.MINSTEMP or
                                  t1.SLM10 > t3.MAXSLM10 or
                                  t1.SLM10 < t3.MINSLM10 or
                                  t1.SLM20 > t3.MAXSLM20 or
                                  t1.SLM20 < t3.MINSLM20 or
                                  t1.SLM30 > t3.MAXSLM30 or
                                  t1.SLM30 < t3.MINSLM30 THEN
                              1
                             ELSE
                              0
                           END WARNINGBJ
                      from DSE_ST_SOIL_REAL t1
                      left join DSE_ST_SOIL_RULE t3 on t1.STCD = t3.STCD
                      LEFT JOIN DSE_ST_LABEL_SET T4 ON RTRIM(T4.STCD) =
                                                       RTRIM(T1.STCD)
                                                   AND T4.LAYERID = 5,
                     ST_STBPRP_B t2
                     where t1.STCD = t2.STCD
                       and t2.usfl = '1'
                       and (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')) aa
             where ISWARING IS NULL
                OR aa.WARNINGBJ like '%' || ISWARING || '%'
             order by aa.TM desc, aa.STNM);
END PLATFORM_SSJK_SQ;


/

