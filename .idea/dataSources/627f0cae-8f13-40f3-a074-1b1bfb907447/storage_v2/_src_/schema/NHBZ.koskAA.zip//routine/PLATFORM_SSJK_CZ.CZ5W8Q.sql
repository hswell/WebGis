create PROCEDURE      PLATFORM_SSJK_CZ(VSTNM    VARCHAR,
                                                 VADDVCD  VARCHAR,
                                                 VQY      VARCHAR,
                                                 VTYPE    INTEGER,
                                                 ISWARING VARCHAR,
                                                 CURR     OUT PLATFORM.CURSOR) IS
  RED      VARCHAR(10);
  ORANGE   VARCHAR(10);
  NORMAL   VARCHAR(10);
  RANGE    NUMBER(5, 1);
  VMAPTYPE VARCHAR(20) := '1';
BEGIN

  SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR, maptype
    INTO RED, ORANGE, RANGE, NORMAL, VMAPTYPE
    FROM DSE_WARNING_PARAM;
  -- 船闸
  --ISWARING 用于判断是否报警，''所有，1报警，0非报警。
  --珠三角需求，返回内外江水位流量
  OPEN CURR FOR
     with sql1 as(
		select * from dse_st_stbprp_b_kz where sttp='CZ' and usfl='1'
	  )
      SELECT a1.name STNM,
                    T1.STCD,
                    'CZ' STTP,
                    case when  VMAPTYPE='2' then func_gis_lonmercator(T2.LGTD) else T2.LGTD end LGTD,
					          case when  VMAPTYPE='2' then func_gis_latmercator(T2.LTTD) else T2.LTTD end LTTD,
                    T4.MAXSCALE,
                    T4.MINSCALE,
                    T4.VIFL,
					TO_CHAR(T1.TM, 'yyyy-mm-dd hh24:mi') TM,
					TRIM(TO_CHAR(ROUND(T1.on_Z, 2), '99999999990.99')) ON_Z,
					TRIM(TO_CHAR(ROUND(T1.down_Z, 2), '99999999990.99')) DOWN_Z,
					TRIM(TO_CHAR(ROUND(T1.mid_Z, 2), '99999999990.99')) MID_Z,
					case FUNC_CZ_ZMZT(a1.stcd) when 1 then '开' when 0 then '关' else '' end ON_STATU,
					case FUNC_CZ_ZMZT(a2.stcd) when 1 then '开' when 0 then '关' else '' end  DOWN_STATU
               FROM sql1 a1,sql1 a2,ST_STBPRP_B T2,dse_cz_ship_kz_real T1
               LEFT JOIN DSE_ST_LABEL_SET T4 ON RTRIM(T4.STCD) = RTRIM(T1.STCD) AND T4.LAYERID = 1
              WHERE a1.newstcd=a2.newstcd and a1.type='1' and a2.type='2' and t2.stcd=a1.stcd
             --关联前闸的经伟度
              and t1.stcd = a1.newstcd   and t2.usfl = '1'
               and (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')
           AND (VADDVCD IS NULL OR T2.ADDVCD LIKE VADDVCD || '%')
           AND (T2.RVNM LIKE '%' || CASE VTYPE WHEN 1 THEN NVL(VQY, '') ELSE ''
               END || '%' OR T2.HNNM LIKE '%' || CASE VTYPE WHEN 2 THEN
               NVL(VQY, '') ELSE '' END || '%' OR T2.BSNM LIKE '%' || CASE
               VTYPE WHEN 3 THEN NVL(VQY, '') ELSE ''
               END || '%' OR '10' = '1' || CASE WHEN VQY IS NULL THEN '0' ELSE '' END)
 order by t1.ON_Z desc,t1.DOWN_Z desc;
END PLATFORM_SSJK_CZ;


/

