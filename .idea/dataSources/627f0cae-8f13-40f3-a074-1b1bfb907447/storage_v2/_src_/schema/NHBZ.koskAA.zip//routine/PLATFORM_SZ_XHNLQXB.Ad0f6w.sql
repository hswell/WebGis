create procedure      PLATFORM_SZ_XHNLQXB(szcode    varchar,
                                                zsswmin   number,
                                                zsswmax   number,
                                                zxswmin   number,
                                                zxswmax   number,
                                                bgtm   varchar,
                                                entm   varchar,
                                                PAGEFROM INT,
                                                PAGETO   INT,
                                                cursor1  OUT PLATFORM.CURSOR) is
begin
  open cursor1 for
    select * from (

         select t1.ennm ,t.ENNMCD,to_char(t.INPRDT, 'yyyy-mm-dd') INPRDT ,t.GTUPWTLV ,t.GTDWWTLV ,t.DSTTFL ,t.ATID ,t.SDFL ,t.RMA ,t.MDPS ,t.MDDT
                ,ROW_NUMBER() over(order by t.MDDT) RN
         from   TB0904_ESCPP_044 t ,TB0001_PRNMSR_044 t1 ,TB0901_SLCMIN_044 t2
         where  t.ennmcd=t1.ennmcd and t.ennmcd =t2.ennmcd
                and t1.ennm like '%'||szcode||'%'
                and t.INPRDT>=to_date(bgtm,'yyyy-mm-dd HH24:MI:SS')
                and t.INPRDT<=to_date(entm,'yyyy-mm-dd HH24:MI:SS')
                and (zsswmin=-1 or t.GTUPWTLV>=zsswmin) and (zsswmax=-1 or t.GTUPWTLV<=zsswmax)
                and  (zxswmin=-1 or t.GTDWWTLV>=zxswmin) and  (zxswmax=-1 or t.GTDWWTLV<=zxswmax)

     ) t1 where t1.rn>PAGEFROM and t1.rn<=PAGETO;

end PLATFORM_SZ_XHNLQXB;


/

