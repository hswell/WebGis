create procedure      PLATFORM_SZ_ZMXX(szcode  varchar,
                                             zmno  number,
                                             zmmc  varchar,
                                             PAGEFROM  INT,
                                             PAGETO    INT,
                                             cursor1 OUT PLATFORM.CURSOR) is
begin
    open cursor1 for
       select * from (
         select t1.ennm ,t.*,t2.zm3durl,row_number() over(order by t.ennmcd) rn
         from DSE_TB0909_SLZBXX_B t,TB0001_PRNMSR_044 t1,TB0901_SLCMIN_044 t2
         where t.ennmcd=t1.ennmcd and t.ennmcd=t2.ennmcd
               and (szcode is null or t1.ennm like '%'||szcode||'%')
               and (zmno=-1 or t.zmnum=zmno )
               and (zmmc is null or t.zmname like '%'||zmmc||'%')
       ) t1 where t1.rn >PAGEFROM and t1.rn <=PAGETO ;
end PLATFORM_SZ_ZMXX;


/

