create procedure      PLATFORM_PPTN_ST_PSTAT_DAY_TJ(
  P_STCD VARCHAR,
	P_TM DATE
) is
--日雨量统计存储过程  zouwei  // 2013-10-08 已作废
	 v_hour int;--小时24小时格式
	 v_min int;--分钟24小时格式
   v_qdate date;

begin
  if P_STCD is null or P_TM is null then
		return;
  end if;

  v_hour:=to_number(to_char(P_TM,'hh24'));
  v_min:=to_number(to_char(P_TM,'mi'));

  if (v_hour <=7) or ( v_hour=8 and v_min=0) then
	   begin
      v_qdate:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM-DD')||' 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
	   end;
	else --08点 到23点
	   begin
			    v_qdate:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM-DD')||' 08:00:00', 'yyyy-mm-dd hh24:mi:ss')+1 ;
	   end;
   end if;

    declare V_STCD_TJ char(8);
	          V_ACCP number(6,1); --累计降水量
	          V_TJSTATUS number(6,1); --统计标识
	          V_DAYDRP number(6,1); --统计日雨量
      begin
            begin
               select STCD,ACCP,TJSTATUS into V_STCD_TJ,V_ACCP,V_TJSTATUS from DSE_ST_PSTAT_R where STTDRCD='1' and STCD=P_STCD and IDTM =v_qdate;
               --存在记录 更新表
               if V_TJSTATUS=1 then
                    begin
                         select nvl(sum(drp),0) into V_DAYDRP from DSE_ST_pptn_r where stcd=P_STCD and tm >v_qdate-1 and tm <=v_qdate ;

                         update 	DSE_ST_PSTAT_R set accp=V_DAYDRP  where STTDRCD='1' and STCD=P_STCD and IDTM =v_qdate;

                    end;
                end if;
           exception
              when NO_DATA_FOUND then
                select nvl(sum(drp),0) into V_DAYDRP from DSE_ST_pptn_r where stcd=P_STCD and tm >v_qdate-1 and tm <=v_qdate ;

                insert into DSE_ST_PSTAT_R(stcd,idtm,sttdrcd,accp,tjstatus)values(P_STCD,v_qdate,'1',V_DAYDRP,1);
         end;

      end;


end PLATFORM_PPTN_ST_PSTAT_DAY_TJ;


/

