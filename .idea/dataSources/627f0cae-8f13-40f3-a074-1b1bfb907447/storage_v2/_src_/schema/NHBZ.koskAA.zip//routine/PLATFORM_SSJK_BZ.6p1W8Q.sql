create PROCEDURE      PLATFORM_SSJK_BZ(VSTNM    VARCHAR,
                                             VADDVCD  VARCHAR,
                                             VQY      VARCHAR,
                                             VTYPE    INTEGER,
                                             ISWARING VARCHAR,
                                             VMAPTYPE VARCHAR,
                                             CURR     OUT PLATFORM.CURSOR) IS

  RED      VARCHAR(10);
  ORANGE   VARCHAR(10);
  NORMAL   VARCHAR(10);
  RANGE    NUMBER(5, 1);
  -- =============================================
  -- Author:    chensong
  -- Create date: 2013-028-16
  -- Description: 泵站实时监控信息
  --ISWARING 用于判断是否报警，''所有，1报警，0非报警。
  -- =============================================
BEGIN
  SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR
    INTO RED, ORANGE, RANGE, NORMAL
    FROM DSE_WARNING_PARAM;
/*if VADDVCD<>'441900' then*/
  OPEN CURR FOR
    SELECT DISTINCT *
      FROM (SELECT T2.STNM,
                   T1.STCD,
                   'DP' STTP,

                   case
                     when VMAPTYPE = '2' then
                      func_gis_lonmercator(T2.LGTD)
                     else
                      T2.LGTD
                   end LGTD,
                   case
                     when VMAPTYPE = '2' then
                      func_gis_latmercator(T2.LTTD)
                     else
                      T2.LTTD
                   end LTTD,
                   T4.MAXSCALE,
                   T4.MINSCALE,
                   T4.SHOWLABELSCALE,
                   T4.BZDETAILSCALE,
                   T4.VIFL,
                   TO_CHAR(T1.TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(T1.FOREBAYZ, 2), '99999999990.99')) FOREBAYZ,
                   TRIM(TO_CHAR(ROUND(T1.NSW, 2), '99999999990.99')) NSW,
                   TRIM(TO_CHAR(ROUND(T1.WSW, 2), '99999999990.99')) WSW,
                   FUNC_BZ_JZZT(T1.STCD, NULL) JZSTATE,
                   to_char(FUNC_BZ_RUNTM(TO_CHAR(T1.STCD)),
                           'yyyy-mm-dd hh24:mi:ss') BZSTATE,
                   TO_CHAR(getadnm(T2.ADDVCD)) ADNM,
                   t9.ennmcd ENNMCD,
                   t8.nsw YNSW,
                   t8.wsw YWSW,
                   t8.forebayz YFOREBAYZ,
                   CASE
                     WHEN t8.NSW IS not NULL and t1.NSW IS not null and
                          t1.NSW > t8.NSW THEN
                      RED
                     WHEN t8.WSW IS not NULL and t1.WSW IS not null and
                          t1.WSW > t8.WSW THEN
                      RED
                     WHEN t8.FOREBAYZ IS not NULL and t1.FOREBAYZ IS not null and
                          t1.FOREBAYZ > t8.FOREBAYZ THEN
                      RED
                     WHEN t8.NSW IS not NULL and t1.NSW IS not null and
                          t8.NSW - t1.NSW <= RANGE THEN
                      ORANGE
                     WHEN t8.WSW IS not NULL and t1.WSW IS not null and
                          t8.WSW - t1.WSW <= RANGE THEN
                      ORANGE
                     WHEN t8.FOREBAYZ IS not NULL and t1.FOREBAYZ IS not null and
                          t8.FOREBAYZ - t1.FOREBAYZ <= RANGE THEN
                      ORANGE
                     ELSE
                      NORMAL
                   END COLOR,

                   CASE
                     WHEN t8.NSW IS not NULL and t1.NSW IS not null and
                          t1.NSW > t8.NSW THEN
                      1
                     ELSE
                      0
                   END WARNINGBJ,

                   CASE
                     WHEN t8.NSW IS not NULL and t1.NSW IS not null and
                          t1.NSW > t8.NSW THEN
                      t1.NSW - t8.NSW + 9999999
                     ELSE
                      T1.NSW
                   END orderbyIndex,T2.ADDVCD

              FROM (select distinct *
                      from (select stcd,
                                   RANK() OVER(PARTITION BY stcd ORDER BY tm desc, nsw, wsw, forebayz, aircrewstate) rn,
                                   tm,
                                   voltagea,
                                   voltageb,
                                   voltagec,
                                   eca,
                                   ecb,
                                   ecc,
                                   poweractive,
                                   powerreactive,
                                   edactive,
                                   edreactive,
                                   powerfactor,
                                   upbushing,
                                   downbushing,
                                   powerbushing,
                                   statortemperature,
                                   aircrewstate,
                                   instantaneousq,
                                   countq,
                                   forebayz,
                                   distance,
                                   nsw,
                                   wsw
                              from dse_bz_runinfo_real)
                     where rn = 1) T1
              left join DSE_BZ_RUNINFO_RULE t8
                on t8.STCD = t1.STCD
              LEFT JOIN dse_tb0001_remark_b t9
                on t9.stcd = t1.stcd
              LEFT JOIN DSE_ST_LABEL_SET T4
                ON RTRIM(T4.STCD) = RTRIM(T1.STCD)
               AND T4.LAYERID = 3, ST_STBPRP_B T2
             WHERE T1.STCD = T2.STCD
               and t2.usfl = '1'
               and T2.STNM LIKE '%' || nvl(VSTNM, '') || '%'


               --AND T2.ADDVCD LIKE nvl(VADDVCD, '') || '%'

               and exists (
                     select 1 from Table(fun_split(VADDVCD,',')) ct2 where T2.ADDVCD like ct2.column_value||'%'
                )
               AND (T2.RVNM LIKE '%' || CASE VTYPE
                     WHEN 1 THEN
                      NVL(VQY, '')
                     ELSE
                      ''
                   END || '%' OR T2.HNNM LIKE '%' || CASE VTYPE
                     WHEN 2 THEN
                      NVL(VQY, '')
                     ELSE
                      ''
                   END || '%' OR T2.BSNM LIKE '%' || CASE VTYPE
                     WHEN 3 THEN
                      NVL(VQY, '')
                     ELSE
                      ''
                   END || '%' OR '10' = '1' || CASE
                     WHEN VQY is null THEN
                      '0'
                     ELSE
                      ''
                   END)
            -- ORDER BY T1.FOREBAYZ DES
            ) tttt
     where tttt.WARNINGBJ like '%' || ISWARING || '%'
     --order by tttt.orderbyIndex desc;
     order by tttt.ADDVCD ;
    /* else
       OPEN CURR FOR select * from st_stbprp_b where 1=2;*/
/*end if;*/
END PLATFORM_SSJK_BZ;


/

