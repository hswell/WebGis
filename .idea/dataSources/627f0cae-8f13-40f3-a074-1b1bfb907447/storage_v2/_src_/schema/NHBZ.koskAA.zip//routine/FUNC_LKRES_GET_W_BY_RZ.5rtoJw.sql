create FUNCTION      FUNC_LKRES_GET_W_BY_RZ(STCDVALUE varchar2,
                                                  ZVALUE   /*用于关联的参考数据*/    NUMERIC)
  RETURN NUMBER IS
  V NUMBER(9, 3);
  --根据水位计算库容
  X1        NUMERIC(18, 8);
  Y1        NUMERIC(18, 8);
  X2        NUMERIC(18, 8);
  Y2        NUMERIC(18, 8);
  X3        NUMERIC(18, 8);
  Y3        NUMERIC(18, 8);
  X4        NUMERIC(18, 8);
  Y4        NUMERIC(18, 8);
  ROWSIZE   INT := 0;
  VARCURSOR SYS_REFCURSOR;
  CURSOR TMPCURSOR IS
    SELECT RZ, W FROM ST_ZVARL_B WHERE 1 = 2;
  R TMPCURSOR%ROWTYPE;
BEGIN
  --获取数值对应关系曲线的相关值
  IF ZVALUE IS NULL OR STCDVALUE IS NULL THEN
    RETURN NULL;
  END IF;

  OPEN VARCURSOR FOR
    SELECT B.RZ, B.W
      FROM (SELECT RZ, W
              FROM (SELECT RZ, W
                      FROM (SELECT RZ, W
                              FROM ST_ZVARL_B
                             WHERE RZ >= ZVALUE
                               AND STCD = STCDVALUE
                             ORDER BY RZ)
                     WHERE ROWNUM <= 2) A1
            UNION ALL
            SELECT CASE
                     WHEN RZ = ZVALUE THEN
                      NULL
                     ELSE
                      RZ
                   END AS RZ,
                   W
              FROM (SELECT *
                      FROM (SELECT RZ, W
                              FROM ST_ZVARL_B
                             WHERE RZ <= ZVALUE
                               AND STCD = STCDVALUE
                             ORDER BY RZ DESC)
                     WHERE ROWNUM <= 2) A2

            ) B
     WHERE B.RZ IS NOT NULL
     ORDER BY B.RZ;

  LOOP
    FETCH VARCURSOR
      INTO R;
    EXIT WHEN VARCURSOR%NOTFOUND;
    IF ROWSIZE = 0 THEN
      X1 := R.RZ;
      Y1 := R.W;
    ELSIF ROWSIZE = 1 THEN
      X2 := R.RZ;
      Y2 := R.W;
    ELSIF ROWSIZE = 2 THEN
      X3 := R.RZ;
      Y3 := R.W;
    ELSIF ROWSIZE = 3 THEN
      X4 := R.RZ;
      Y4 := R.W;
    END IF;
    ROWSIZE := ROWSIZE + 1;
  END LOOP;

  IF ROWSIZE = 4 THEN
    IF (ABS(X2 - ZVALUE) < ABS(X3 - ZVALUE)) THEN
      V := FUNC_THREE_SPOT_METHOD(X1, Y1, X2, Y2, X3, Y3, ZVALUE);
    ELSE
      V := FUNC_THREE_SPOT_METHOD(X2, Y2, X3, Y3, X4, Y4, ZVALUE);
    END IF;
  ELSIF ROWSIZE = 3 THEN
    V := FUNC_THREE_SPOT_METHOD(X1, Y1, X2, Y2, X3, Y3, ZVALUE);
  ELSIF ROWSIZE = 2 THEN
    IF X1 >= ZVALUE THEN
      V := Y1;
    ELSE
      V := Y2;
    END IF;

  END IF;

  RETURN(V);
END FUNC_LKRES_GET_W_BY_RZ;


/

