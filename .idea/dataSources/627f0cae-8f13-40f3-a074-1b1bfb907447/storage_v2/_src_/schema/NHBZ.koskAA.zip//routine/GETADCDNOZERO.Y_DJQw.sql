create function      getAdcdNoZero(adcd  in varchar2) return varchar2
as
code  varchar2(15) ;

begin
     code := rtrim(adcd);
     if(code is not null and length(code) >1) then
     begin
        if(substr(code,5))='00000000000' then
            select '4419' into code from dual;
        else
            select code into code from dual;
        end if;
      end;
     end if;
     return code;
end getAdcdNoZero;


/

