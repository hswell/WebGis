create FUNCTION      FUNC_THREE_SPOT_METHOD(X1 NUMERIC,
                                                  Y1 NUMERIC,
                                                  X2 NUMERIC,
                                                  Y2 NUMERIC,
                                                  X3 NUMERIC,
                                                  Y3 NUMERIC,
                                                  XT NUMERIC) RETURN NUMBER IS
  --获取三点不等距插值
  V   NUMERIC(18, 8);
  V1  NUMERIC(18, 8);
  YY1 NUMERIC(18, 8);
  YY2 NUMERIC(18, 8);
BEGIN

  IF (XT <> X2) THEN
    BEGIN
      V := (Y1 * (XT - X2) / (X1 - X2) * (XT - X3) / (X1 - X3)) +
           (Y2 * (XT - X1) / (X2 - X1) * (XT - X3) / (X2 - X3)) +
           (Y3 * (XT - X1) / (X3 - X1) * (XT - X2) / (X3 - X2));
      IF (XT < X2) THEN
        BEGIN
          YY1 := Y1;
          YY2 := Y2;
          V1  := (Y1 * (XT - X2) - Y2 * (XT - X1)) / (X1 - X2);
        END;
      ELSE
        BEGIN
          YY1 := Y2;
          YY2 := Y3;
          V1  := (Y2 * (XT - X3) - Y3 * (XT - X2)) / (X2 - X3);
        END;
      END IF;
      V := (V * 2 + V1) / 3;

      IF (V > YY2 OR V < YY1) THEN
        V := V1;
      END IF;
    END;
  ELSE
    V := Y2;
  END IF;
  RETURN (V);
END FUNC_THREE_SPOT_METHOD;


/

