create trigger TRIG_DSE_BZ_YCXX_B
    after insert or update
    on DSE_BZ_YCXX_B
    for each row
declare
  PRAGMA AUTONOMOUS_TRANSACTION;
  TEMPTIME DATE;
begin

  --更新实时表
  SELECT MAX(TM)
    INTO TEMPTIME
    FROM DSE_BZ_YCXX_B_REAL
   WHERE STCD = :NEW.STCD;

  IF TEMPTIME IS NULL THEN
    INSERT INTO DSE_BZ_YCXX_B_REAL
      (STCD, TM, NSW, WSW, NJYCYJZ, WPTN, ISWARN, CYCYJ, NJQPSW, NT)
    VALUES
      (:NEW.STCD,
       :NEW.TM,
       :NEW.NSW,
       :NEW.WSW,
       :NEW.NJYCYJZ,
       :NEW.WPTN,
       :NEW.ISWARN,
       :NEW.CYCYJ,
       :NEW.NJQPSW,
       :NEW.NT);
  ELSIF (TEMPTIME <= :NEW.TM) or
        (:NEW.TM < sysdate + 1 and TEMPTIME > sysdate + 1) THEN
    UPDATE DSE_BZ_YCXX_B_REAL
       SET TM      = :NEW.TM,
           NSW     = :NEW.NSW,
           WSW     = :NEW.WSW,
           NJYCYJZ = :NEW.NJYCYJZ,
           WPTN    = :NEW.WPTN,
           ISWARN  = :NEW.ISWARN,
           CYCYJ   = :NEW.CYCYJ,
           NT      = :NEW.NT
     WHERE STCD = :NEW.STCD;
  END IF;

  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    rollback;
  
end TRIG_DSE_ST_RIVER_R;


/

