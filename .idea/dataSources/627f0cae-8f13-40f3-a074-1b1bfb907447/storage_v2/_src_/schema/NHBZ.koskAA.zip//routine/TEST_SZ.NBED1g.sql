create PROCEDURE      TEST_SZ IS
 /* ST TIMESTAMP := TO_DATE('2013-01-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
  ET TIMESTAMP := TO_DATE('2013-06-18 00:00:00', 'yyyy-mm-dd hh24:mi:ss');*/
  ST TIMESTAMP;
  MI INT;

BEGIN

  SELECT SYSDATE INTO ST FROM DUAL;
  MI := TO_NUMBER(TO_CHAR(ST, 'mi'));

  WHILE MOD(MI, 5) != 0 LOOP
    SELECT ST - INTERVAL '1' MINUTE INTO ST FROM DUAL;
    MI := TO_NUMBER(TO_CHAR(ST, 'mi'));
  END LOOP;

  /*WHILE ST < ET LOOP*/
    DECLARE
      --类型定义
      CURSOR C_JOB IS
        SELECT STCD FROM ST_STBPRP_B WHERE STTP = 'DD';
      --定义一个游标变量
      C_ROW C_JOB%ROWTYPE;
    BEGIN
      FOR C_ROW IN C_JOB LOOP
        INSERT INTO DSE_SZ_RUNINFO_R
          (STCD,
           TM,
           OUT_WATER,
           IN_WATER,
           N1,
           KD1,
           N2,
           KD2,
           N3,
           KD3,
           N4,
           KD4,
           N5,
           KD5)
        VALUES
          (C_ROW.STCD,
           ST,
           ROUND(DBMS_RANDOM.VALUE(100, 300), 2),
           ROUND(DBMS_RANDOM.VALUE(50, 150), 2),
           ROUND(DBMS_RANDOM.VALUE(0, 1), 0),
           ROUND(DBMS_RANDOM.VALUE(0, 100), 2),
           ROUND(DBMS_RANDOM.VALUE(0, 1), 0),
           ROUND(DBMS_RANDOM.VALUE(0, 100), 2),
           ROUND(DBMS_RANDOM.VALUE(0, 1), 0),
           ROUND(DBMS_RANDOM.VALUE(0, 100), 2),
           ROUND(DBMS_RANDOM.VALUE(0, 1), 0),
           ROUND(DBMS_RANDOM.VALUE(0, 100), 2),
           ROUND(DBMS_RANDOM.VALUE(0, 1), 0),
           ROUND(DBMS_RANDOM.VALUE(0, 100), 2));
      END LOOP;
      COMMIT;
    END;
  /*
    ST := ST + INTERVAL '5' MINUTE;
  END LOOP;*/
END TEST_SZ;


/

