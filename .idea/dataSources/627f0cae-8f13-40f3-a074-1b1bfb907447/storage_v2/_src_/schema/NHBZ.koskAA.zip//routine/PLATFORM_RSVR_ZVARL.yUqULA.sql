create procedure      PLATFORM_RSVR_ZVARL(STCDS    VARCHAR,
                                               PAGEFROM INT,
                                               PAGETO   INT,
                                               CURR1    OUT PLATFORM.CURSOR) is
begin
   OPEN CURR1 FOR
     SELECT * FROM (
      SELECT T1.stcd,to_char(T1.mstm,'yyyy-mm-dd HH24:MI:SS') mstm,T1.ptno,T1.rz,T1.w,T1.wsfa,to_char(T1.moditime,'yyyy-mm-dd HH24:MI') moditime ,T2.STNM,ROW_NUMBER() OVER(ORDER BY T1.STCD) AS ROWNUM_  FROM ST_ZVARL_B T1
      INNER JOIN (SELECT * FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS PLATFORM_STCD_TYPE))) T4 ON T4.STCD =T1.STCD,ST_STBPRP_B T2
      WHERE T1.STCD=T2.STCD
     ) TT WHERE TT.ROWNUM_>PAGEFROM and TT.ROWNUM_ <= PAGETO ;

end PLATFORM_RSVR_ZVARL;


/

