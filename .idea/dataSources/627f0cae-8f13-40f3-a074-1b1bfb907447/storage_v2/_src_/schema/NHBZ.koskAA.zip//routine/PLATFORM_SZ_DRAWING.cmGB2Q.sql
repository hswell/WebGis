create procedure      PLATFORM_SZ_DRAWING(gcname  varchar,
                                                pcode   varchar,
                                                PAGEFROM  INT,
                                                PAGETO    INT,
                                                cursor1 OUT PLATFORM.CURSOR) is
begin

    open cursor1 for
       select t1.* from (
            select t1.ennm,t.* ,decode(t.fgsr,'1','设计图','2','竣工图','3','示意图','4','改建图') fgsrname
                   ,row_number() over(order by t.mddt) rn
            from  TB0003_PRGL_044 t,TB0001_PRNMSR_044 t1 ,TB0901_SLCMIN_044 t2
            where t.ennmcd=t1.ennmcd and t.ennmcd=t2.ennmcd
                  and t1.ennm like '%'||gcname||'%'  and  t.fgmr like '%'||pcode||'%'
      ) t1 where t1.rn >PAGEFROM and t1.rn <=PAGETO ;

end PLATFORM_SZ_DRAWING;


/

