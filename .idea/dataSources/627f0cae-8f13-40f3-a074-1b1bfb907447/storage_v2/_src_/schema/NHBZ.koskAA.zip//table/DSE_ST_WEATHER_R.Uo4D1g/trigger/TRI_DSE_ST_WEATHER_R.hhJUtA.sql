create trigger TRI_DSE_ST_WEATHER_R
    after insert or update
    on DSE_ST_WEATHER_R
    for each row
declare
  --AUTHOR chenya
  --DATE 2014-07-08
  --触发气象数据到气象实时表dse_st_weather_real。
  V_COUNT int;
  V_DRP NUMERIC(5,1);
  V_DRPOLD NUMERIC(5,1);
begin
  select count(1)
    into V_COUNT
    from dse_st_weather_real
   where stcd = :new.stcd;
  if (V_COUNT > 0) then
    begin
    -- LIUXAIN
    SELECT DRPDAY INTO V_DRPOLD FROM DSE_ST_WEATHER_REAL WHERE STCD = :NEW.STCD;
    V_DRP:=:NEW.DRPDAY-V_DRPOLD;
    IF(V_DRP<0) THEN
        V_DRP:=0;
    END IF;
      INSERT INTO ST_PPTN_R (STCD,TM,DRP) VALUES (:NEW.STCD,:NEW.TM,V_DRP);  
    
    --LIUXIAN
      update dse_st_weather_real
         set tm            = :new.tm,
             DRPHOUR       = :new.DRPHOUR,
             DRPDAY        = :new.DRPDAY,
             WD            = :new.WD,
             WDHIGHHOUR    = :new.WDHIGHHOUR,
             WDLOWHOUR     = :new.WDLOWHOUR,
             WDHIGHDAY     = :new.WDHIGHDAY,
             WDLOWDAY      = :new.WDLOWDAY,
             WIND2MIN      = :new.WIND2MIN,
             WINDR2MIN     = :new.WINDR2MIN,
             WIND10MIN     = :new.WIND10MIN,
             WINDR10MIN    = :new.WINDR10MIN,
             WIND10MINH    = :new.WIND10MINH,
             WINDR10MINH   = :new.WINDR10MINH,
             WINDMAXH      = :new.WINDMAXH,
             WINDRMAXH     = :new.WINDRMAXH,
             WIND10MINDAY  = :new.WIND10MINDAY,
             WINDR10MINDAY = :new.WINDR10MINDAY,
             WINDMAXDAY    = :new.WINDMAXDAY,
             WINDRMAXDAY   = :new.WINDRMAXDAY
       where stcd = :new.stcd;
    end;
  else
    insert into dse_st_weather_real
      (stcd,
       tm,
       DRPHOUR,
       DRPDAY,
       WD,
       WDHIGHHOUR,
       WDLOWHOUR,
       WDHIGHDAY,
       WDLOWDAY,
       WIND2MIN,
       WINDR2MIN,
       WIND10MIN,
       WINDR10MIN,
       WIND10MINH,
       WINDR10MINH,
       WINDMAXH,
       WINDRMAXH,
       WIND10MINDAY,
       WINDR10MINDAY,
       WINDMAXDAY,
       WINDRMAXDAY)
    values
      (:new.stcd,
       :new.tm,
       :new.DRPHOUR,
       :new.DRPDAY,
       :new.WD,
       :new.WDHIGHHOUR,
       :new.WDLOWHOUR,
       :new.WDHIGHDAY,
       :new.WDLOWDAY,
       :new.WIND2MIN,
       :new.WINDR2MIN,
       :new.WIND10MIN,
       :new.WINDR10MIN,
       :new.WIND10MINH,
       :new.WINDR10MINH,
       :new.WINDMAXH,
       :new.WINDRMAXH,
       :new.WIND10MINDAY,
       :new.WINDR10MINDAY,
       :new.WINDMAXDAY,
       :new.WINDRMAXDAY);
  
  end if;

end TRI_dse_st_weather_r;


/

