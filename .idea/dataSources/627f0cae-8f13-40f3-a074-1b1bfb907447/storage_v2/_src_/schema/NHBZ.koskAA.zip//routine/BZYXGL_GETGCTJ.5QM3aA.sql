create procedure      BZYXGL_GETGCTJ(VSTNM varchar2,
                                           VADCD varchar2,
                                           VSTTP VARCHAR2,
                                           VSFSB VARCHAR2,
                                           CURR  OUT PLATFORM.CURSOR) IS
begin
if VSTTP ='DP' then
    if VSFSB='Y' then
         open CURR for
         select * from
             (select distinct
                 t1.STCD,
                 t2.STNM,
                 t1.TM,
                 case when t1.nsw is null then 0 else t1.nsw end NSW,
                 case when t1.wsw is null then 0 else t1.wsw end WSW,
                 getadnm(t2.addvcd) AS ADNAME,
                 (case when (t1.TM > to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss')) then 1  else 0 end )as STATUS
                 from  ST_STBPRP_B t2 left join dse_bz_runinfo_real t1 on t1.STCD=t2.STCD
                 where  t2.usfl=1 and t2.sttp = 'DP'
                 AND  ( VADCD IS NULL OR T2.ADDVCD LIKE getAdcdNoZero(VADCD) || '%')
                 AND (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')) order by stnm,NSW desc;

         else
         open CURR for
           select * from
             (select distinct
                 t1.STCD,
                 t2.STNM,
                 t1.TM,
                 case when t1.nsw is null then 0 else t1.nsw end NSW,
                 case when t1.wsw is null then 0 else t1.wsw end WSW,
                 getadnm(t2.addvcd) AS ADNAME,
                 (case when (t1.TM < to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss')  or t1.TM is null) then 1 else 0 end )as SBSTATUS
                 from  ST_STBPRP_B t2 left join dse_bz_runinfo_real t1 on t1.STCD=t2.STCD
                 where  t2.usfl=1 and t2.sttp = 'DP'
                 AND  ( VADCD IS NULL OR T2.ADDVCD LIKE getAdcdNoZero(VADCD) || '%')
                 AND (t1.tm>=to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss'))
                  AND (t1.tm<=to_date(to_char(sysdate,'yyyy-mm-dd')||' 23:59:59','yyyy-mm-dd hh24:mi:ss'))
                 AND (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')) order by stnm,NSW desc;
      end if;
else if VSTTP = 'PP' then
 if VSFSB='Y' then
         open CURR for
         select * from
            (select distinct
                 t1.STCD,
                 t2.STNM,
                 t1.TM,
                 case when t1.drp is null then 0 else t1.drp end DRP,

                 getadnm(t2.addvcd) AS ADNAME,
                 (case when (t1.TM > to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss') ) then 1 else 0 end )as SBSTATUS
                 from  ST_STBPRP_B t2 left join dse_st_pptn_real t1  on t1.STCD=t2.STCD
                 where  t2.usfl=1
                 --and t2.sttp = 'ZQ'
                 and t2.sttp in ('PP','MM')
                 AND  ( VADCD IS NULL OR T2.ADDVCD LIKE getAdcdNoZero(VADCD) || '%')
                 AND (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%'))order by stnm,drp desc;

      else
           open CURR for
          select * from
            (select distinct
                 t1.STCD,
                 t2.STNM,
                 t1.TM,
                 case when t1.drp is null then 0 else t1.drp end DRP,
                 getadnm(t2.addvcd) AS ADNAME,
                 (case when (t1.TM > to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss') ) then 1 else 0 end )as SBSTATUS
                 from  ST_STBPRP_B t2 left join dse_st_pptn_real t1  on t1.STCD=t2.STCD
                 where  t2.usfl=1
                 --and t2.sttp = 'ZQ'
                 and t2.sttp in('PP','MM')
                 AND (t1.tm>to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss'))
                  AND (t1.tm<=to_date(to_char(sysdate,'yyyy-mm-dd')||' 23:59:59','yyyy-mm-dd hh24:mi:ss'))
                 AND  ( VADCD IS NULL OR T2.ADDVCD LIKE getAdcdNoZero(VADCD) || '%')
                 AND (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%'))order by stnm,drp desc;
      end if;
  else
  if VSFSB='Y' then
         open CURR for
         select * from
            (select distinct
                 t1.STCD,
                 t2.STNM,
                 t1.TM,
                 case when t1.Z is null then 0 else t1.Z end Z,
                 getadnm(t2.addvcd) AS ADNAME,
                 (case when (t1.TM > to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss')  ) then 1 else 0 end )as SBSTATUS
                 from  ST_STBPRP_B t2  left join dse_st_river_real t1
                 on t2.STCD =t1.STCD
                 where  t2.usfl=1
                 and t2.sttp in ('ZZ','RR')
                 AND  ( VADCD IS NULL OR T2.ADDVCD LIKE getAdcdNoZero(VADCD) || '%')
                 AND (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%'))order by stnm,Z desc;

      else
           open CURR for
          select * from
            (select distinct
                 t1.STCD,
                 t2.STNM,
                 t1.TM,
                 case when t1.Z is null then 0 else t1.Z end Z,
                 getadnm(t2.addvcd) AS ADNAME,
                 (case when (t1.TM > to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss')  ) then 1 else 0 end )as SBSTATUS
                 from  ST_STBPRP_B t2   left join dse_st_river_real t1
                 on t2.STCD =t1.STCD
                 where  t2.usfl=1
                 --and t2.sttp = 'ZQ'
                 and t2.sttp in ('ZZ','RR')
                 AND (t1.tm>to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss'))
                 AND  ( VADCD IS NULL OR T2.ADDVCD LIKE getAdcdNoZero(VADCD) || '%')
                 AND (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%'))order by stnm,Z desc;
      end if;

     end if;


end if;

END BZYXGL_GETGCTJ;


/

