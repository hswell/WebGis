create procedure      PLATFORM_BZ_DRAWING(gcname  varchar,
                                                pcode   varchar,
                                                PAGEFROM  INT,
                                                PAGETO    INT,
                                                cursor1 OUT PLATFORM.CURSOR) is
begin
    open cursor1 for
       select r1.* from (
            select  t.* ,decode(t.fgsr,'1','设计图','2','竣工图','3','示意图','4','改建图') fgsrname,t1.ennm ,F.NEWFILENAME,F.BSNUM
                   ,row_number() over(order by t.mddt) rn
            from  TB0003_PRGL_044 t LEFT JOIN DSE_ATTACHMENT F ON t.ppath=f.bsnum,TB0001_PRNMSR_044 t1,TB1501_MEIDSCIN_044 t2
            where t.ennmcd=t1.ennmcd and t.ennmcd=t2.ennmcd
                  and t1.ennm like '%'||gcname||'%'
                  and  t.fgmr like '%'||pcode||'%'
       ) r1 where r1.rn >PAGEFROM and r1.rn <=PAGETO ;
end PLATFORM_BZ_DRAWING;


/

