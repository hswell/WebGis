create PROCEDURE      PLATFORM_BB_GZZRNBJY_YY(VSTCD VARCHAR,
                                                    NF    INTEGER,
                                                    CUR1  OUT PLATFORM.CURSOR) IS

  STARTTIME DATE;
  ENDTIME   DATE;
BEGIN
  -- 各站逐日降雨年报表
  STARTTIME := TO_DATE(TO_CHAR(NF) || '-01-01 08:00:00',
                       'yyyy-mm-dd hh24:mi:ss');
  ENDTIME   := TO_DATE(TO_CHAR(NF + 1) || '-01-01 08:00:00',
                       'yyyy-mm-dd hh24:mi:ss');

  OPEN CUR1 FOR WITH SQL1 AS(
    SELECT T1.ACCP,
           IDTM - INTERVAL '1' DAY TM,
           TO_NUMBER(NVL(TO_CHAR(IDTM - INTERVAL '1' DAY, 'dd'), '01')) DD,
           TO_NUMBER(NVL(TO_CHAR(IDTM - INTERVAL '1' DAY, 'mm'), '01')) MM
      FROM DSE_ST_PSTAT_R T1
     WHERE T1.STCD = VSTCD
       AND STTDRCD = '1'
       AND T1.IDTM > STARTTIME
       AND T1.IDTM <= ENDTIME
       AND T1.ACCP > 0
     ORDER BY IDTM)
    SELECT *
      FROM (SELECT SUM(ACCP) LJ FROM SQL1),
           (SELECT COUNT(ACCP) HJ FROM SQL1),
           (SELECT ACCP ACCP1, TO_CHAR(TM, 'yyyy-mm-dd') TM1
              FROM (SELECT ACCP, TM FROM SQL1 ORDER BY ACCP DESC)
             WHERE ROWNUM = 1),
           (SELECT *
              FROM (SELECT TO_CHAR(T1.TM, 'yyyy-mm-dd') TM3,
                           SUM(T2.ACCP) ACCP3
                      FROM SQL1 T1, SQL1 T2
                     WHERE T2.TM < T1.TM + INTERVAL '3' DAY
                       AND T2.TM >= T1.TM
                     GROUP BY T1.TM
                     ORDER BY ACCP3 DESC)
             WHERE ROWNUM = 1),
           (SELECT *
              FROM (SELECT TO_CHAR(T1.TM, 'yyyy-mm-dd') TM7,
                           SUM(T2.ACCP) ACCP7
                      FROM SQL1 T1, SQL1 T2
                     WHERE T2.TM < T1.TM + INTERVAL '7' DAY
                       AND T2.TM >= T1.TM
                     GROUP BY T1.TM
                     ORDER BY ACCP7 DESC)
             WHERE ROWNUM = 1),
           (SELECT *
              FROM (SELECT TO_CHAR(T1.TM, 'yyyy-mm-dd') TM15,
                           SUM(T2.ACCP) ACCP15
                      FROM SQL1 T1, SQL1 T2
                     WHERE T2.TM < T1.TM + INTERVAL '15' DAY
                       AND T2.TM >= T1.TM
                     GROUP BY T1.TM
                     ORDER BY ACCP15 DESC)
             WHERE ROWNUM = 1),
           (SELECT *
              FROM (SELECT TO_CHAR(T1.TM, 'yyyy-mm-dd') TM30,
                           SUM(T2.ACCP) ACCP30
                      FROM SQL1 T1, SQL1 T2
                     WHERE T2.TM < T1.TM + INTERVAL '30' DAY
                       AND T2.TM >= T1.TM
                     GROUP BY T1.TM
                     ORDER BY ACCP30 DESC)
             WHERE ROWNUM = 1)

    ;

END PLATFORM_BB_GZZRNBJY_YY;


/

