create FUNCTION      FUNC_SPLITSTRING(STR IN VARCHAR)
  RETURN PLATFORM_STCD_TYPE IS
  RESULT PLATFORM_STCD_TYPE := PLATFORM_STCD_TYPE();

BEGIN
  RESULT := PLATFORM_STCD_TYPE();
  DECLARE
    CURSOR C_JOB IS
      SELECT SUBSTR(T.RPT_ID,
                    INSTR(T.RPT_ID, ',', 1, C.LV) + 1,
                    INSTR(T.RPT_ID, ',', 1, C.LV + 1) -
                    (INSTR(T.RPT_ID, ',', 1, C.LV) + 1)) AS RPT_ID
        FROM (SELECT ',' || STR || ',' RPT_ID,
                     LENGTH(STR || ',') - NVL(LENGTH(REPLACE(STR, ',')), 0) CNT
                FROM DUAL) T,
             (SELECT LEVEL LV
                FROM DUAL
              CONNECT BY LEVEL <= LENGTH(STR || ',') -
                         NVL(LENGTH(REPLACE(STR, ',')), 0)) C
       WHERE T.CNT >= C.LV;

    C_ROW C_JOB%ROWTYPE;

  BEGIN
    FOR C_ROW IN C_JOB LOOP
      RESULT.EXTEND;
      RESULT(RESULT.COUNT) := PLATFORM_STCD_TABLE(NULL, NULL);
      RESULT(RESULT.COUNT).STCD := C_ROW.RPT_ID;
    END LOOP;
  END;

  RETURN(RESULT);
END FUNC_SPLITSTRING;


/

