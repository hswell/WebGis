create procedure      PLATFORM_LABEL_SET(LV_USERID   number,
                                               Lv_name     varchar2,
                                               lv_labelkey number) is
  VCOUNT number(1) := 0;
  --author: chenya
  --date: 2013-10-28
  --操作标签控制表
begin
  select count(userid)
    into VCOUNT
    from dse_label_set_contorl
   where userid = LV_USERID
     and labeltype = Lv_name;
  if VCOUNT > 0 then
    update dse_label_set_contorl
       set labelkey = lv_labelkey
     where userid = LV_USERID
       and labeltype = Lv_name;
  else
    insert into dse_label_set_contorl
      (USERID, labeltype, labelkey)
    values
      (LV_USERID, Lv_name, lv_labelkey);
  end if;
end PLATFORM_LABEL_SET;


/

