create function      getXqName return varchar2
is
adnme varchar2(100);
begin
  select NAME into adnme from SYS_DISTRICT where  PID is null and rownum <=1;
  if(length(adnme)>2) then
   adnme :=replace(adnme,'县','');
   adnme :=replace(adnme,'区','');
  end if;
  return(adnme);
end getXqName;


/

