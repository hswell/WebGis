create procedure      BZXXXT_BZ_YCXX(STCDS    VARCHAR, --测站编码
                                           PAGEFROM INT, --起始数据
                                           PAGETO   INT, --截止数据
                                           CURR     OUT PLATFORM.CURSOR) is
begin
  IF STCDS IS NOT NULL THEN
    BEGIN
      OPEN CURR FOR
    SELECT QQ.*
      FROM (SELECT Q.*, ROW_NUMBER() OVER(ORDER BY Q.CYCYJ DESC) RNUM
              FROM (SELECT T.STCD,
                           TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') AS TM,
                           T.NSW,
                           T.WSW,
                           T.NJYCYJZ,
                           T.CYCYJ,
                           T.ISWARN,
                           CASE T.WPTN
                             WHEN '4' THEN
                              '落'
                             WHEN '5' THEN
                              '涨'
                             WHEN '6' THEN
                              '平'
                             ELSE
                              '--'
                           END AS WPTN,
                           B.STNM
                      FROM DSE_BZ_YCXX_B_REAL T, ST_STBPRP_B B, V_TB1502_MEIDSBI V,
                      (SELECT *FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS PLATFORM_STCD_TYPE))) ST
                     WHERE T.STCD = B.STCD AND T.STCD = ST.STCD AND T.STCD = V.STCD) Q
             WHERE Q.ISWARN='1') QQ
     WHERE QQ.RNUM > PAGEFROM
       AND QQ.RNUM <= PAGETO;
    END;
  ELSE
    BEGIN
       OPEN CURR FOR
      SELECT QQ.*
      FROM (SELECT Q.*, ROW_NUMBER() OVER(ORDER BY Q.CYCYJ DESC) RNUM
              FROM (SELECT T.STCD,
                           TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') AS TM,
                           T.NSW,
                           T.WSW,
                           T.NJYCYJZ,
                           T.CYCYJ,
                           T.ISWARN,
                           CASE T.WPTN
                             WHEN '4' THEN
                              '落'
                             WHEN '5' THEN
                              '涨'
                             WHEN '6' THEN
                              '平'
                             ELSE
                              '--'
                           END AS WPTN,
                           B.STNM
                      FROM DSE_BZ_YCXX_B_REAL T, ST_STBPRP_B B, V_TB1502_MEIDSBI V
                     WHERE T.STCD = B.STCD AND T.STCD = V.STCD) Q
             WHERE Q.ISWARN='1') QQ
     WHERE QQ.RNUM > PAGEFROM
       AND QQ.RNUM <= PAGETO;
    END;
   END IF;
end BZXXXT_BZ_YCXX;


/

