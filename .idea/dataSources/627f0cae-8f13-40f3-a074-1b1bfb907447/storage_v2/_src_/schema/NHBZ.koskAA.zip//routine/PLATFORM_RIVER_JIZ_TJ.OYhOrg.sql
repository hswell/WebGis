create procedure      platform_river_jiz_tj(p_tm date)
 is
 TJTM date;--统计时间
 m_day int;--月格式
 d_day int;--天格式
begin
  if p_tm is null then
		begin
       TJTM:=TO_DATE(TO_CHAR(sysdate, 'YYYY-MM-DD') || ' 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
		end;
	else
		begin
			 TJTM:=TO_DATE(TO_CHAR(p_tm, 'YYYY-MM-DD') || ' 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
		end;
  end if;
  m_day:=to_number(to_char(TJTM,'mm'));
  d_day:=to_number(to_char(TJTM,'dd'));


  --日极值变量
  declare stcd char(8);
      htz number(7,3);
      ltz_dmx number(7,3);
      mxq_dmx number(9,3);
      mnq_dmx number(9,3);
      htztm_dmx DATE;
      ltztm_dmx DATE;
      mxqtm_dmx DATE;
      mnqtm_dmx DATE;
      STCD_TJ char(8); --是否已经存在对于记录判断
			TJSTATUS number(6,1); --统计标识
    begin
         declare cursor  lcur_river_day_jz  is
            select  t.stcd as stcd,n1.z as htz ,n2.z as ltz,n3.q as mxq,n4.q as mnq,
                  n1.tm as htztm,n2.tm as ltztm,n3.tm as mxqtm,n4.tm as mnqtm from  dse_st_river_real t inner join st_stbprp_b st on st.stcd=t.stcd  left join
                  (select * from (select t.stcd,t.z,t.tm, row_number() over (partition by t.stcd order by t.z desc)rn  from dse_st_river_r t
                  where t.z is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n1
                  on t.stcd = n1.stcd left join
                  (select * from (select t.stcd,t.z,t.tm, row_number() over (partition by t.stcd order by t.z asc)rn  from dse_st_river_r t
                  where t.z is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n2
                  on t.stcd = n2.stcd left join
                  (select * from (select t.stcd,t.q,t.tm, row_number() over (partition by t.stcd order by t.q desc)rn  from dse_st_river_r t
                  where t.q is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n3
                  on t.stcd = n3.stcd left join
                  (select * from (select t.stcd,t.q,t.tm, row_number() over (partition by t.stcd order by t.q asc)rn  from dse_st_river_r t
                  where t.q is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n4
                  on t.stcd = n4.stcd where   n1.z is not null and st.usfl='1' and (st.sttp='ZZ' or st.sttp='ZQ');
          begin
               FOR data_row IN lcur_river_day_jz LOOP
                     stcd:= data_row.stcd;
                     htz:=data_row.htz;
                     ltz_dmx:=data_row.ltz;
                     mxq_dmx:=data_row.mxq;
                     mnq_dmx:=data_row.mnq;
                     htztm_dmx:=data_row.htztm;
                     ltztm_dmx:=data_row.ltztm;
                     mxqtm_dmx:=data_row.mxqtm;
                     mnqtm_dmx:=data_row.mnqtm;
                     STCD_TJ:=null;
                     TJSTATUS:=null;
                    select max(STCD),max(TJSTATUS) into STCD_TJ,TJSTATUS from DSE_ST_RVEVS_R where STTDRCD='1' and STCD=stcd and IDTM =TJTM;

            				if STCD_TJ is not null then
            					begin
            					    if  TJSTATUS=1 then --系统自动统计值 可以修改
              							begin
              								update DSE_ST_RVEVS_R set HTZ=htz,LTZ=ltz_dmx,MXQ=mxq_dmx,MNQ=mnq_dmx,HTZTM=htztm_dmx,LTZTM=ltztm_dmx,MXQTM=mxqtm_dmx,MNQTM=mnqtm_dmx
              								where STTDRCD='1' and STCD=stcd and IDTM =TJTM;
              							end;
                          end if;
            					end;
            				else
            					begin
            						 INSERT INTO DSE_ST_RVEVS_R(STCD,IDTM,STTDRCD,HTZ,LTZ,MXQ,MNQ,HTZTM,LTZTM,MXQTM,MNQTM,TJSTATUS)
            						 VALUES(stcd,TJTM,'1',htz,ltz_dmx,mxq_dmx,mnq_dmx,htztm_dmx,ltztm_dmx,mxqtm_dmx,mnqtm_dmx,1);
            					end	;
                    end if;

               END LOOP;

          end;
    end;

    --旬极值
   if d_day=1 or d_day=11 or d_day=21 then
      begin
            declare XUM_START_TJTM date;
                    XUM_END_TJTM date;

                    stcd char(8);
                    htz number(7,3);
                    ltz_dmx number(7,3);
                    mxq_dmx number(9,3);
                    mnq_dmx number(9,3);
                    htztm_dmx DATE;
                    ltztm_dmx DATE;
                    mxqtm_dmx DATE;
                    mnqtm_dmx DATE;
                    XUN_STCD_TJ char(8); --是否已经存在对于记录判断
		                XUN_TJSTATUS number(6,1); --统计标识
             begin
                if  d_day=1 then
          				begin
          					XUM_START_TJTM :=add_months(TO_DATE(TO_CHAR(TJTM, 'YYYY-MM') || '-21 00:00:00', 'yyyy-mm-dd hh24:mi:ss'),-1);
          				end;
            		elsif d_day=11	then
            				begin
            					XUM_START_TJTM:=TO_DATE(TO_CHAR(TJTM, 'YYYY-MM') || '-11 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
            				end;
            		elsif	d_day=21 then
            				begin
            					XUM_START_TJTM:=TO_DATE(TO_CHAR(TJTM, 'YYYY-MM') || '-21 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
            				end;
                end if;
                XUM_END_TJTM:=TJTM;


                 declare cursor lcur_river_xum_jz  is
                   select  t.stcd as stcd,n1.z as htz ,n2.z as ltz,n3.q as mxq,n4.q as mnq,
        					  n1.tm as htztm,n2.tm as ltztm,n3.tm as mxqtm,n4.tm as mnqtm from dse_st_river_real t inner join st_stbprp_b st on st.stcd=t.stcd left join
        					  (select * from (select t.stcd,t.z,t.tm, row_number() over (partition by t.stcd order by t.z desc)rn  from dse_st_river_r t
        					  where t.z is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n1
        					  on t.stcd = n1.stcd left join
        					  (select * from (select t.stcd,t.z,t.tm, row_number() over (partition by t.stcd order by t.z asc)rn  from dse_st_river_r t
        					  where t.z is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n2
        					  on t.stcd = n2.stcd left join
        					  (select * from (select t.stcd,t.q,t.tm, row_number() over (partition by t.stcd order by t.q desc)rn  from dse_st_river_r t
        					  where t.q is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n3
        					  on t.stcd = n3.stcd left join
        					  (select * from (select t.stcd,t.q,t.tm, row_number() over (partition by t.stcd order by t.q asc)rn  from dse_st_river_r t
        					  where t.q is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n4
        					  on t.stcd = n4.stcd where   n1.z is not null and st.usfl='1' and (st.sttp='ZZ' or st.sttp='ZQ');
                 begin
                       FOR dataxun IN lcur_river_xum_jz LOOP
                         stcd:= dataxun.stcd;
                         htz:=dataxun.htz;
                         ltz_dmx:=dataxun.ltz;
                         mxq_dmx:=dataxun.mxq;
                         mnq_dmx:=dataxun.mnq;
                         htztm_dmx:=dataxun.htztm;
                         ltztm_dmx:=dataxun.ltztm;
                         mxqtm_dmx:=dataxun.mxqtm;
                         mnqtm_dmx:=dataxun.mnqtm;
                         XUN_STCD_TJ:=null;
                         XUN_TJSTATUS:=null;
                        select max(STCD),max(TJSTATUS) into XUN_STCD_TJ,XUN_TJSTATUS from DSE_ST_RVEVS_R where STTDRCD='4' and STCD=stcd and IDTM =XUM_END_TJTM;

                				if XUN_STCD_TJ is not null then
                					begin
                					    if  XUN_TJSTATUS=1 then --系统自动统计值 可以修改
                  							begin
                  								update DSE_ST_RVEVS_R set HTZ=htz,LTZ=ltz_dmx,MXQ=mxq_dmx,MNQ=mnq_dmx,HTZTM=htztm_dmx,LTZTM=ltztm_dmx,MXQTM=mxqtm_dmx,MNQTM=mnqtm_dmx
                  								where STTDRCD='4' and STCD=stcd and IDTM =XUM_END_TJTM;
                  							end;
                              end if;
                					end;
                				else
                					begin
                						 INSERT INTO DSE_ST_RVEVS_R(STCD,IDTM,STTDRCD,HTZ,LTZ,MXQ,MNQ,HTZTM,LTZTM,MXQTM,MNQTM,TJSTATUS)
                						 VALUES(stcd,XUM_END_TJTM,'4',htz,ltz_dmx,mxq_dmx,mnq_dmx,htztm_dmx,ltztm_dmx,mxqtm_dmx,mnqtm_dmx,1);
                					end	;
                        end if;

                   END LOOP;
               end;
           end;
      end;
   end if;


  --月极值
	IF d_day=1 then
		 BEGIN
          DECLARE stcd_ymx char(8);
        			 htz_ymx number(7,3);
        			 ltz_ymx number(7,3);
        			 mxq_ymx number(9,3);
        			 mnq_ymx number(9,3);
        			 htztm_ymx date;
        			 ltztm_ymx date;
        			 mxqtm_ymx date;
        			 mnqtm_ymx date;
        			 MONTH_START_TJTM date;
        			 MONTH_END_TJTM date;
               STCD_MONTH_TJ char(8);
               TJSTATUS_MONTH number(6,1);
           begin
               MONTH_END_TJTM:=TJTM;
			         MONTH_START_TJTM:=add_months(MONTH_END_TJTM,-1);
               declare cursor lcur_river_ymx_jiz  is
                   select distinct t.stcd as stcd,n1.htz ,n2.ltz,n3.mxq,n4.mnq,
          				  n1.htztm,n2.ltztm,n3.mxqtm,n4.mnqtm from dse_st_river_real t inner join st_stbprp_b st on st.stcd=t.stcd left join
          				  (select * from (select t.stcd,t.htz,t.htztm, row_number() over (partition by t.stcd order by t.htz desc)rn  from DSE_ST_RVEVS_R t
          				  where t.htz is not null and t.sttdrcd='1' and idtm>=MONTH_START_TJTM and idtm <MONTH_END_TJTM ) t where t.rn = 1) n1
          				  on t.stcd = n1.stcd left join
          				  (select * from (select t.stcd,t.ltz,t.ltztm, row_number() over (partition by t.stcd order by t.ltz asc)rn  from DSE_ST_RVEVS_R t
          				  where t.ltz is not null and t.sttdrcd='1' and idtm>=MONTH_START_TJTM and idtm <MONTH_END_TJTM ) t where t.rn = 1) n2
          				  on t.stcd = n2.stcd left join
          				  (select * from (select t.stcd,t.mxq,t.mxqtm, row_number() over (partition by t.stcd order by t.mxq desc)rn  from DSE_ST_RVEVS_R t
          				  where t.mxq is not null and t.sttdrcd='1' and idtm>=MONTH_START_TJTM and idtm <MONTH_END_TJTM ) t where t.rn = 1) n3
          				  on t.stcd = n3.stcd left join
          				  (select * from (select t.stcd,t.mnq,t.mnqtm, row_number() over (partition by t.stcd order by t.mnq asc)rn  from DSE_ST_RVEVS_R t
          				  where t.mnq is not null and t.sttdrcd='1' and idtm>=MONTH_START_TJTM and idtm <MONTH_END_TJTM ) t where t.rn = 1) n4
          				  on t.stcd = n4.stcd
          				  where  n1.htz is not null and st.usfl='1' and (st.sttp='ZZ' or st.sttp='ZQ');

                begin
                     FOR datam IN lcur_river_ymx_jiz LOOP
                         stcd_ymx:= datam.stcd;
                         htz_ymx:=datam.htz;
                         ltz_ymx:=datam.ltz;
                         mxq_ymx:=datam.mxq;
                         mnq_ymx:=datam.mnq;
                         htztm_ymx:=datam.htztm;
                         ltztm_ymx:=datam.ltztm;
                         mxqtm_ymx:=datam.mxqtm;
                         mnqtm_ymx:=datam.mnqtm;
                         STCD_MONTH_TJ:=null;
                         TJSTATUS_MONTH:=null;
                        select max(STCD),max(TJSTATUS) into STCD_MONTH_TJ,TJSTATUS_MONTH from DSE_ST_RVEVS_R where STTDRCD='5' and STCD=stcd_ymx and IDTM =MONTH_END_TJTM;

                				if STCD_MONTH_TJ is not null then
                					begin
                					    if  TJSTATUS_MONTH=1 then --系统自动统计值 可以修改
                  							begin
                  								update DSE_ST_RVEVS_R set HTZ=htz_ymx,LTZ=ltz_ymx,MXQ=mxq_ymx,MNQ=mnq_ymx,HTZTM=htztm_ymx,LTZTM=ltztm_ymx,MXQTM=mxqtm_ymx,MNQTM=mnqtm_ymx
                  								where STTDRCD='5' and STCD=stcd_ymx and IDTM =MONTH_END_TJTM;
                  							end;
                              end if;
                					end;
                				else
                					begin
                						 INSERT INTO DSE_ST_RVEVS_R(STCD,IDTM,STTDRCD,HTZ,LTZ,MXQ,MNQ,HTZTM,LTZTM,MXQTM,MNQTM,TJSTATUS)
                						 VALUES(stcd_ymx,MONTH_END_TJTM,'5',htz_ymx,ltz_ymx,mxq_ymx,mnq_ymx,htztm_ymx,ltztm_ymx,mxqtm_ymx,mnqtm_ymx,1);
                					end	;
                        end if;

                   END LOOP;
                end;
           end;
     END;
  END IF;


  --年极值
	if m_day =1 and d_day =1 then
		  begin

           DECLARE stcd_nmx char(8);
        			htz_nmx number(7,3);
        			ltz_nmx number(7,3);
        			mxq_nmx number(9,3);
        			mnq_nmx number(9,3);
        			htztm_nmx date;
        			ltztm_nmx date;
        			mxqtm_nmx date;
        			mnqtm_nmx date;
        			YEAR_START_TJTM date;
        			YEAR_END_TJTM date;
              STCD_YEAR_TJ char(8);
              TJSTATUS_YEAR number(6,1);
           begin
               YEAR_END_TJTM:=TJTM;
			         YEAR_START_TJTM:=add_months(YEAR_END_TJTM,-12);

               declare cursor lcur_river_year_nmx  is
                  select distinct t.stcd as stcd,n1.htz ,n2.ltz,n3.mxq,n4.mnq,
        				  n1.htztm,n2.ltztm,n3.mxqtm,n4.mnqtm from dse_st_river_real t inner join st_stbprp_b st on st.stcd=t.stcd left join
        				  (select * from (select t.stcd,t.htz,t.htztm, row_number() over (partition by t.stcd order by t.htz desc)rn  from DSE_ST_RVEVS_R t
        				  where t.htz is not null and t.sttdrcd='5' and idtm>=YEAR_START_TJTM  and idtm<YEAR_END_TJTM) t where t.rn = 1) n1
        				  on t.stcd = n1.stcd left join
        				  (select * from (select t.stcd,t.ltz,t.ltztm, row_number() over (partition by t.stcd order by t.ltz asc)rn  from DSE_ST_RVEVS_R t
        				  where t.ltz is not null and t.sttdrcd='5' and idtm>=YEAR_START_TJTM  and idtm<YEAR_END_TJTM) t where t.rn = 1) n2
        				  on t.stcd = n2.stcd left join
        				  (select * from (select t.stcd,t.mxq,t.mxqtm, row_number() over (partition by t.stcd order by t.mxq desc)rn  from DSE_ST_RVEVS_R t
        				  where t.mxq is not null and t.sttdrcd='5' and idtm>=YEAR_START_TJTM  and idtm<YEAR_END_TJTM) t where t.rn = 1) n3
        				  on t.stcd = n3.stcd left join
        				  (select * from (select t.stcd,t.mnq,t.mnqtm, row_number() over (partition by t.stcd order by t.mnq asc)rn  from DSE_ST_RVEVS_R t
        				  where t.mnq is not null and t.sttdrcd='5'and idtm>=YEAR_START_TJTM  and idtm<YEAR_END_TJTM) t where t.rn = 1) n4
        				  on t.stcd = n4.stcd
        				  where n1.htz is not null and st.usfl='1' and (st.sttp='ZZ' or st.sttp='ZQ');

               begin
                     FOR datay IN lcur_river_year_nmx LOOP
                         stcd_nmx:= datay.stcd;
                         htz_nmx:=datay.htz;
                         ltz_nmx:=datay.ltz;
                         mxq_nmx:=datay.mxq;
                         mnq_nmx:=datay.mnq;
                         htztm_nmx:=datay.htztm;
                         ltztm_nmx:=datay.ltztm;
                         mxqtm_nmx:=datay.mxqtm;
                         mnqtm_nmx:=datay.mnqtm;
                         STCD_YEAR_TJ:=null;
                         TJSTATUS_YEAR:=null;
                        select max(STCD),max(TJSTATUS) into STCD_YEAR_TJ,TJSTATUS_YEAR from DSE_ST_RVEVS_R where STTDRCD='6' and STCD=stcd_nmx and IDTM =YEAR_END_TJTM;

                				if STCD_YEAR_TJ is not null then
                					begin
                					    if  TJSTATUS_YEAR=1 then --系统自动统计值 可以修改
                  							begin
                  								update DSE_ST_RVEVS_R set HTZ=htz_nmx,LTZ=ltz_nmx,MXQ=mxq_nmx,MNQ=mnq_nmx,HTZTM=htztm_nmx,LTZTM=ltztm_nmx,MXQTM=mxqtm_nmx,MNQTM=mnqtm_nmx
                  								where STTDRCD='6' and STCD=stcd_nmx and IDTM =YEAR_END_TJTM;
                  							end;
                              end if;
                					end;
                				else
                					begin
                						 INSERT INTO DSE_ST_RVEVS_R(STCD,IDTM,STTDRCD,HTZ,LTZ,MXQ,MNQ,HTZTM,LTZTM,MXQTM,MNQTM,TJSTATUS)
                						 VALUES(stcd_nmx,YEAR_END_TJTM,'6',htz_nmx,ltz_nmx,mxq_nmx,mnq_nmx,htztm_nmx,ltztm_nmx,mxqtm_nmx,mnqtm_nmx,1);
                					end	;
                        end if;

                   END LOOP;
                end;

           end;
      end;
  end if;
end platform_river_jiz_tj;


/

