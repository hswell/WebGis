create PROCEDURE      PLATFORM_RIVER_DETAIL_(VSTCD VARCHAR,
                                                   ST    VARCHAR,
                                                   ET    VARCHAR,
                                                   CURR1 OUT PLATFORM.CURSOR,
                                                   CURR2 OUT PLATFORM.CURSOR) IS
  VST DATE;
  VET DATE;
BEGIN
  VST := TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss');
  VET := TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss');
  --列表数据
  OPEN CURR1 FOR
    SELECT TTT.*, ROWNUM
      FROM (SELECT TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(IN_Z, 2), '99999999990.99')) IN_Z,
                   TRIM(TO_CHAR(ROUND(OUT_Z, 2), '99999999990.99')) OUT_Z
              FROM dse_st_river_kz_r
             WHERE TM >= VST
               AND TM <= VET
               AND STCD = VSTCD
             ORDER BY TM DESC) TTT;

  --图表数据
  OPEN CURR2 FOR

    select TO_CHAR(t1.tm, 'yyyy-mm-dd hh24:mi') TM,
           TRIM(TO_CHAR(ROUND(t1.Z, 2), '99999999990.99')) Z,
           t2.type TYPE
      from dse_st_river_r t1, dse_st_stbprp_b_kz t2
     where t1.stcd = t2.stcd
       and t1.tm >= VST
       AND t1.tm <= VET
       AND t2.newstcd = VSTCD
     ORDER BY TM DESC;

END PLATFORM_RIVER_DETAIL_;


/

