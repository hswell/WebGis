create procedure      platform_pptn_tj_mod_h_day_drp
is
v_time date;
v_qdate date;
d_hour int;--分钟24小时格式
d_min int;
v_stcd char(8);

	--修正日雨量
V_STCD_TJ char(8);
V_ACCP number(6,1); --累计降水量
V_TJSTATUS number(6,1) ;--统计标识
V_DAYDRP number(6,1); --统计日雨量


begin
  v_time:=TO_DATE(TO_CHAR(sysdate, 'YYYY-MM-DD')||' 00:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
  d_hour:=to_number(to_char(v_time,'hh24'));
  d_min:=to_number(to_char(v_time,'mi'));
  if (d_hour <=7) or ( d_hour=8 and d_min=0) then
	   begin
      v_qdate:=TO_DATE(TO_CHAR(v_time-1, 'YYYY-MM-DD')||' 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
	   end;
	else --08点 到23点
	   begin
			    v_qdate:=TO_DATE(TO_CHAR(v_time, 'YYYY-MM-DD')||' 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
	   end;
   end if;

    declare cursor  cur_pptn_r  is
        SELECT r.STCD from dse_st_pptn_real r inner join st_stbprp_b st on r.stcd=st.stcd and st.usfl='1';
    begin
         FOR data_row IN cur_pptn_r LOOP
             v_stcd:=data_row.stcd;

             DECLARE start_time date;
                     end_time  date;
              begin
                   start_time:=v_time;
                   end_time:=v_time-1;
                   	WHILE start_time >= end_time loop
              					begin

              					   --统计1小时累计降雨量
              					    platform_pptn_tj_1_h(v_stcd,start_time);


              						  start_time := start_time-1/24;
              					end;
                    end loop;
              end;

      			V_STCD_TJ :=null;
            V_ACCP:=null;
            V_TJSTATUS:=null;
            V_DAYDRP :=null;
            select max(STCD),max(ACCP),max(TJSTATUS) into V_STCD_TJ,V_ACCP,V_TJSTATUS from DSE_ST_PSTAT_R where STTDRCD='1' and STCD=v_stcd and IDTM =v_qdate;
            if V_STCD_TJ  is not null then
      					begin
          					if V_TJSTATUS=1 then--系统自动统计值 可以修改
          							begin

          								select sum(drp) into V_DAYDRP from dse_st_pptn_r where stcd=v_stcd and tm >v_qdate-1 and tm <=v_qdate ;

          								if 	V_DAYDRP is null then
            									begin
            										   V_DAYDRP:=0;
            									end;
                          end if;

          								if 	V_ACCP<>V_DAYDRP then
            									begin
            										 update 	DSE_ST_PSTAT_R set accp=V_DAYDRP  where STTDRCD='1' and STCD=v_stcd and IDTM =v_qdate;
            									end;
          					      end if;
                        end;
                      end if;
                  end;
      				else
        					begin

        							select sum(drp) into V_DAYDRP from dse_st_pptn_r where stcd=v_stcd and tm >v_qdate-1 and tm <=v_qdate ;

        							if 	V_DAYDRP is null then
        									begin
        										   V_DAYDRP:=0;
        									end;
                      end if;
        							insert into DSE_ST_PSTAT_R(stcd,idtm,sttdrcd,accp,tjstatus)values(v_stcd,v_qdate,'1',V_DAYDRP,1);
        					end	;

           end if;


         END LOOP;

    end;

end platform_pptn_tj_mod_h_day_drp;


/

