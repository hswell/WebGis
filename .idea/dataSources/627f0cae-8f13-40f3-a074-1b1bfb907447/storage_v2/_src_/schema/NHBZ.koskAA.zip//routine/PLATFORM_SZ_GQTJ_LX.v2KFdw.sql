create procedure      PLATFORM_SZ_GQTJ_LX(STCDS    VARCHAR,
                                             ST       VARCHAR,
                                             ET       VARCHAR,
                                             PAGEFROM INT,
                                             PAGETO   INT,
                                             CUR      OUT PLATFORM.CURSOR) is

 --liuxian dongguan 水闸工情统计  2014-07-23
 vstime VARCHAR(40);
 estime VARCHAR(40);
 begin
 vstime := st||'00:00';
 estime := et||'59:59';
  OPEN CUR FOR
    select * from (
           SELECT ROW_NUMBER() OVER(order by t.tm desc) ROWNUM_,
           t.STCD,
           t.N1,
           T.N2,
           T.N3,
           TRIM(st.STNM) STNM,
          case when t.TM IS NOT NULL THEN TO_CHAR(t.TM, 'YYYY-MM-DD HH24:MI:SS') else null end as TM,
          case  t.state when '1'  THEN '开'
          when '0' then '关' else null end as DO

      FROM (SELECT * FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS PLATFORM_STCD_TYPE))) qt,
       dse_sz_runstate_r t , st_stbprp_b st
       where qt.stcd =t.stcd and  st.stcd = t.stcd
       and t.tm >=to_date(vstime,'yyyy-mm-dd hh24:mi:ss')
       and t.tm <=to_date(estime,'yyyy-mm-dd hh24:mi:ss')
       ) TTT
     WHERE TTT.ROWNUM_> PAGEFROM
       AND TTT.ROWNUM_<= PAGETO
    order by ttt.TM DESC;

EXCEPTION
  WHEN OTHERS THEN
    NULL;

end PLATFORM_SZ_GQTJ_LX;


/

