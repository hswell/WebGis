create trigger TRIG_DSE_BZ_ALARM_LOG
    after insert or update
    on DSE_BZ_ALARM_LOG
    for each row
DECLARE
 V_CNT NUMBER;
 V_WARNTYPEID NUMBER;
 V_ID  NUMBER;
BEGIN
 --INSERT触发
 IF INSERTING THEN
   --是否属于预警的内容
  SELECT COUNT(1) INTO V_CNT FROM DSE_BZ_WARN_CONFIG T WHERE ALARM_ID = :NEW.ALARM_ID;
  IF V_CNT=1 THEN
  SELECT WARNTYPEID INTO V_WARNTYPEID FROM DSE_BZ_WARN_CONFIG T WHERE ALARM_ID = :NEW.ALARM_ID;
   V_ID:= DSE_DX_SEQUENCE.Nextval;
    --插入预警信息表
    insert into STWarnRecord_R
      (Stwarnid,
       STCD,
       WarnTypeID,
       WarnGradeID,
       STWarnNM,
       STWarnDESC,
       STWarnSTM,
       STINDEX)
    values
      (V_ID,
       100000,
       V_WARNTYPEID,
       '1',
       :NEW.ALARM_MESSAGE,
       :NEW.ALARM_MESSAGE,
       sysdate,
       'DP');
  END IF;
 END IF;
EXCEPTION
  WHEN OTHERS THEN
  ROLLBACK;
END;

/

