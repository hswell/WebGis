create PROCEDURE      PLATFORM_GKXX_HD(CURR1 OUT PLATFORM.CURSOR) IS
BEGIN
  --河道工况信息
  OPEN CURR1 FOR
    SELECT TTT.*, ROWNUM ROWNUM_
      FROM (SELECT T.STCD,
                   rtrim(S.STNM) STNM,
                   TO_CHAR(T.TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(T.Z, 2), '99999999990.99')) Z,
                  ABS(CEIL((T.TM - SYSDATE))) || '天' ||
                   (ABS(CEIL((T.TM - SYSDATE) * 24))- ABS(CEIL((T.TM - SYSDATE)))*24) || '小时' ||
                   (ABS(CEIL(((T.TM - SYSDATE)) * 24 * 60))-ABS(CEIL((T.TM - SYSDATE) * 24))*60) || '分' TIMEST
              FROM DSE_ST_RIVER_REAL T
              LEFT JOIN ST_STBPRP_B S ON T.STCD = S.STCD
                                     AND S.USFL = '1'
             WHERE T.TM < SYSDATE
             ORDER BY T.TM, T.Z DESC) TTT;
END PLATFORM_GKXX_HD;


/

