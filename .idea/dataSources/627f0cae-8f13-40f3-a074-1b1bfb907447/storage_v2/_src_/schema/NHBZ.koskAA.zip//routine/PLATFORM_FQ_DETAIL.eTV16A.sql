create PROCEDURE      PLATFORM_FQ_DETAIL(VSTCD VARCHAR,
                                               ST    VARCHAR,
                                               ET    VARCHAR,
                                               CURR1 OUT PLATFORM.CURSOR) IS
  --  author chenya
--  date 2013-11-04
--  风情图表查询
  VST DATE;
  VET DATE;
BEGIN
  VST := TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss');
  VET := TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss');

  OPEN CURR1 FOR
    SELECT TT.*, ROWNUM
      FROM (SELECT TO_CHAR(DT, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(WIND, 2), '99999999990.99')) WIND,
                   case
                     when DIRECTORY = 0 then
                      '北风'
                     when DIRECTORY > 0 and DIRECTORY < 90 then
                      '东北风'
                     when DIRECTORY = 90 then
                      '东风'
                     when DIRECTORY > 90 and DIRECTORY < 180 then
                      '东南风'
                     when DIRECTORY = 180 then
                      '南风'
                     when DIRECTORY > 180 and DIRECTORY < 270 then
                      '西南风'
                     when DIRECTORY = 270 then
                      '西风'
                     when DIRECTORY > 270 and DIRECTORY < 360 then
                      '西北风'
                   end FENGXIANG,

                   TRIM(TO_CHAR(ROUND(DIRECTORY, 2), '99999999990.99')) DIRECTORY
              FROM dse_st_rtu_air_r
             WHERE DT > VST
               AND DT <= VET
               AND STCD = VSTCD
             ORDER BY TM DESC) TT;
END PLATFORM_FQ_DETAIL;


/

