create procedure      platform_pptn_tj_1_h(p_stcd varchar,p_tm date)
 is
 v_time date;
 DRP_H number(5,1);
 v_stcd char(8);
 v_drp number(5,1);
begin
    if p_stcd is null or p_tm is null then
    		return;
    end if;
  v_time:=TO_DATE(TO_CHAR(p_tm, 'YYYY-MM-dd hh24') || ':00:00', 'yyyy-mm-dd hh24:mi:ss');

  SELECT SUM(DRP) into DRP_H  FROM DSE_ST_PPTN_R WHERE TM>v_time-1/24  AND TM<=v_time AND STCD = p_stcd;
  if 	DRP_H is null then
  		begin
  			  DRP_H:=0 ;
  		end;
  end if;

  --判断小时表是否存在记录
	select max(stcd),max(drp) into v_stcd,v_drp from DSE_ST_PPTN_H  where STCD =p_stcd and TM =v_time;
	IF v_stcd is null then--当前记录不存在
		BEGIN --执行insert
  			INSERT INTO DSE_ST_PPTN_H(STCD,TM,DRP)
  			VALUES(p_stcd,v_time,DRP_H);
		END;
	ELSE
		BEGIN --执行更新
        if DRP_H<> v_drp then
           begin
               UPDATE DSE_ST_PPTN_H SET DRP=DRP_H where STCD =p_stcd and TM =v_time;
           end;
        end if;

		END ;
  end if;


end platform_pptn_tj_1_h;


/

