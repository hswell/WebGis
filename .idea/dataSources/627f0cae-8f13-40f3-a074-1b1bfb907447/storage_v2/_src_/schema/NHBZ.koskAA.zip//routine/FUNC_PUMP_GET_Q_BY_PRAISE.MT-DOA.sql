create FUNCTION      FUNC_PUMP_GET_Q_BY_PRAISE(MODALVALUE IN varchar2,--机组型号
                                                 ANGLEVALUE IN varchar2, --叶片安放角度
                                                 PVALUE    IN NUMERIC) --扬程/*用于关联的参考数据*/
  RETURN NUMBER IS
  V         NUMERIC(18, 8);
  X1        NUMERIC(18, 8);
  Y1        NUMERIC(18, 8);
  X2        NUMERIC(18, 8);
  Y2        NUMERIC(18, 8);
  X3        NUMERIC(18, 8);
  Y3        NUMERIC(18, 8);
  X4        NUMERIC(18, 8);
  Y4        NUMERIC(18, 8);
  ROWSIZE   INT := 0;
  VARCURSOR SYS_REFCURSOR;
  CURSOR TMPCURSOR IS
    SELECT PRAISE, Q FROM Dse_PumpQ WHERE 1 = 2;
  R TMPCURSOR%ROWTYPE;
  --根据河道水位计算流量
BEGIN
  IF MODALVALUE IS NULL OR ANGLEVALUE IS NULL OR  PVALUE IS NULL THEN
    RETURN NULL;
  END IF;

  --游标大小
  OPEN VARCURSOR FOR
    SELECT B.PRAISE, B.Q --PRAISE为扬程,Q为流量
      FROM (SELECT *
              FROM (SELECT PRAISE, Q
                      FROM (SELECT PRAISE, Q
                              FROM Dse_PumpQ
                             WHERE PRAISE >= PVALUE
                               AND WATERPUMP_MODAL = MODALVALUE
                               AND ANGLE = ANGLEVALUE
                             ORDER BY PRAISE)
                     WHERE ROWNUM <= 2) A1
            UNION ALL

            SELECT CASE
                     WHEN PRAISE = PVALUE THEN
                      PRAISE
                     ELSE
                      PRAISE
                   END AS PRAISE,
                   Q
              FROM (SELECT PRAISE, Q
                      FROM (SELECT PRAISE, Q
                              FROM Dse_PumpQ
                             WHERE PRAISE <= PVALUE
                               AND WATERPUMP_MODAL = MODALVALUE
                               AND ANGLE = ANGLEVALUE
                             ORDER BY PRAISE DESC)
                     WHERE ROWNUM <= 2) A2

            ) B
     WHERE B.PRAISE IS NOT NULL
     ORDER BY B.PRAISE;

  LOOP
    FETCH VARCURSOR
      INTO R;
    EXIT WHEN VARCURSOR%NOTFOUND;
    IF ROWSIZE = 0 THEN
      X1 := R.PRAISE;
      Y1 := R.Q;
    ELSIF ROWSIZE = 1 THEN
      X2 := R.PRAISE;
      Y2 := R.Q;
    ELSIF ROWSIZE = 2 THEN
      X3 := R.PRAISE;
      Y3 := R.Q;
    ELSIF ROWSIZE = 3 THEN
      X4 := R.PRAISE;
      Y4 := R.Q;
    END IF;
    ROWSIZE := ROWSIZE + 1;
  END LOOP;

  IF ROWSIZE = 4 THEN
    IF (ABS(X2 - PVALUE) < ABS(X3 - PVALUE)) THEN
      V := FUNC_THREE_SPOT_METHOD(X1, Y1, X2, Y2, X3, Y3, PVALUE);
    ELSE
      V := FUNC_THREE_SPOT_METHOD(X2, Y2, X3, Y3, X4, Y4, PVALUE);
    END IF;
  ELSIF ROWSIZE = 3 THEN
    V := FUNC_THREE_SPOT_METHOD(X1, Y1, X2, Y2, X3, Y3, PVALUE);
  ELSIF ROWSIZE = 2 THEN
    IF X1 >= PVALUE THEN
      V := Y1;
    ELSE
      V := Y2;
    END IF;
  END IF;

  RETURN V;
END FUNC_PUMP_GET_Q_BY_PRAISE;


/

