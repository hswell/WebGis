create procedure      PLATFORM_BZ_SWXXCX(VSTCD VARCHAR,
                                               ST    VARCHAR,
                                               ET    VARCHAR,
                                               CURR1 OUT PLATFORM.CURSOR,
                                               CURR2 OUT PLATFORM.CURSOR) is
  /**
  *AUTHOR:TICHSTAR
  *DESCRIPTION:泵站--单站》水位信息查询
  *DATE:2013年7月30日13:47:51
  */
  VST DATE;
  VET DATE;
begin
  VST := TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss');
  VET := TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss');
  OPEN CURR1 FOR
    SELECT TTT.*, ROWNUM
      FROM (SELECT DISTINCT TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                            TRIM(TO_CHAR(ROUND(FOREBAYZ, 2),
                                         '99999999990.99')) FOREBAYZ,
                            -- TRIM(TO_CHAR(ROUND(OPZ, 2), '99999999990.99')) OPZ,
                            TRIM(TO_CHAR(ROUND(NSW, 2), '99999999990.99')) NSW,
                            TRIM(TO_CHAR(ROUND(WSW, 2), '99999999990.99')) WSW,
                            --STATE,
                            --状态 1：开 0 关 2 故障
                            DECODE(FUNC_BZ_BZZT(STCD, TM),
                                   '1',
                                   '开',
                                   '0',
                                   '关',
                                   '故障') BZSTATE
            -- AIRCREWNM
            --FUNC_BZ_JZZT(STCD, TM) JZZT
            --  FUNC_NUMERIC(LL, 3) LL
              FROM DSE_BZ_RUNINFO_R
             WHERE TM >= VST
               AND TM <= VET
               AND STCD = VSTCD
             ORDER BY TM DESC) TTT;
  OPEN CURR2 FOR
    SELECT TO_CHAR(R.TM, 'YYYY-MM-DD HH24:MI:SS') RTM,
           R.NSW RNSW,
           R.WSW RWSW,
           TO_CHAR(NMA.MATM, 'YYYY-MM-DD HH24:MI:SS') MANTM,
           NMA.MANSW,
           TO_CHAR(WMA.MATM, 'YYYY-MM-DD HH24:MI:SS') MAWTM,
           WMA.MAWSW,

           TO_CHAR(NMI.MITM, 'YYYY-MM-DD HH24:MI:SS') MINTM,
           NMI.MINSW,
           TO_CHAR(WMI.MITM, 'YYYY-MM-DD HH24:MI:SS') MIWTM,
           WMI.MIWSW
      FROM (SELECT DISTINCT T.TM, T.NSW, T.WSW
              FROM DSE_BZ_RUNINFO_REAL T
             WHERE T.STCD = VSTCD) R,
           (SELECT DISTINCT MA.TM AS MATM, MA.NSW AS MANSW
              FROM (SELECT M.NSW, M.TM
                      FROM DSE_BZ_RUNINFO_R M
                     WHERE M.STCD = VSTCD
                       AND M.TM >= VST
                       AND M.TM <= VET
                     ORDER BY M.NSW DESC) MA
             WHERE ROWNUM = 1) NMA,

           (SELECT DISTINCT MA.TM AS MATM, MA.WSW AS MAWSW
              FROM (SELECT M.WSW, M.TM
                      FROM DSE_BZ_RUNINFO_R M
                     WHERE M.STCD = VSTCD
                       AND M.TM >= VST
                       AND M.TM <= VET
                     ORDER BY M.WSW DESC) MA
             WHERE ROWNUM = 1) WMA,

           (SELECT DISTINCT MI.TM AS MITM, MI.NSW AS MINSW
              FROM (SELECT M.NSW, M.TM
                      FROM DSE_BZ_RUNINFO_R M
                     WHERE M.STCD = VSTCD
                       AND M.TM >= VST
                       AND M.TM <= VET
                     ORDER BY M.NSW ASC) MI
             WHERE ROWNUM = 1) NMI,
           (SELECT DISTINCT MI.TM AS MITM, MI.WSW AS MIWSW
              FROM (SELECT M.WSW, M.TM
                      FROM DSE_BZ_RUNINFO_R M
                     WHERE M.STCD = VSTCD
                       AND M.TM >= VST
                       AND M.TM <= VET
                     ORDER BY M.WSW ASC) MI
             WHERE ROWNUM = 1) WMI;

end PLATFORM_BZ_SWXXCX;


/

