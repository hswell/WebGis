create procedure      PLATFORM_CZ_DETAIL(VSTCD VARCHAR,
                                               ST    VARCHAR,
                                               ET    VARCHAR,
                                               CURR1 OUT PLATFORM.CURSOR,
                                               CURR2 OUT PLATFORM.CURSOR,
                                               CURR3 OUT PLATFORM.CURSOR) is
  VST DATE;
  VET DATE;
begin
  -- =============================================
  -- Author:    chens
  -- Create date: 2014-01-06
  -- Description: 船闸详细信息 珠三角需求
  -- =============================================
  VST := TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss');
  VET := TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss');

  open CURR1 for
    SELECT TTT.*, ROWNUM
      FROM (SELECT TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                   row_number() over(order by Tm DESC),
                   TRIM(TO_CHAR(ROUND(ON_Z, 2), '99999999990.99')) ON_Z,
                   TRIM(TO_CHAR(ROUND(DOWN_Z, 2), '99999999990.99')) DOWN_Z,
                   TRIM(TO_CHAR(ROUND(MID_Z, 2), '99999999990.99')) MID_Z
              FROM dse_cz_ship_kz_r
             WHERE TM >= VST
               AND TM <= VET
               AND STCD = VSTCD) TTT;

  open CURR2 for
    select TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
           TRIM(TO_CHAR(ROUND(t1.Z, 2), '99999999990.99')) Z,
           TRIM(TO_CHAR(ROUND(t1.in_z, 2), '99999999990.99')) IN_Z,
           t2.type TYPE
      from dse_cz_ship_r t1, dse_st_stbprp_b_kz t2
     where t1.stcd = t2.stcd
       and t1.tm >= VST
       AND t1.tm <= VET
       AND t2.newstcd = VSTCD
     ORDER BY TM DESC;

  open CURR3 for
    select case t2.type
             when '1' then
              '前闸'
             else
              '后闸'
           end name,
           TO_CHAR(t1.tm, 'yyyy-mm-dd hh24:mi') tm,
           t1.state
      from dse_sz_runstate_r t1, dse_st_stbprp_b_kz t2
     where t1.stcd = t2.stcd
       and t1.tm >= VST
       AND t1.tm <= VET
       and t2.newstcd = VSTCD
     order by t1.stcd, t1.tm;

end PLATFORM_CZ_DETAIL;


/

