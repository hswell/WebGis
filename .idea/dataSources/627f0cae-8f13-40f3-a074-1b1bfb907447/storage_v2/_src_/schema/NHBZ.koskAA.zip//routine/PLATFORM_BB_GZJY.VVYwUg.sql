create PROCEDURE      PLATFORM_BB_GZJY(STCDS VARCHAR,
                                             ST    VARCHAR,
                                             ET    VARCHAR,
                                             CUR1  OUT PLATFORM.CURSOR) IS

  STARTTIME DATE;
  ENDTIME   DATE;
BEGIN
  -- 各站累积降雨表
  STARTTIME := TO_DATE(ST || ':00:00', 'yyyy-mm-dd hh24:mi:ss');
  ENDTIME   := TO_DATE(ET || ':00:00', 'yyyy-mm-dd hh24:mi:ss');

 /* OPEN CUR1 FOR WITH SQL1 AS(
    SELECT ROWNUM, T2.STNM, T1.DRP
      FROM (SELECT AA.STCD, SUM(AA.DRP) DRP
              FROM DSE_ST_PPTN_H AA,
                   (SELECT * FROM TABLE(FUNC_SPLITSTRING(STCDS))) BB
             WHERE TM > STARTTIME
               AND TM <= ENDTIME
               AND AA.STCD = BB.STCD
             GROUP BY AA.STCD) T1,
           ST_STBPRP_B T2
     WHERE T1.STCD = T2.STCD)
      SELECT T1.STNM, T1.DRP, T2.STNM STNM1, T2.DRP DRP1
        FROM (SELECT *
          FROM (SELECT Q1.*, ROWNUM AROWNUM FROM SQL1 Q1)
         WHERE MOD(AROWNUM, 2) = 1) T1
        LEFT JOIN (SELECT *
               FROM (SELECT Q2.*, ROWNUM BROWNUM FROM SQL1 Q2)
              WHERE MOD(BROWNUM, 2) = 0) T2 ON T1.AROWNUM =
                                               T2.BROWNUM - 1
      UNION ALL
      SELECT '平均雨量' STNM, AVG(DRP) DRP, NULL STNM1, NULL DRP1
        FROM SQL1 HAVING COUNT(1)>0;*/

    --没雨量也要补充空行
    OPEN CUR1 FOR WITH SQL1 AS(
    SELECT ROWNUM, T2.STNM, T1.DRP
      FROM (SELECT BB.STCD, SUM(AA.DRP) DRP
              FROM
                   (SELECT * FROM TABLE(FUNC_SPLITSTRING(STCDS))) BB LEFT JOIN DSE_ST_PPTN_H AA
                   ON AA.STCD = BB.STCD
             AND TM > STARTTIME
               AND TM <= ENDTIME
              -- AND AA.STCD = BB.STCD
             GROUP BY BB.STCD) T1,
           ST_STBPRP_B T2
     WHERE T1.STCD = T2.STCD)
      SELECT T1.STNM, T1.DRP, T2.STNM STNM1, T2.DRP DRP1
        FROM (SELECT *
          FROM (SELECT Q1.*, ROWNUM AROWNUM FROM SQL1 Q1)
         WHERE MOD(AROWNUM, 2) = 1) T1
        LEFT JOIN (SELECT *
               FROM (SELECT Q2.*, ROWNUM BROWNUM FROM SQL1 Q2)
              WHERE MOD(BROWNUM, 2) = 0) T2 ON T1.AROWNUM =
                                               T2.BROWNUM - 1
      UNION ALL
      SELECT '平均雨量' STNM, AVG(DRP) DRP, NULL STNM1, NULL DRP1
        FROM SQL1 HAVING COUNT(1)>0;

END PLATFORM_BB_GZJY;


/

