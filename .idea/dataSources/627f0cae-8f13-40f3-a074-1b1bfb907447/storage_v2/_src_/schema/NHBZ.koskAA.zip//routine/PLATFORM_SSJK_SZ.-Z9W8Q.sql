create PROCEDURE      PLATFORM_SSJK_SZ(VSTNM    VARCHAR,
                                             VADDVCD  VARCHAR,
                                             VQY      VARCHAR,
                                             VTYPE    INTEGER,
                                             ISWARING VARCHAR,
                                             CURR     OUT PLATFORM.CURSOR) IS

  RED      VARCHAR(10);
  ORANGE   VARCHAR(10);
  NORMAL   VARCHAR(10);
  RANGE    NUMBER(5, 1);
  VMAPTYPE VARCHAR(20) := '1';
BEGIN
   SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR, maptype
    INTO RED, ORANGE, RANGE, NORMAL, VMAPTYPE
    FROM DSE_WARNING_PARAM;

  OPEN CURR FOR
  select * from (
    SELECT NVL(T2.STNM, T1.STCD) STNM,
           T1.STCD,
           'DD' STTP,
           case
             when VMAPTYPE = '2' then
              func_gis_lonmercator(T2.LGTD)
             else
              T2.LGTD
           end LGTD,
           case
             when VMAPTYPE = '2' then
              func_gis_latmercator(T2.LTTD)
             else
              T2.LTTD
           end LTTD,
           t3.maxscale,
           t3.minscale,
           t3.vifl,
          -- TO_CHAR(getadnm(T2.ADDVCD)) ADNM,
           TO_CHAR(T1.TM, 'yyyy-mm-dd hh24:mi') TM,
           TRIM(TO_CHAR(ROUND(T1.OUT_WATER, 2), '99999999990.99')) OUT_WATER,
           TRIM(TO_CHAR(ROUND(T1.IN_WATER, 2), '99999999990.99')) IN_WATER,
           TO_CHAR(getadnm(T2.ADDVCD)) ADNM,
           DECODE(T1.N1, '9', '', T1.N1) || DECODE(T1.N2, '9', '', T1.N2) ||
           DECODE(T1.N3, '9', '', T1.N3) || DECODE(T1.N4, '9', '', T1.N4) ||
           DECODE(T1.N5, '9', '', T1.N5) || DECODE(T1.N6, '9', '', T1.N6) ||
           DECODE(T1.N7, '9', '', T1.N7) || DECODE(T1.N8, '9', '', T1.N8) ||
           DECODE(T1.N9, '9', '', T1.N9) SZKGQK,
           FUNC_NUMERIC(T1.LL, 3) LL,
           CASE
             WHEN t8.OUT_WATER IS not NULL and t1.OUT_WATER IS not null and t1.OUT_WATER>t8.OUT_WATER THEN
              RED
             WHEN t8.IN_WATER IS not NULL and t1.IN_WATER IS not null and t1.IN_WATER>t8.IN_WATER THEN
              RED
              WHEN t8.OUT_WATER IS not NULL and t1.OUT_WATER IS not null and t8.OUT_WATER-t1.OUT_WATER <= RANGE THEN
              ORANGE
             WHEN t8.IN_WATER IS not NULL and t1.IN_WATER IS not null and t8.IN_WATER-t1.IN_WATER <= RANGE THEN
              ORANGE
             ELSE
              NORMAL
             END COLOR,

             CASE
             WHEN t8.OUT_WATER IS not NULL and t1.OUT_WATER IS not null and t1.OUT_WATER>t8.OUT_WATER THEN
              1
             WHEN t8.IN_WATER IS not NULL and t1.IN_WATER IS not null and t1.IN_WATER>t8.IN_WATER THEN
              1
              WHEN t8.OUT_WATER IS not NULL and t1.OUT_WATER IS not null and t8.OUT_WATER-t1.OUT_WATER <= RANGE THEN
              1
             WHEN t8.IN_WATER IS not NULL and t1.IN_WATER IS not null and t8.IN_WATER-t1.IN_WATER <= RANGE THEN
              1
             ELSE
              0
             END WARNINGBJ,

            CASE
             WHEN t8.OUT_WATER IS not NULL and t1.OUT_WATER IS not null and t1.OUT_WATER>t8.OUT_WATER THEN
				t1.OUT_WATER - t8.OUT_WATER + 9999999
             WHEN t8.IN_WATER IS not NULL and t1.IN_WATER IS not null and t1.IN_WATER>t8.IN_WATER THEN
				t1.IN_WATER - t8.IN_WATER + 9999999
              WHEN t8.OUT_WATER IS not NULL and t1.OUT_WATER IS not null and t8.OUT_WATER-t1.OUT_WATER <= RANGE THEN
				t1.OUT_WATER - t8.OUT_WATER + 999999
             WHEN t8.IN_WATER IS not NULL and t1.IN_WATER IS not null and t8.IN_WATER-t1.IN_WATER <= RANGE THEN
				t1.IN_WATER - t8.IN_WATER + 999999
             ELSE
              T1.IN_WATER
             END orderbyIndex

      FROM DSE_SZ_RUNINFO_REAL T1
      left join DSE_SZ_RUNINFO_RULE t8 on t8.STCD=t1.STCD
      LEFT JOIN ST_STBPRP_B T2
        ON T1.STCD = T2.STCD
      LEFT JOIN dse_st_label_set t3
        on rtrim(T3.STCD) = rtrim(T1.STCD)
       and t3.layerid = 2
     WHERE (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')
       AND (VADDVCD IS NULL OR T2.ADDVCD LIKE VADDVCD || '%')
       AND (T2.RVNM LIKE '%' || CASE VTYPE
             WHEN 1 THEN
              nvl(VQY, '')
             ELSE
              ''
           END || '%' OR T2.HNNM LIKE '%' || CASE VTYPE
             WHEN 2 THEN
              nvl(VQY, '')
             ELSE
              ''
           END || '%' OR T2.BSNM LIKE '%' || CASE VTYPE
             WHEN 3 THEN
              nvl(VQY, '')
             ELSE
              ''
           END || '%' OR '10' = '1' || CASE
             WHEN VQY is null THEN
              '0'
             ELSE
              ''
           END)

     --ORDER BY T1.IN_WATER DESC;
     )ttttt where ttttt.WARNINGBJ like '%' || ISWARING || '%'
			order by ttttt.orderbyIndex desc;
END PLATFORM_SSJK_SZ;


/

