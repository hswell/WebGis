create PROCEDURE      PLATFORM_SSJK_PPTN(VSTNM    VARCHAR,
                                               VTYPE    NUMBER,
                                               CODE     VARCHAR,
                                               BGDATE   VARCHAR,
                                               ENDDATE  VARCHAR,
                                               ISWARING VARCHAR,
                                               VMAPTYPE VARCHAR,
                                               CURR     OUT PLATFORM.CURSOR) IS
  RED    VARCHAR(10);
  ORANGE VARCHAR(10);
  NORMAL VARCHAR(10);
  RANGE  NUMBER(5, 1);
BEGIN
  SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR
    INTO RED, ORANGE, RANGE, NORMAL
    FROM DSE_WARNING_PARAM;

  --雨量站测报的水库水情实时信息
  --ISWARING 用于判断是否报警，''所有，1报警，0非报警。
  IF VTYPE <> 0 THEN
    OPEN CURR FOR
      SELECT *
        FROM (SELECT NVL(T2.STNM, T2.STCD) STNM,
                    TO_CHAR(getadnm(T2.ADDVCD)) ADNM,
                    T2.ADDVCD,
                     T2.STCD,
                     'PP' STTP,
                     case
                       when VMAPTYPE = '2' then
                        func_gis_lonmercator(T2.LGTD)
                       else
                        T2.LGTD
                     end LGTD,
                     case
                       when VMAPTYPE = '2' then
                        func_gis_latmercator(T2.LTTD)
                       else
                        T2.LTTD
                     end LTTD,
                     T4.MAXSCALE,
                     T4.MINSCALE,
                     T4.SHOWLABELSCALE,
                     T4.VIFL,
                     TO_CHAR(MAX(T1.TM), 'yyyy-mm-dd hh24:mi') TM,

                     case
                       when ROUND(SUM(DRP)) is not null then
                        TRIM(TO_CHAR(ROUND(SUM(DRP), 1), '99999999990.9'))
                       else
                        '0.0'
                     end DRP,
                     T5.TM TMWARING,
                     T5.WINFO,
                     CASE
                       WHEN T5.WINFO IS NULL THEN
                        '0'
                       ELSE
                        '1'
                     END WARNING,
                     CASE
                       WHEN T5.WINFO IS NULL THEN
                        NORMAL
                       ELSE
                        RED

                     END COLOR

                FROM (SELECT  T2.*
                        FROM DSE_ST_PPTN_REAL T1, ST_STBPRP_B T2
                       WHERE T1.STCD = T2.STCD and t2.sttp in('PP','MM') and t2.usfl='1') T2
                LEFT JOIN DSE_ST_PPTN_R T1
                  ON T1.STCD = T2.STCD
                 AND T1.TM >= SYSDATE - VTYPE / 24
                LEFT JOIN DSE_ST_LABEL_SET T4
                  ON RTRIM(T4.STCD) = RTRIM(T2.STCD)
                 AND T4.LAYERID = 1

                LEFT JOIN (SELECT STCD,
                                 TM,
                                 SUBSTR(MAX(SYS_CONNECT_BY_PATH(WINFO, '；')),
                                        2) WINFO
                            FROM (SELECT STCD,
                                         TM,
                                         WINFO,
                                         RANK() OVER(PARTITION BY STCD ORDER BY TO_NUMBER(INDEXW)) RN
                                    FROM (SELECT STCD,
                                                 TM,

                                                 WINFO,
                                                 CASE
                                                   WHEN FUNC_ISNUMBER(SUBSTR(WINFO, 1, 2)) = 1 THEN
                                                    SUBSTR(WINFO, 1, 2)
                                                   ELSE
                                                    SUBSTR(WINFO, 1, 1)
                                                 END INDEXW,
                                                 RANK() OVER(PARTITION BY STCD ORDER BY TM DESC) ROWN
                                            FROM DSE_WARN_INFO
                                           WHERE TM >= SYSDATE - VTYPE / 24
                                             AND STINDEX = 'PP') T
                                   WHERE T.ROWN = 1)
                           START WITH RN = 1
                          CONNECT BY RN - 1 = PRIOR RN
                           GROUP BY STCD, TM) T5
                  ON T5.STCD = T1.STCD

               WHERE (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')
              -- AND TM >= SYSDATE - INTERVAL VTYPE HOUR
               GROUP BY NVL(T2.STNM, T2.STCD),
                        T2.STCD,
                        LGTD,
                        LTTD,
                        T4.MAXSCALE,
                        T4.VIFL,
                        T4.MINSCALE,
                        T5.WINFO,
                        T5.TM,TO_CHAR(getadnm(T2.ADDVCD)),T2.ADDVCD)
       WHERE WARNING LIKE '%' || ISWARING || '%' AND ADDVCD LIKE nvl(CODE, '') || '%'
       ORDER BY WARNING DESC, DRP DESC;
  ELSE
    OPEN CURR FOR
      SELECT *
        FROM (SELECT NVL(T2.STNM, T2.STCD) STNM,
        TO_CHAR(getadnm(T2.ADDVCD)) ADNM,
        T2.ADDVCD,
                     T2.STCD,
                     'PP' STTP,
                     --TO_CHAR(getadnm(T2.ADDVCD)) ADNM,
                     case
                       when VMAPTYPE = '2' then
                        func_gis_lonmercator(T2.LGTD)
                       else
                        T2.LGTD
                     end LGTD,
                     case
                       when VMAPTYPE = '2' then
                        func_gis_latmercator(T2.LTTD)
                       else
                        T2.LTTD
                     end LTTD,
                     T4.MAXSCALE,
                     T4.MINSCALE,
                     T4.VIFL,
                     TO_CHAR(MAX(T1.TM), 'yyyy-mm-dd hh24:mi') TM,
                     case
                       when ROUND(SUM(DRP)) is not null then
                        TRIM(TO_CHAR(ROUND(SUM(DRP), 1), '99999999990.9'))
                       else
                        '0.0'
                     end DRP,
                     TO_CHAR(T5.TM, 'hh24:mi') TMWARING,
                     T5.WINFO,
                     CASE
                       WHEN T5.WINFO IS NULL THEN
                        '0'
                       ELSE
                        '1'
                     END WARNING,
                     CASE
                       WHEN T5.WINFO IS NULL THEN
                        NORMAL
                       ELSE
                        RED
                     END COLOR
                FROM (SELECT  T2.*
                        FROM DSE_ST_PPTN_REAL T1, ST_STBPRP_B T2
                       WHERE T1.STCD = T2.STCD and t2.sttp in('PP','MM')   and t2.usfl='1') T2
                LEFT JOIN DSE_ST_PPTN_R T1
                  ON T1.STCD = T2.STCD
                 AND T1.TM > TO_DATE(BGDATE, 'yyyy-mm-dd hh24:mi:ss')
                 AND T1.TM <= TO_DATE(ENDDATE, 'yyyy-mm-dd hh24:mi:ss')
                LEFT JOIN DSE_ST_LABEL_SET T4
                  ON RTRIM(T4.STCD) = RTRIM(T2.STCD)
                 AND T4.LAYERID = 1

                LEFT JOIN (SELECT STCD,
                                 TM,
                                 SUBSTR(MAX(SYS_CONNECT_BY_PATH(WINFO, '；')),
                                        2) WINFO
                            FROM (SELECT STCD,
                                         TM,
                                         WINFO,
                                         RANK() OVER(PARTITION BY STCD ORDER BY TO_NUMBER(INDEXW)) RN
                                    FROM (SELECT STCD,
                                                 TM,
                                                 WINFO,
                                                 CASE
                                                   WHEN FUNC_ISNUMBER(SUBSTR(WINFO,
                                                                             1,
                                                                             2)) = 1 THEN
                                                    SUBSTR(WINFO, 1, 2)
                                                   ELSE
                                                    SUBSTR(WINFO, 1, 1)
                                                 END INDEXW,
                                                 RANK() OVER(PARTITION BY STCD ORDER BY TM DESC) ROWN
                                            FROM DSE_WARN_INFO
                                           WHERE TM >
                                                 TO_DATE(BGDATE,
                                                         'yyyy-mm-dd hh24:mi:ss')
                                             AND TM <=
                                                 TO_DATE(ENDDATE,
                                                         'yyyy-mm-dd hh24:mi:ss')
                                             AND STINDEX = 'PP') T
                                   WHERE T.ROWN = 1)
                           START WITH RN = 1
                          CONNECT BY RN - 1 = PRIOR RN
                           GROUP BY STCD, TM) T5
                  ON T5.STCD = T1.STCD
               WHERE (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')
               GROUP BY NVL(T2.STNM, T2.STCD),
                        T2.STCD,
                        LGTD,
                        LTTD,
                        T4.MAXSCALE,
                        T4.VIFL,
                        T4.MINSCALE,
                        T5.WINFO,
                        T5.TM,TO_CHAR(getadnm(T2.ADDVCD)),T2.ADDVCD)
       WHERE WARNING LIKE '%' || ISWARING || '%' AND ADDVCD LIKE nvl(CODE, '') || '%'
       ORDER BY WARNING DESC, DRP DESC;
  END IF;
END PLATFORM_SSJK_PPTN;


/

