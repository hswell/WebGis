create function      FUNC_CZ_ZMZT(VSTCD CHAR) return integer is
  Result integer;
begin
  -- 返回船闸的实时状态
  select state
    into Result
    from (select state
            from dse_sz_runstate_r
           where STCD = VSTCD
           order by TM desc)
   where rownum = 1;

  return(Result);
end FUNC_CZ_ZMZT;


/

