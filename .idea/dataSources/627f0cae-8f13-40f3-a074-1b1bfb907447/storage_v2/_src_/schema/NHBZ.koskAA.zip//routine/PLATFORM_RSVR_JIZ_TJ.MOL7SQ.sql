create procedure      PLATFORM_RSVR_JIZ_TJ(p_tm date)
is
 TJTM date;--统计时间
 m_day int;--月格式
 d_day int;--天格式

  v_stcd char(8);
  htrz_jz  number(7,3);
  ltrz_jz  number(7,3);
  mxinq_jz  number(9,3);
  mninq_jz  number(9,3);
  mxotq_jz  number(9,3);
  mnotq_jz  number(9,3);
  mxw_jz  number(9,3);
  mnw_jz  number(9,3);
  htrztm_jz  DATE;
  ltrztm_jz  date;
  mxinqtm_jz  DATE;
  mninqtm_jz  DATE;
  mxotqtm_jz  DATE;
  mnotqtm_jz  DATE;
  mxwtm_jz  DATE;
  mnwtm_jz  DATE;

  V_STCD_TJ char(8);
  V_TJSTATUS number(6,1);

  XUM_START_TJTM date;--旬开始时间
  XUM_END_TJTM date;--旬结束时间

  MONTH_START_TJTM date;
	MONTH_END_TJTM date;

  YEAR_START_TJTM date;
	YEAR_END_TJTM date;
begin
  if p_tm is null then
		begin
       TJTM:=TO_DATE(TO_CHAR(sysdate, 'YYYY-MM-DD') || ' 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
		end;
	else
		begin
			 TJTM:=TO_DATE(TO_CHAR(p_tm, 'YYYY-MM-DD') || ' 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
		end;
  end if;
  m_day:=to_number(to_char(TJTM,'mm'));
  d_day:=to_number(to_char(TJTM,'dd'));


   declare cursor  lcur_rsvr_day_jz  is
        select r.stcd as stcd,n1.rz as htrz ,n2.rz as ltrz,n3.inq as mxinq,n4.inq as mninq,n5.otq as mxotq,n6.otq as mnotq,n7.w as mxw,n8.w as mnw
  		  ,n1.tm as htrztm,n2.tm as ltrztm,n3.tm as mxinqtm,n4.tm as mninqtm,n5.tm as mxotqtm,n6.tm as mnotqtm,n7.tm as mxwtm,n8.tm as mnwtm from
  		  dse_st_rsvr_real r  inner join st_stbprp_b st on st.stcd=r.stcd
  		  left join
  		  (select * from (select t.stcd,t.rz,t.tm, row_number() over (partition by t.stcd order by t.rz desc)rn
  			  from dse_st_rsvr_r t where t.rz is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n1
  		  on r.stcd=n1.stcd
  		  left join
  		  (select * from (select t.stcd,t.rz,t.tm, row_number() over (partition by t.stcd order by t.rz asc)rn
  			  from dse_st_rsvr_r t where t.rz is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n2
  		  on r.stcd = n2.stcd
  		  left join
  		  (select * from (select t.stcd,t.inq,t.tm, row_number() over (partition by t.stcd order by t.inq desc)rn
  			  from dse_st_rsvr_r t where t.inq is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n3
  		  on r.stcd = n3.stcd
  		  left join
  		  (select * from (select t.stcd,t.inq,t.tm, row_number() over (partition by t.stcd order by t.inq asc)rn
  			  from dse_st_rsvr_r t where t.inq is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n4
  		  on r.stcd = n4.stcd
  		  left join
  		  (select * from (select t.stcd,t.otq,t.tm, row_number() over (partition by t.stcd order by t.otq desc)rn
  			  from dse_st_rsvr_r t where t.otq is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n5
  		  on r.stcd = n5.stcd
  		  left join
  		  (select * from (select t.stcd,t.otq,t.tm, row_number() over (partition by t.stcd order by t.otq asc)rn
  			  from dse_st_rsvr_r t where t.otq is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n6
  		  on r.stcd = n6.stcd
  		  left join
  		  (select * from (select t.stcd,t.w,t.tm, row_number() over (partition by t.stcd order by t.w desc)rn
  			  from dse_st_rsvr_r t where t.w is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n7
  		  on r.stcd = n7.stcd
  		  left join
  		  (select * from (select t.stcd,t.w,t.tm, row_number() over (partition by t.stcd order by t.w asc)rn
  			  from dse_st_rsvr_r t where t.w is not null and t.tm>=TJTM-1 and t.tm<TJTM) t where t.rn = 1) n8
  		   on r.stcd = n8.stcd  where n1.rz is not null and st.usfl='1' and st.sttp='RR' ;
   begin
        FOR data_row IN lcur_rsvr_day_jz LOOP
               v_stcd:=data_row.stcd;
               htrz_jz:=data_row.htrz;
               ltrz_jz :=data_row.ltrz;
               mxinq_jz:=data_row.mxinq;
               mninq_jz :=data_row.mninq;
               mxotq_jz :=data_row.mxotq;
               mnotq_jz:=data_row.mnotq;
               mxw_jz  :=data_row.mxw;
               mnw_jz:=data_row.mnw;
               htrztm_jz :=data_row.htrztm;
               ltrztm_jz :=data_row.ltrztm;
               mxinqtm_jz:=data_row.mxinqtm;
               mninqtm_jz:=data_row.mninqtm;
               mxotqtm_jz:=data_row.mxotqtm;
               mnotqtm_jz:=data_row.mnotqtm;
               mxwtm_jz  :=data_row.mxwtm;
               mnwtm_jz :=data_row.mnwtm;

              V_STCD_TJ:=null;
              V_TJSTATUS:=null;
        			select max(stcd),max(TJSTATUS) into  V_STCD_TJ,V_TJSTATUS from DSE_ST_RSVREVS_R where STTDRCD='1' and STCD=v_stcd and IDTM =TJTM;

        			if V_STCD_TJ is not null then
        				 begin
        				    if  V_TJSTATUS=1 then --系统自动统计值 可以修改
          						begin
          							update DSE_ST_RSVREVS_R set HTRZ=htrz_jz,LTRZ=ltrz_jz,MXINQ=mxinq_jz,MNINQ=mninq_jz,MXOTQ=mxotq_jz,MNOTQ=mnotq_jz,MXW=mxw_jz,MNW=mnw_jz
          							,HTRZTM=htrztm_jz,LTRZTM=ltrztm_jz,MXINQTM=mxinqtm_jz,MNINQTM=mninqtm_jz,MXOTQTM=mxotqtm_jz,MNOTQTM=mnotqtm_jz,MXWTM=mxwtm_jz,MNWTM=mnwtm_jz
          							where STCD=v_stcd and IDTM=TJTM and STTDRCD='1';
          						end;
                     end if;
        				end;
        			else
        				begin
        					 INSERT INTO DSE_ST_RSVREVS_R(STCD,IDTM,STTDRCD,HTRZ,LTRZ,MXINQ,MNINQ,MXOTQ,MNOTQ,MXW,MNW,HTRZTM,LTRZTM,MXINQTM,MNINQTM,MXOTQTM,MNOTQTM,MXWTM,MNWTM,TJSTATUS)
        					VALUES(v_stcd,TJTM,'1',htrz_jz,ltrz_jz,mxinq_jz,mninq_jz,mxotq_jz,mnotq_jz,mxw_jz,mnw_jz
        					,htrztm_jz,ltrztm_jz,mxinqtm_jz,mninqtm_jz,mxotqtm_jz,mnotqtm_jz,mxwtm_jz,mnwtm_jz,1);
        				end	;
             end if;

        END LOOP;
   end;

    --旬极值
   if d_day=1 or d_day=11 or d_day=21 then
      begin
           if  d_day=1 then
      				begin
      					XUM_START_TJTM :=add_months(TO_DATE(TO_CHAR(TJTM, 'YYYY-MM') || '-21 00:00:00', 'yyyy-mm-dd hh24:mi:ss'),-1);
      				end;
        		elsif d_day=11	then
        				begin
        					XUM_START_TJTM:=TO_DATE(TO_CHAR(TJTM, 'YYYY-MM') || '-11 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
        				end;
        		elsif	d_day=21 then
        				begin
        					XUM_START_TJTM:=TO_DATE(TO_CHAR(TJTM, 'YYYY-MM') || '-21 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
        				end;
            end if;
            XUM_END_TJTM:=TJTM;

            declare cursor  lcur_rsvr_xun_jz  is
                select r.stcd as stcd,n1.rz as htrz ,n2.rz as ltrz,n3.inq as mxinq,n4.inq as mninq,n5.otq as mxotq,n6.otq as mnotq,n7.w as mxw,n8.w as mnw
    					  ,n1.tm as htrztm,n2.tm as ltrztm,n3.tm as mxinqtm,n4.tm as mninqtm,n5.tm as mxotqtm,n6.tm as mnotqtm,n7.tm as mxwtm,n8.tm as mnwtm from
    					  dse_st_rsvr_real r  inner join st_stbprp_b st on st.stcd=r.stcd
    					  left join
    					  (select * from (select t.stcd,t.rz,t.tm, row_number() over (partition by t.stcd order by t.rz desc)rn
    						  from dse_st_rsvr_r t where t.rz is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n1
    					  on r.stcd=n1.stcd
    					  left join
    					  (select * from (select t.stcd,t.rz,t.tm, row_number() over (partition by t.stcd order by t.rz asc)rn
    						  from dse_st_rsvr_r t where t.rz is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n2
    					  on r.stcd = n2.stcd
    					  left join
    					  (select * from (select t.stcd,t.inq,t.tm, row_number() over (partition by t.stcd order by t.inq desc)rn
    						  from dse_st_rsvr_r t where t.inq is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n3
    					  on r.stcd = n3.stcd
    					  left join
    					  (select * from (select t.stcd,t.inq,t.tm, row_number() over (partition by t.stcd order by t.inq asc)rn
    						  from dse_st_rsvr_r t where t.inq is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n4
    					  on r.stcd = n4.stcd
    					  left join
    					  (select * from (select t.stcd,t.otq,t.tm, row_number() over (partition by t.stcd order by t.otq desc)rn
    						  from dse_st_rsvr_r t where t.otq is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n5
    					  on r.stcd = n5.stcd
    					  left join
    					  (select * from (select t.stcd,t.otq,t.tm, row_number() over (partition by t.stcd order by t.otq asc)rn
    						  from dse_st_rsvr_r t where t.otq is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n6
    					  on r.stcd = n6.stcd
    					  left join
    					  (select * from (select t.stcd,t.w,t.tm, row_number() over (partition by t.stcd order by t.w desc)rn
    						  from dse_st_rsvr_r t where t.w is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n7
    					  on r.stcd = n7.stcd
    					  left join
    					  (select * from (select t.stcd,t.w,t.tm, row_number() over (partition by t.stcd order by t.w asc)rn
    						  from dse_st_rsvr_r t where t.w is not null and t.tm>=XUM_START_TJTM and t.tm<XUM_END_TJTM) t where t.rn = 1) n8
    					   on r.stcd = n8.stcd  where n1.rz is not null and st.usfl='1' and st.sttp='RR';
               begin
                    FOR data_row IN lcur_rsvr_xun_jz LOOP
                           v_stcd:=data_row.stcd;
                           htrz_jz:=data_row.htrz;
                           ltrz_jz :=data_row.ltrz;
                           mxinq_jz:=data_row.mxinq;
                           mninq_jz :=data_row.mninq;
                           mxotq_jz :=data_row.mxotq;
                           mnotq_jz:=data_row.mnotq;
                           mxw_jz  :=data_row.mxw;
                           mnw_jz:=data_row.mnw;
                           htrztm_jz :=data_row.htrztm;
                           ltrztm_jz :=data_row.ltrztm;
                           mxinqtm_jz:=data_row.mxinqtm;
                           mninqtm_jz:=data_row.mninqtm;
                           mxotqtm_jz:=data_row.mxotqtm;
                           mnotqtm_jz:=data_row.mnotqtm;
                           mxwtm_jz  :=data_row.mxwtm;
                           mnwtm_jz :=data_row.mnwtm;
                        V_STCD_TJ:=null;
                        V_TJSTATUS:=null;
                      	select max(stcd),max(TJSTATUS) into  V_STCD_TJ,V_TJSTATUS from DSE_ST_RSVREVS_R where STTDRCD='4' and STCD=v_stcd and IDTM =XUM_END_TJTM;

                				if V_STCD_TJ is not null then
                					begin
                						if  V_TJSTATUS=1 then--系统自动统计值 可以修改
                  							begin
                    								update DSE_ST_RSVREVS_R set HTRZ=htrz_jz,LTRZ=ltrz_jz,MXINQ=mxinq_jz,MNINQ=mninq_jz,MXOTQ=mxotq_jz,MNOTQ=mnotq_jz,MXW=mxw_jz,MNW=mnw_jz
                    								,HTRZTM=htrztm_jz,LTRZTM=ltrztm_jz,MXINQTM=mxinqtm_jz,MNINQTM=mninqtm_jz,MXOTQTM=mxotqtm_jz,MNOTQTM=mnotqtm_jz,MXWTM=mxwtm_jz,MNWTM=mnwtm_jz
                    								where STCD=v_stcd and IDTM=XUM_END_TJTM and STTDRCD='4';
                  							end;
                             end if;
                					end;
                				else
                					begin
                						 INSERT INTO DSE_ST_RSVREVS_R(STCD,IDTM,STTDRCD,HTRZ,LTRZ,MXINQ,MNINQ,MXOTQ,MNOTQ,MXW,MNW
                						,HTRZTM,LTRZTM,MXINQTM,MNINQTM,MXOTQTM,MNOTQTM,MXWTM,MNWTM,TJSTATUS)
                						VALUES(v_stcd,XUM_END_TJTM,'4',htrz_jz,ltrz_jz,mxinq_jz,mninq_jz,mxotq_jz,mnotq_jz,mxw_jz,mnw_jz
                						,htrztm_jz,ltrztm_jz,mxinqtm_jz,mninqtm_jz,mxotqtm_jz,mnotqtm_jz,mxwtm_jz,mnwtm_jz,1);
                					end	;
                        end if;


                      END LOOP;
                 end;
      end;
   end if;

   --月极值
   IF d_day=1  then
       begin
            MONTH_END_TJTM:=TJTM;
			      MONTH_START_TJTM:=add_months(MONTH_END_TJTM,-1);
            declare cursor  lcur_rsvr_month_jz  is
                select r.stcd as stcd,n1.htrz as htrz ,n2.ltrz as ltrz,n3.mxinq as mxinq,n4.mninq as mninq,n5.mxotq as mxotq,n6.mnotq as mnotq,n7.mxw as mxw,n8.mnw as mnw
    					  ,n1.idtm as htrztm,n2.idtm as ltrztm,n3.idtm as mxinqtm,n4.idtm as mninqtm,n5.idtm as mxotqtm,n6.idtm as mnotqtm,n7.idtm as mxwtm,n8.idtm as mnwtm from
    					  dse_st_rsvr_real r  inner join st_stbprp_b st on st.stcd=r.stcd
    					  left join
    					  (select * from (select t.stcd,t.htrz,t.idtm, row_number() over (partition by t.stcd order by t.htrz desc)rn
    						  from DSE_ST_RSVREVS_R t where t.htrz is not null and t.sttdrcd='1' and t.idtm>=MONTH_START_TJTM and t.idtm<MONTH_END_TJTM) t where t.rn = 1) n1
    					  on r.stcd=n1.stcd
    					  left join
    					  (select * from (select t.stcd,t.ltrz,t.idtm, row_number() over (partition by t.stcd order by t.ltrz asc)rn
    						  from DSE_ST_RSVREVS_R t where t.ltrz is not null and t.sttdrcd='1' and t.idtm>=MONTH_START_TJTM and t.idtm<MONTH_END_TJTM) t where t.rn = 1) n2
    					  on r.stcd = n2.stcd
    					  left join
    					  (select * from (select t.stcd,t.mxinq,t.idtm, row_number() over (partition by t.stcd order by t.mxinq desc)rn
    						  from DSE_ST_RSVREVS_R t where t.mxinq is not null and t.sttdrcd='1' and t.idtm>=MONTH_START_TJTM and t.idtm<MONTH_END_TJTM) t where t.rn = 1) n3
    					  on r.stcd = n3.stcd
    					  left join
    					  (select * from (select t.stcd,t.mninq,t.idtm, row_number() over (partition by t.stcd order by t.mninq asc)rn
    						  from DSE_ST_RSVREVS_R t where t.mninq is not null and t.sttdrcd='1' and t.idtm>=MONTH_START_TJTM and t.idtm<MONTH_END_TJTM) t where t.rn = 1) n4
    					  on r.stcd = n4.stcd
    					  left join
    					  (select * from (select t.stcd,t.mxotq,t.idtm, row_number() over (partition by t.stcd order by t.mxotq desc)rn
    						  from DSE_ST_RSVREVS_R t where t.mxotq is not null and t.sttdrcd='1' and t.idtm>=MONTH_START_TJTM and t.idtm<MONTH_END_TJTM) t where t.rn = 1) n5
    					  on r.stcd = n5.stcd
    					  left join
    					  (select * from (select t.stcd,t.mnotq,t.idtm, row_number() over (partition by t.stcd order by t.mnotq asc)rn
    						  from DSE_ST_RSVREVS_R t where t.mnotq is not null and t.sttdrcd='1' and t.idtm>=MONTH_START_TJTM and t.idtm<MONTH_END_TJTM) t where t.rn = 1) n6
    					  on r.stcd = n6.stcd
    					  left join
    					  (select * from (select t.stcd,t.mxw,t.idtm, row_number() over (partition by t.stcd order by t.mxw desc)rn
    						  from DSE_ST_RSVREVS_R t where t.mxw is not null and t.sttdrcd='1' and t.idtm>=MONTH_START_TJTM and t.idtm<MONTH_END_TJTM) t where t.rn = 1) n7
    					  on r.stcd = n7.stcd
    					  left join
    					  (select * from (select t.stcd,t.mnw,t.idtm, row_number() over (partition by t.stcd order by t.mnw asc)rn
    						  from DSE_ST_RSVREVS_R t where t.mnw is not null and t.sttdrcd='1' and t.idtm>=MONTH_START_TJTM and t.idtm<MONTH_END_TJTM) t where t.rn = 1) n8
    					   on r.stcd = n8.stcd  where n1.htrz is not null and st.usfl='1' and st.sttp='RR';
            begin
                 FOR data_row IN lcur_rsvr_month_jz LOOP
                     v_stcd:=data_row.stcd;
                     htrz_jz:=data_row.htrz;
                     ltrz_jz :=data_row.ltrz;
                     mxinq_jz:=data_row.mxinq;
                     mninq_jz :=data_row.mninq;
                     mxotq_jz :=data_row.mxotq;
                     mnotq_jz:=data_row.mnotq;
                     mxw_jz  :=data_row.mxw;
                     mnw_jz:=data_row.mnw;
                     htrztm_jz :=data_row.htrztm;
                     ltrztm_jz :=data_row.ltrztm;
                     mxinqtm_jz:=data_row.mxinqtm;
                     mninqtm_jz:=data_row.mninqtm;
                     mxotqtm_jz:=data_row.mxotqtm;
                     mnotqtm_jz:=data_row.mnotqtm;
                     mxwtm_jz  :=data_row.mxwtm;
                     mnwtm_jz :=data_row.mnwtm;
                     V_STCD_TJ:=null;
                     V_TJSTATUS:=null;
                     	select max(stcd),max(TJSTATUS) into  V_STCD_TJ,V_TJSTATUS from DSE_ST_RSVREVS_R where STTDRCD='5' and STCD=v_stcd and IDTM =MONTH_END_TJTM;

              				if V_STCD_TJ is not null then
              					begin
              						if  V_TJSTATUS=1 then --系统自动统计值 可以修改
                							begin
                  								update DSE_ST_RSVREVS_R set HTRZ=htrz_jz,LTRZ=ltrz_jz,MXINQ=mxinq_jz,MNINQ=mninq_jz,MXOTQ=mxotq_jz,MNOTQ=mnotq_jz,MXW=mxw_jz,MNW=mnw_jz
                  								,HTRZTM=htrztm_jz,LTRZTM=ltrztm_jz,MXINQTM=mxinqtm_jz,MNINQTM=mninqtm_jz,MXOTQTM=mxotqtm_jz,MNOTQTM=mnotqtm_jz,MXWTM=mxwtm_jz,MNWTM=mnwtm_jz
                  								where STCD=v_stcd and IDTM=MONTH_END_TJTM and STTDRCD='5';
                							end;
                           end if;
              					end;
              				else
              					begin
              						  INSERT INTO DSE_ST_RSVREVS_R(STCD,IDTM,STTDRCD,HTRZ,LTRZ,MXINQ,MNINQ,MXOTQ,MNOTQ,MXW,MNW
                  						,HTRZTM,LTRZTM,MXINQTM,MNINQTM,MXOTQTM,MNOTQTM,MXWTM,MNWTM,TJSTATUS)
                  						VALUES(v_stcd,MONTH_END_TJTM,'5',htrz_jz,ltrz_jz,mxinq_jz,mninq_jz,mxotq_jz,mnotq_jz,mxw_jz,mnw_jz
                  						,htrztm_jz,ltrztm_jz,mxinqtm_jz,mninqtm_jz,mxotqtm_jz,mnotqtm_jz,mxwtm_jz,mnwtm_jz,1);
              					end;
                      end if;


                 END LOOP;

            end;


       end;
   end if;


   --年极值
	if m_day =1 and d_day =1 then
		  begin
           YEAR_END_TJTM:=TJTM;
			     YEAR_START_TJTM:=add_months(YEAR_END_TJTM,-12);
            declare cursor  lcur_rsvr_year_jz  is
                select r.stcd as stcd,n1.htrz as htrz ,n2.ltrz as ltrz,n3.mxinq as mxinq,n4.mninq as mninq,n5.mxotq as mxotq,n6.mnotq as mnotq,n7.mxw as mxw,n8.mnw as mnw
    					  ,n1.idtm as htrztm,n2.idtm as ltrztm,n3.idtm as mxinqtm,n4.idtm as mninqtm,n5.idtm as mxotqtm,n6.idtm as mnotqtm,n7.idtm as mxwtm,n8.idtm as mnwtm from
    					  dse_st_rsvr_real r  inner join st_stbprp_b st on st.stcd=r.stcd
    					  left join
    					  (select * from (select t.stcd,t.htrz,t.idtm, row_number() over (partition by t.stcd order by t.htrz desc)rn
    						  from DSE_ST_RSVREVS_R t where t.htrz is not null and t.sttdrcd='5' and t.idtm>=YEAR_START_TJTM and t.idtm<YEAR_END_TJTM) t where t.rn = 1) n1
    					  on r.stcd=n1.stcd
    					  left join
    					  (select * from (select t.stcd,t.ltrz,t.idtm, row_number() over (partition by t.stcd order by t.ltrz asc)rn
    						  from DSE_ST_RSVREVS_R t where t.ltrz is not null and t.sttdrcd='5' and t.idtm>=YEAR_START_TJTM and t.idtm<YEAR_END_TJTM) t where t.rn = 1) n2
    					  on r.stcd = n2.stcd
    					  left join
    					  (select * from (select t.stcd,t.mxinq,t.idtm, row_number() over (partition by t.stcd order by t.mxinq desc)rn
    						  from DSE_ST_RSVREVS_R t where t.mxinq is not null and t.sttdrcd='5' and t.idtm>=YEAR_START_TJTM and t.idtm<YEAR_END_TJTM) t where t.rn = 1) n3
    					  on r.stcd = n3.stcd
    					  left join
    					  (select * from (select t.stcd,t.mninq,t.idtm, row_number() over (partition by t.stcd order by t.mninq asc)rn
    						  from DSE_ST_RSVREVS_R t where t.mninq is not null and t.sttdrcd='5' and t.idtm>=YEAR_START_TJTM and t.idtm<YEAR_END_TJTM) t where t.rn = 1) n4
    					  on r.stcd = n4.stcd
    					  left join
    					  (select * from (select t.stcd,t.mxotq,t.idtm, row_number() over (partition by t.stcd order by t.mxotq desc)rn
    						  from DSE_ST_RSVREVS_R t where t.mxotq is not null and t.sttdrcd='5' and t.idtm>=YEAR_START_TJTM and t.idtm<YEAR_END_TJTM) t where t.rn = 1) n5
    					  on r.stcd = n5.stcd
    					  left join
    					  (select * from (select t.stcd,t.mnotq,t.idtm, row_number() over (partition by t.stcd order by t.mnotq asc)rn
    						  from DSE_ST_RSVREVS_R t where t.mnotq is not null and t.sttdrcd='5' and t.idtm>=YEAR_START_TJTM and t.idtm<YEAR_END_TJTM) t where t.rn = 1) n6
    					  on r.stcd = n6.stcd
    					  left join
    					  (select * from (select t.stcd,t.mxw,t.idtm, row_number() over (partition by t.stcd order by t.mxw desc)rn
    						  from DSE_ST_RSVREVS_R t where t.mxw is not null and t.sttdrcd='5' and t.idtm>=YEAR_START_TJTM and t.idtm<YEAR_END_TJTM) t where t.rn = 1) n7
    					  on r.stcd = n7.stcd
    					  left join
    					  (select * from (select t.stcd,t.mnw,t.idtm, row_number() over (partition by t.stcd order by t.mnw asc)rn
    						  from DSE_ST_RSVREVS_R t where t.mnw is not null and t.sttdrcd='5' and t.idtm>=YEAR_START_TJTM and t.idtm<YEAR_END_TJTM) t where t.rn = 1) n8
    					   on r.stcd = n8.stcd  where n1.htrz is not null and st.usfl='1' and st.sttp='RR';
            begin
                   FOR data_row IN lcur_rsvr_year_jz LOOP
                     v_stcd:=data_row.stcd;
                     htrz_jz:=data_row.htrz;
                     ltrz_jz :=data_row.ltrz;
                     mxinq_jz:=data_row.mxinq;
                     mninq_jz :=data_row.mninq;
                     mxotq_jz :=data_row.mxotq;
                     mnotq_jz:=data_row.mnotq;
                     mxw_jz  :=data_row.mxw;
                     mnw_jz:=data_row.mnw;
                     htrztm_jz :=data_row.htrztm;
                     ltrztm_jz :=data_row.ltrztm;
                     mxinqtm_jz:=data_row.mxinqtm;
                     mninqtm_jz:=data_row.mninqtm;
                     mxotqtm_jz:=data_row.mxotqtm;
                     mnotqtm_jz:=data_row.mnotqtm;
                     mxwtm_jz  :=data_row.mxwtm;
                     mnwtm_jz :=data_row.mnwtm;
                     V_STCD_TJ:=null;
                     V_TJSTATUS:=null;
                     select max(stcd),max(TJSTATUS) into  V_STCD_TJ,V_TJSTATUS from DSE_ST_RSVREVS_R where STTDRCD='6' and STCD=v_stcd and IDTM =MONTH_END_TJTM;

                     if V_STCD_TJ is not null then
            					begin
              						if V_TJSTATUS=1 then--系统自动统计值 可以修改
                							begin
                								update DSE_ST_RSVREVS_R set HTRZ=htrz_jz,LTRZ=ltrz_jz,MXINQ=mxinq_jz,MNINQ=mninq_jz,MXOTQ=mxotq_jz,MNOTQ=mnotq_jz,MXW=mxw_jz,MNW=mnw_jz
                								,HTRZTM=htrztm_jz,LTRZTM=ltrztm_jz,MXINQTM=mxinqtm_jz,MNINQTM=mninqtm_jz,MXOTQTM=mxotqtm_jz,MNOTQTM=mnotqtm_jz,MXWTM=mxwtm_jz,MNWTM=mnwtm_jz
                								where STCD=v_stcd and IDTM=YEAR_END_TJTM and STTDRCD='6';
                							end;
                           end if;
            					end;
            				else
            					begin
            						  INSERT INTO DSE_ST_RSVREVS_R(STCD,IDTM,STTDRCD,HTRZ,LTRZ,MXINQ,MNINQ,MXOTQ,MNOTQ,MXW,MNW
              						,HTRZTM,LTRZTM,MXINQTM,MNINQTM,MXOTQTM,MNOTQTM,MXWTM,MNWTM,TJSTATUS)
              						VALUES(v_stcd,YEAR_END_TJTM,'6',htrz_jz,ltrz_jz,mxinq_jz,mninq_jz,mxotq_jz,mnotq_jz,mxw_jz,mnw_jz
              						,htrztm_jz,ltrztm_jz,mxinqtm_jz,mninqtm_jz,mxotqtm_jz,mnotqtm_jz,mxwtm_jz,mnwtm_jz,1);
            					end;
                   end if;
				         end LOOP;
            end;
      end;
  end if;


end PLATFORM_RSVR_JIZ_TJ;


/

