create procedure      PLATFORM_JZ_JBXX(tcode    varchar2,
                                             tname varchar2,
                                             PAGEFROM INT,
                                             PAGETO   INT,
                                             cursor1  OUT platform.CURSOR) is
begin
  open cursor1 for
    select *
      from (select a.ennmcd,
                   a.aircrewnm,
                   a.waterpump_modal as waterpumpModal,
                   a.d_runoff as drunoff,
                   a.d_raise as draise,
                   a.angle,
                   a.waterpump_speed as waterpumpSpeed,
                   a.elec_modal as elecModal,
                   a.power,
                   a.elec_speed as elecSpeed,
                   a.electricity,
                   a.fgmr,a.fpath,
                   b.ennm,
                   a.bzlx,
                   a.djlx,
									a.DZEDDY,
								a.DZEDDL,
								a.ZZEDDY,
									a.ZZEDDL,
                   row_number() over(order by a.ennmcd) m

              from dse_bz_pumb a, TB0001_PRNMSR_044 b
             where a.ennmcd = b.ennmcd
               and a.ennmcd like '%' || tcode || '%' and  b.ennm like '%' || tname || '%') t
     where t.m > PAGEFROM
       and t.m <= PAGETO;

end PLATFORM_JZ_JBXX;


/

