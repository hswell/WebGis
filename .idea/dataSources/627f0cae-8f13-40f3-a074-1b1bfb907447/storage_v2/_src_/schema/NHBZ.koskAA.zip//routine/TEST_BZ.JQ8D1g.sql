create PROCEDURE      TEST_BZ IS
  /*ST TIMESTAMP := TO_DATE('2013-06-18 00:00:00', 'yyyy-mm-dd hh24:mi:ss');
  ET TIMESTAMP := TO_DATE('2013-06-18 08:45:00', 'yyyy-mm-dd hh24:mi:ss');*/
  ST TIMESTAMP;
  MI INT;

  W2 NUMERIC(6, 2);
  W1 NUMERIC(6, 2);
  W3 NUMERIC(6, 2);
BEGIN

  SELECT SYSDATE INTO ST FROM DUAL;
  MI := TO_NUMBER(TO_CHAR(ST, 'mi'));

  WHILE MOD(MI, 5) != 0 LOOP
    SELECT ST - INTERVAL '1' MINUTE INTO ST FROM DUAL;
    MI := TO_NUMBER(TO_CHAR(ST, 'mi'));
  END LOOP;

  /* WHILE ST < ET LOOP*/
  DECLARE
    --类型定义
    CURSOR C_JOB IS
      SELECT STCD FROM ST_STBPRP_B WHERE STTP = 'DP';
    --定义一个游标变量
    C_ROW C_JOB%ROWTYPE;
  BEGIN
    FOR C_ROW IN C_JOB LOOP
      W1 := ROUND(DBMS_RANDOM.VALUE(3, 5.5), 2);
      W2 := ROUND(DBMS_RANDOM.VALUE(3, 5.5), 2);
      W3 := ROUND(DBMS_RANDOM.VALUE(3, 5.5), 2);
      INSERT INTO DSE_BZ_RUNINFO_R
        (STCD, TM, FOREBAYZ, NSW, WSW, AIRCREWNM, AIRCREWSTATE, PIPENM)
      VALUES
        (C_ROW.STCD,
         ST,
         W1,
         W3,
         W2,
         '1#',
         ROUND(DBMS_RANDOM.VALUE(0, 1)),
         '1#') ;
      INSERT INTO DSE_BZ_RUNINFO_R
        (STCD, TM, FOREBAYZ, NSW, WSW, AIRCREWNM, AIRCREWSTATE, PIPENM)
      VALUES
        (C_ROW.STCD,
         ST,
         W1,
         W3,
         W2,
         '2#',
         ROUND(DBMS_RANDOM.VALUE(0, 1)),
         '1#');
      INSERT INTO DSE_BZ_RUNINFO_R
        (STCD, TM, FOREBAYZ, NSW, WSW, AIRCREWNM, AIRCREWSTATE, PIPENM)
      VALUES
        (C_ROW.STCD,
         ST,
         W1,
         W3,
         W2,
         '3#',
         ROUND(DBMS_RANDOM.VALUE(0, 1)),
         '1#');
      INSERT INTO DSE_BZ_RUNINFO_R
        (STCD, TM, FOREBAYZ, NSW, WSW, AIRCREWNM, AIRCREWSTATE, PIPENM)
      VALUES
        (C_ROW.STCD,
         ST,
         W1,
         W3,
         W2,
         '4#',
         ROUND(DBMS_RANDOM.VALUE(0, 1)),
         '1#');
    END LOOP;
    COMMIT;
  END;

  /*  ST := ST + INTERVAL '5' MINUTE;
  END LOOP;*/
END TEST_BZ;


/

