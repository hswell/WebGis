create function      getdeptnm(deptcd  in varchar2) return varchar2
as
code  varchar2(30) ;

begin
       code:=rtrim(deptcd);
  if (code is not null and length(code) >= 1 ) then

          select deptnm into code from  dept_b   where  deptcd =code;
         end if;
  return code;
end getdeptnm;


/

