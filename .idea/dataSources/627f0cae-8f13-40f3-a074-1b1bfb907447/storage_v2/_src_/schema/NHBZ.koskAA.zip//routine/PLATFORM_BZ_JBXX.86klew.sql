create procedure      PLATFORM_BZ_JBXX(tcode    varchar,
                                             tname varchar,
                                             PAGEFROM INT,
                                             PAGETO   INT,
                                             cursor1   OUT PLATFORM.CURSOR) is
begin
  open cursor1 for
    select *
      from (select a.ennmcd,
                --   to_char(a.infndt, 'yyyy-mm-dd') infndt,
                   a.infndt,
                   a.aduncd,
                   a.adunnm,
                   a.enpl,
                   a.oppr,
                   a.type,
                   a.lvbslv,
                   a.dlblp,
                   a.bldt,
                   a.opbgtm,
                 --  to_char(a.bldt, 'yyyy-mm-dd HH24:MI:SS') bldt,
                 --  to_char(a.opbgtm, 'yyyy-mm-dd HH24:MI:SS') opbgtm,
                   b.dsincp*1000 as dsincp,
                   b.acincp*1000 as acincp,
                   b.unnb,
                   b.pmtp,
                   b.ddfwlv,
                   b.ddpwlv,
                   b.pmpnmtel,
                   b.dsdrfl,
                   b.avdrfl,
                   b.acdrar,
                   b.iddfwlv,
                   b.iddpwlv,
                   b.dsirdrfl,
                   b.maxyc,
                   b.axirdrfl,
                   b.dsirar,
                   b.acirar,
                   b.qcsize,
                   b.jscsize,
                   b.cscsize,
                   c.ogid,
                   c.ennm,
                   a.adunmobile,
                   a.angel,
                   c.entyced,m.STCD,
                   r.SZSTCD SZCD,
                   --liuxian 水闸2
                   r.SZSTCD2 SZCD2,
                   f.id as bsnum,f.filename,f.filepath as newfilepath,ca.filepath,ca.bhid,
                   row_number() over( partition by a.ennmcd order by a.infndt desc) m

              from tb1501_meidscin_044 a left join DSE_TB0001_REMARK_B m on a.ENNMCD=m.ENNMCD left join DSE_BZSZ_REMARK r on m.STCD=r.BZSTCD
              left join sys_common_file f on trim(a.ennmcd) = trim(f.bid)
              left join dse_filecate_com_b ca on f.id = ca.upfileid,
                   tb1502_meidsbi_044  b,
                   TB0001_PRNMSR_044   c

             where a.ennmcd = b.ennmcd
               and a.infndt = b.infndt
               and a.ennmcd = c.ennmcd
               and a.ennmcd like '%' || tcode || '%' and c.ennm like '%' || tname || '%') t

     where t.m = 1 and  t.m > PAGEFROM
       and t.m <= PAGETO;

end PLATFORM_BZ_JBXX;


/

