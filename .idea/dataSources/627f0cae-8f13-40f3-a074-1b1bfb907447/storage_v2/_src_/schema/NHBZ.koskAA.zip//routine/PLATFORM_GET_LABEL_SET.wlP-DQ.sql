create procedure      PLATFORM_GET_LABEL_SET(VUSERID number,
                                                   CURR    OUT PLATFORM.CURSOR) is
begin
  OPEN CURR FOR
    SELECT * FROM dse_label_set_contorl V WHERE V.Userid = VUSERID;

end PLATFORM_GET_LABEL_SET;


/

