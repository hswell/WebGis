create TYPE        "PLATFORM_BZ_RUNSTATE_TABLE"                                          as object
(
  -- Author  : DSE_TICHSTAR
  -- Created : 2013年7月25日9:35:06
  -- Purpose :
  -- Attributes
  STCD char(12),  --站码
  AIRCREWNM VARCHAR(10), -- 机组编号
  KTM DATE, --泵站机组开启时间
  K_IN_WATER numeric(8,3),--泵站机组开启内水位
  K_OUT_WATER numeric(8,3),--泵站机组开启外水位
  GTM DATE, --泵站机组关闭时间
  G_IN_WATER numeric(8,3),--泵站机组关闭内水位
  G_OUT_WATER numeric(8,3),--泵站机组关闭外水位
  FLAG CHAR(1) -- 判断是否插入完成 1:完成，0:未完成
)
/

