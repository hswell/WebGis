create procedure      PLATFORM_PPTN_MOD_1_12H_D_X_M

is
 D_TIME date;
 DAY_TIME date;--修改天的时间

 T_MONTH int;
 T_DAY  int ; --天
 T_HOUR  int; -- 小时
 STCD_REAL char(8);
 CHECK_STCD char(8);
begin

	 D_TIME:=to_date(to_char(sysdate,'yyyy-mm-dd hh24')||':00:00','yyyy-mm-dd hh24:mi:ss')-1/24;
	 --当前时间的八时
	 DAY_TIME:=to_date(to_char(sysdate,'yyyy-mm-dd')||' 08:00:00','yyyy-mm-dd hh24:mi:ss');

  T_HOUR:=to_number(to_char(sysdate,'hh24'));
	T_DAY:=to_number(to_char(sysdate,'dd'));

	T_MONTH:=to_number(to_char(sysdate,'mm'));

  declare cursor  lcur_mod_pptn_real  is
      select r.stcd from dse_st_pptn_real r inner join st_stbprp_b st on  r.stcd =st.stcd and st.USFL ='1' ;
    begin
          FOR stcd_row IN lcur_mod_pptn_real LOOP
              STCD_REAL:=stcd_row.stcd;
              CHECK_STCD:=null;
                -- 修补1小时记录
               select max(stcd) into CHECK_STCD from DSE_ST_PPTN_H where STCD=STCD_REAL and TM=D_TIME;
        		   if CHECK_STCD is null then
          				begin
          					insert into DSE_ST_PPTN_H(STCD,TM,DRP)values(STCD_REAL,D_TIME,0);
          				end	;
               end if;


                  --修补天
        		   if T_HOUR=12 or T_HOUR=20 then
          			   begin
                      CHECK_STCD:=null;
                      select max(stcd) into CHECK_STCD from DSE_ST_PSTAT_R where STTDRCD='1' and STCD=STCD_REAL and IDTM=DAY_TIME;
            					if CHECK_STCD is null then
            						begin
            							insert into DSE_ST_PSTAT_R(STCD,IDTM,STTDRCD,ACCP)values(STCD_REAL,DAY_TIME,'1',0);
            						end;
                      end if;
          			   end;
               end if;


               --修改旬的记录,1 11 21 日13时统计
          			if (T_DAY=1 or T_DAY=11 or T_DAY=21)  and (T_HOUR=13 or T_HOUR=20 )  then
          				begin
                     CHECK_STCD:=null;
                     select max(stcd) into CHECK_STCD from DSE_ST_PSTAT_R where STTDRCD='4' and STCD=STCD_REAL and IDTM=DAY_TIME;
            					if CHECK_STCD is null then
              						begin
              							  insert into DSE_ST_PSTAT_R(STCD,IDTM,STTDRCD,ACCP)values(STCD_REAL,DAY_TIME,'4',0);
              						end;
                       end if;
          				end;
                end if;

                --修补月
        			if T_MONTH=1 and T_DAY=1 and (T_HOUR=14 or T_HOUR=21) then
        				begin
                   CHECK_STCD:=null;
                   select max(stcd) into CHECK_STCD from DSE_ST_PSTAT_R where STTDRCD='5' and STCD=STCD_REAL and IDTM=DAY_TIME;

          					if CHECK_STCD is null then
            						begin
            							insert into DSE_ST_PSTAT_R(STCD,IDTM,STTDRCD,ACCP)values(STCD_REAL,DAY_TIME,'5',0);
            						end;
                    end if;
        				end;
              end if;

          END LOOP;
     end;
end PLATFORM_PPTN_MOD_1_12H_D_X_M;


/

