create PROCEDURE      PLATFORM_GKXX_SK(CURR1 OUT PLATFORM.CURSOR) IS
BEGIN
  --水库工况信息
  OPEN CURR1 FOR
    SELECT TTT.*, ROWNUM ROWNUM_
      FROM (SELECT T.STCD,
                   rtrim(S.STNM) STNM,
                   TO_CHAR(T.TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(T.RZ, 2), '99999999990.99')) RZ,
                   ABS(CEIL((T.TM - SYSDATE))) || '天' ||
                   (ABS(CEIL((T.TM - SYSDATE) * 24))- ABS(CEIL((T.TM - SYSDATE)))*24) || '小时' ||
                   (ABS(CEIL(((T.TM - SYSDATE)) * 24 * 60))-ABS(CEIL((T.TM - SYSDATE) * 24))*60) || '分' TIMEST
              FROM DSE_ST_RSVR_REAL T
              LEFT JOIN ST_STBPRP_B S ON T.STCD = S.STCD
                                     AND S.USFL = '1'
             WHERE T.TM < SYSDATE
             ORDER BY T.TM, T.RZ DESC) TTT;
END PLATFORM_GKXX_SK;


/

