create trigger TRIG_STWARNRECORD_R
    after insert
    on STWARNRECORD_R
    for each row
declare  
 PRAGMA AUTONOMOUS_TRANSACTION; 
   zjetm  DATE;  
   visdxpb  char(1)  ;    
   vdxhz  nvarchar2(50)  ; 

begin
  
   select max(stwarnetm) into zjetm  from   stwarnrecord_r where  stwarnetm is not null and stcd=:NEW.stcd and WarnTypeID=:NEW.WarnTypeID; 
    select isdxpb,dxhz into visdxpb,vdxhz  from dse_st_config_b where stcd=:NEW.stcd  and rownum=1;    
     if (visdxpb is null) then    
          visdxpb:='0';
     end if;   
     
   if( visdxpb='0' and ( zjetm is null or (:NEW.stwarnstm-zjetm)*24>1 ) )then     
       PRC_WARNNOTESEND(:NEW.stwarnid,
                              :NEW.stcd,
                              :NEW.WarnTypeID,
                              '系统管理员',
                              :NEW.stwarndesc||vdxhz); 
     end if;                     
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    rollback;
end TRIG_STWARNRECORD_R;


/

