create procedure      BZYXGL_ZPZSTATE(STCD    VARCHAR, --????????
                                           CURR     OUT PLATFORM.CURSOR,
                                           CURR2     OUT PLATFORM.CURSOR) is

szstcd1 varchar2(8);
szstcd2 varchar2(8);
num1    int;
num2    int;


begin

  IF STCD IS NOT NULL THEN
     select count(szstcd) into num1 from dse_bzsz_remark where bzstcd = stcd ;
     if num1>0 then
         select szstcd into szstcd1 from dse_bzsz_remark where bzstcd = stcd ;
         if szstcd1 is not null then
             begin
               OPEN CURR FOR
                 SELECT Q.*, ROW_NUMBER() OVER(ORDER BY Q.STCD DESC) RNUM
                          FROM (SELECT T.STCD,
                                       TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') AS TM,
                                       B.STNM,
                                       case t.state when '1' then '??' when '0' then '??' else null end as DO,
                                       ROW_NUMBER() OVER(PARTITION BY T.STCD ORDER BY T.TM DESC) RN
                                  FROM DSE_SZ_RUNSTATE_R T, ST_STBPRP_B B
                                 WHERE T.STCD = B.STCD AND T.STCD = szstcd1 ) Q
                         WHERE Q.RN = 1;
             end;
         end if;
     end if;

     select count(szstcd2) into num2 from dse_bzsz_remark where bzstcd = stcd ;
     if num2>0 then
         select szstcd2 into szstcd2 from dse_bzsz_remark where bzstcd = stcd ;
         if szstcd2 is not null then
             begin
               OPEN CURR2 FOR
                   SELECT Q.*, ROW_NUMBER() OVER(ORDER BY Q.STCD DESC) RNUM
                          FROM (SELECT T.STCD,
                                       TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') AS TM,
                                       B.STNM,
                                       case t.state when '1' then '??' when '0' then '??' else null end as DO,
                                       ROW_NUMBER() OVER(PARTITION BY T.STCD ORDER BY T.TM DESC) RN
                                  FROM DSE_SZ_RUNSTATE_R T, ST_STBPRP_B B
                                 WHERE T.STCD = B.STCD AND T.STCD = szstcd2 ) Q
                         WHERE Q.RN = 1;
             end;
         end if;
     end if;
  END IF;
end BZYXGL_ZPZSTATE;


/

