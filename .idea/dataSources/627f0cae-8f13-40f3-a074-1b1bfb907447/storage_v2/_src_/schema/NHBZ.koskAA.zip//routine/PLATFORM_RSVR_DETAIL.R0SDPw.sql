create PROCEDURE      PLATFORM_RSVR_DETAIL(VSTCD VARCHAR,
                                                 ST    VARCHAR,
                                                 ET    VARCHAR,
                                                 CURR1 OUT PLATFORM.CURSOR,
                                                 CURR2 OUT PLATFORM.CURSOR,
                                                 CURR3 OUT PLATFORM.CURSOR,
                                                 CURR4 OUT PLATFORM.CURSOR) IS
  VST DATE;
  VET DATE;
BEGIN
  VST := TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss');
  VET := TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss');

  --水库站测报的水库水情信息
  OPEN CURR1 FOR
    SELECT TTT.*, ROWNUM
      FROM (SELECT TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(RZ, 2), '99999999990.99')) RZ,
                   FUNC_NUMERIC(W, 3) W
              FROM DSE_ST_RSVR_R
             WHERE TM >= VST
               AND TM <= VET
               AND STCD = VSTCD
             ORDER BY TM DESC) TTT;

  --水库站测报的雨量信息
  OPEN CURR2 FOR
    SELECT TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
           TRIM(TO_CHAR(ROUND(DRP, 1), '99999999990.9')) DRP
      FROM DSE_ST_PPTN_H
     WHERE TM > VST
       AND TM <= VET
       AND STCD = VSTCD
     ORDER BY TM DESC;

  --特征值
  OPEN CURR3 FOR
    SELECT DDZ, CKFLZ, TTCP, DDCP FROM ST_RSVRFCCH_B WHERE STCD = VSTCD;

  --汛限水位
  OPEN CURR4 FOR
    SELECT FSLTDZ
      FROM ST_RSVRFSR_B
     WHERE TO_NUMBER(BGMD) <= TO_NUMBER(TO_CHAR(SYSDATE, 'mmdd'))
       AND (EDMD IS NULL OR
            TO_NUMBER(EDMD) >= TO_NUMBER(TO_CHAR(SYSDATE, 'mmdd')))
       AND STCD = VSTCD;
END PLATFORM_RSVR_DETAIL;


/

