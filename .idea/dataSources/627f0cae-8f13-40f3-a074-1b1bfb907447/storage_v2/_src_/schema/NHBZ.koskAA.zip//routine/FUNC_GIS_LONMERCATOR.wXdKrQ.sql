create function      FUNC_GIS_LONMERCATOR(LGTD NUMBER) return number is
  Result number;
  --createTime 2013-08-16
  --author chenya
  --经度转墨卡托
begin
  Result:=LGTD*20037508.34/180;
  return(Result);
end FUNC_GIS_LONMERCATOR;


/

