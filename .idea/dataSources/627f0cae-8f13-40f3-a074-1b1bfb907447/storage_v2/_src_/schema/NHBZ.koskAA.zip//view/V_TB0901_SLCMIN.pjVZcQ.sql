create view V_TB0901_SLCMIN as
select
  /**
    *AUTHOR:CHENHX
    *CTEATEDATE:2013年7月12日18:00:46
    *DESCRIPTION:查询水闸最新资料时间
    **/
       b.stcd,
       t1."ENNMCD",t1."INFNDT",t1."ADUNCD",t1."ADUNNM",t1."BLDT",t1."OPBGTM",t1."GTCL",t1."LVBSLV",t1."DLBLP",t1."DSIN",t1."ASTKBIN",t1."RM",t1."ATID",t1."SDFL",t1."RMA",t1."MDPS",t1."MDDT",t1."ZMNUM",t1."ISIMP",t1."ZM3DURL",t1."RNUM"
       from (select t.*,row_number()over(partition by t.ennmcd order by t.INFNDT desc)rnum from TB0901_SLCMIN_044 t) t1,
       DSE_TB0001_REMARK_B b where t1.ennmcd = b.ennmcd and t1.rnum = 1


/

