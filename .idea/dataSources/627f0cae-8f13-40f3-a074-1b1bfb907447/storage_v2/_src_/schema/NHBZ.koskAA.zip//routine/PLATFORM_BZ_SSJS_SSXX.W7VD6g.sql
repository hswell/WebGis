create procedure      PLATFORM_BZ_SSJS_SSXX(STCDS VARCHAR,
                                                  CURR  OUT PLATFORM.CURSOR,
                                                  CURR1 OUT PLATFORM.CURSOR) is
begin
  OPEN CURR FOR
    select t.stcd,
           to_char(t.tm, 'yyyy-mm-dd hh24:mi:ss') tm,
           t.aircrewnm || '机组' aircrewnm,
           t.aircrewstate,
           t.instantaneousq,
           t.wsw,
           t.nsw,
           p.power,
           to_char(maxw.tm, 'hh24:mi:ss') as wtm,
           maxw.wsw mwsw,
           to_char(maxn.tm, 'hh24:mi:ss') as ntm,
           maxn.nsw mnsw
      from DSE_BZ_PUMB p
      left join v_tb1502_meidsbi v
        on p.ENNMCD = v.stcd
      left join DSE_BZ_RUNINFO_REAL t
        on (v.stcd = T.STCD and t.aircrewnm = p.aircrewnm)
      left join (select *
                   from (select stcd, tm, wsw
                           from dse_bz_runinfo_r
                          where stcd = STCDS
                            and tm >= to_date(to_char(sysdate, 'yyyy-mm-dd') ||
                                              ' 00:00:00',
                                              'yyyy-mm-dd hh24:mi:ss')
                          order by wsw desc nulls last)
                  where rownum = 1) maxw
        on 1 = 1
      left join (select *
                   from (select stcd, tm, nsw
                           from dse_bz_runinfo_r
                          where stcd = STCDS
                            and tm >= to_date(to_char(sysdate, 'yyyy-mm-dd') ||
                                              ' 00:00:00',
                                              'yyyy-mm-dd hh24:mi:ss')
                          order by nsw desc nulls last)
                  where rownum = 1) maxn
        on 1 = 1
     where t.stcd = STCDS
     order by t.aircrewnm;

  OPEN CURR1 FOR
    SELECT v.ENNMCD,
           v.INFNDT,
           v.DSINCP * 1000 DSINCP,
           v.ACINCP,
           v.UNNB,
           v.PMTP,
           v.DDFWLV,
           v.DDPWLV,
           v.PMPNMTEL,
           v.DSDRFL,
           v.IDDFWLV,
           v.IDDPWLV,
           v.DSIRDRFL
      FROM V_TB1502_MEIDSBI V
     WHERE V.stcd = STCDS;

end PLATFORM_BZ_SSJS_SSXX;


/

