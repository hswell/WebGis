create function      FUNC_isNumber(p_in varchar2) return integer as
  i number;
begin
  i := to_number(p_in);
  return 1;
exception
  when others then
    return 0;
end;


/

