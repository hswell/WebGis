create PROCEDURE      PLATFORM_SSJK_RSVR(VSTNM    VARCHAR,
                                               VADDVCD  VARCHAR,
                                               ISWARING VARCHAR,
                                                VMAPTYPE VARCHAR,
                                               CURR     OUT PLATFORM.CURSOR) IS
  RED      VARCHAR(10);
  ORANGE   VARCHAR(10);
  NORMAL   VARCHAR(10);
  RANGE    NUMBER(5, 1);
BEGIN
  SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR
    INTO RED, ORANGE, RANGE, NORMAL
    FROM DSE_WARNING_PARAM;
  --水库站测报的水库水情实时信息
  --ISWARING 用于判断是否报警，''所有，1报警，0非报警。
  OPEN CURR FOR
    select *
      from (SELECT NVL(T2.STNM, T1.STCD) STNM,
                   T1.STCD,
                   'RR' STTP,
                   case
                     when VMAPTYPE = '2' then
                      func_gis_lonmercator(T2.LGTD)
                     else
                      T2.LGTD
                   end LGTD,
                   case
                     when VMAPTYPE = '2' then
                      func_gis_latmercator(T2.LTTD)
                     else
                      T2.LTTD
                   end LTTD,
                   T4.MAXSCALE,
                   T4.MINSCALE,
                   T4.SHOWLABELSCALE,
                   T4.VIFL,
                   TO_CHAR(T1.TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(T1.RZ, 2), '99999999990.99')) RZ,
                   FUNC_NUMERIC(T1.W, 3) W,
                   FUNC_NUMERIC(T1.INQ, 3) INQ,
                   FUNC_NUMERIC(T1.OTQ, 3) OTQ,
                   TRIM(TO_CHAR(ROUND(T3.FSLTDZ, 2), '99999999990.99')) FSLTDZ,
                   TO_CHAR(getadnm(T2.ADDVCD)) ADNM,
                   CASE
                     WHEN T1.RZ IS NULL OR T3.FSLTDZ IS NULL THEN
                      NULL
                     WHEN T1.RZ >= T3.FSLTDZ OR T3.FSLTDZ - T1.RZ <= RANGE THEN
                      TRIM(TO_CHAR(ROUND(T1.RZ - T3.FSLTDZ, 2),
                                   '99999999990.99'))
                     ELSE
                      NULL
                   END CFSLTDZ,
                   CASE
                     WHEN T1.RZ IS NULL OR T3.FSLTDZ IS NULL THEN
                      NORMAL
                     WHEN T1.RZ >= T3.FSLTDZ THEN
                      RED
                     WHEN T3.FSLTDZ - T1.RZ <= RANGE THEN
                      ORANGE
                     ELSE
                      NORMAL
                   END COLOR,
                   CASE
                     WHEN T1.RZ IS NULL OR T3.FSLTDZ IS NULL THEN
                      0
                     WHEN T1.RZ >= T3.FSLTDZ THEN
                      1
                     WHEN T3.FSLTDZ - T1.RZ <= RANGE THEN
                      2
                     ELSE
                      0
                   END WARNING,
                   CASE
                   --WHEN T1.RZ >= T3.FSLTDZ or T3.FSLTDZ - T1.RZ <= RANGE THEN
                     WHEN T1.RZ >= T3.FSLTDZ THEN
                      1
                     ELSE
                      0
                   END WARNINGBJ,
                   CASE
                     WHEN T1.RZ >= T3.FSLTDZ OR T3.FSLTDZ - T1.RZ <= RANGE THEN
                      RZ - FSLTDZ + 9999999
                     ELSE
                      T1.RZ
                   END orderbyIndex,
                   --是否测了雨量
                   DECODE(T5.STCD, NULL, 0, 1) YQ
              FROM DSE_ST_RSVR_REAL T1
            -- LEFT JOIN ST_STBPRP_B T2 ON T1.STCD = T2.STCD
              LEFT JOIN ST_RSVRFSR_B T3 ON T1.STCD = T3.STCD
                                      /* AND TO_NUMBER(TO_CHAR(T1.TM, 'mmdd')) >=
                                           T3.BGMD
                                       AND TO_NUMBER(TO_CHAR(T1.TM, 'mmdd')) <=
                                           T3.EDMD*/
              LEFT JOIN DSE_ST_LABEL_SET T4 ON rtrim(T4.STCD) =
                                               rtrim(T1.STCD)
                                           AND T4.LAYERID = 1
              LEFT JOIN DSE_ST_PPTN_REAL T5 ON T1.STCD = T5.STCD,
             ST_STBPRP_B T2
             WHERE T1.STCD = T2.STCD
               and t2.usfl = '1'
               and (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')
               AND (VADDVCD IS NULL OR T2.ADDVCD LIKE '%' || VADDVCD || '%'))

     where WARNINGBJ like '%' || ISWARING || '%'
    --FSLTDZ为空时，按rz排序
    --ORDER BY NVL(RZ - FSLTDZ, RZ) DESC;
     ORDER BY orderbyIndex DESC;
END PLATFORM_SSJK_RSVR;


/

