create PROCEDURE      PLATFORM_PPTN_YQCX_LS(P_STCDS       VARCHAR,
                                                  P_STIME       VARCHAR,
                                                  P_ETIME       VARCHAR,
                                                  P_PERIOD      INT,
                                                  P_PAGEFROM    INT,
                                                  P_PAGETO      INT,
                                                  RESULT_CURSOR OUT PLATFORM.CURSOR) IS
  --雨情查询  历史雨情 zouwei
  V_STIME     DATE;
  V_ETIME     DATE;
 -- V_ST_STTIME DATE; --小时间隔差补时间
BEGIN
  V_STIME := TO_DATE(P_STIME, 'yyyy-mm-dd hh24:mi:ss');
  V_ETIME := TO_DATE(P_ETIME, 'yyyy-mm-dd hh24:mi:ss');

  --累计雨量
  IF P_PERIOD = -1 THEN
    BEGIN

      OPEN RESULT_CURSOR FOR
        SELECT T.STCD,
               TRIM(TO_CHAR(ROUND(T.DRP, 1), '99999999990.9')) DRP,
               TRIM(T.STNM) STNM,
               T.NAME,
               T.ROWNUM_ ROWN
          FROM (

                SELECT TT.STCD,
                        ST.STNM,
                        DIST.NAME,
                        TT.DRP,
                        ROW_NUMBER() OVER(ORDER BY TT.DRP DESC) AS ROWNUM_
                  FROM (SELECT T1.STCD, SUM(DRP) DRP
                           FROM DSE_ST_PPTN_H T1
                          INNER JOIN (SELECT *
                                       FROM TABLE(CAST(FUNC_SPLITSTRING(P_STCDS) AS
                                                       PLATFORM_STCD_TYPE))) T2 ON T1.STCD =
                                                                                   T2.STCD
                          WHERE T1.TM > V_STIME
                            AND T1.TM <= V_ETIME
                          GROUP BY T1.STCD) TT
                 INNER JOIN ST_STBPRP_B ST ON TT.STCD = ST.STCD
                  LEFT JOIN SYS_DISTRICT DIST ON DIST.ADCODE = ST.ADDVCD

                ) T
         WHERE T.ROWNUM_ > P_PAGEFROM
           AND T.ROWNUM_ <= P_PAGETO;

    END;
    --按天统计
  ELSIF P_PERIOD = 24 THEN
    BEGIN

      OPEN RESULT_CURSOR FOR
        SELECT TP.*
          FROM (SELECT TPM.*, ROWNUM ROWN
                  FROM (SELECT T.STCD,
                               TO_CHAR(T.IDTM - 1, 'yyyy-mm-dd hh24:mi:ss') || '-' ||
                               TO_CHAR(T.IDTM, 'yyyy-mm-dd hh24:mi:ss') DT,
                               TRIM(TO_CHAR(ROUND(T.ACCP, 1), '99999999990.9')) DRP,
                               TRIM(ST.STNM) STNM,
                               DIST.NAME,
                               ROW_NUMBER() OVER(PARTITION BY T.STCD ORDER BY T.IDTM DESC)

                          FROM DSE_ST_PSTAT_R T
                         INNER JOIN (SELECT *
                                      FROM TABLE(CAST(FUNC_SPLITSTRING(P_STCDS) AS
                                                      PLATFORM_STCD_TYPE))) T2 ON T.STCD =
                                                                                  T2.STCD
                                                                              AND T.STTDRCD = '1'
                         INNER JOIN ST_STBPRP_B ST ON T.STCD = ST.STCD
                          LEFT JOIN SYS_DISTRICT DIST ON DIST.ADCODE =
                                                         ST.ADDVCD
                         WHERE T.IDTM >= V_STIME
                           AND T.IDTM <= V_ETIME

                        ) TPM
                 WHERE ROWNUM <= P_PAGETO

                ) TP
         WHERE TP.ROWN > P_PAGEFROM;

    END;
    --按月统计
  ELSIF P_PERIOD = 30 THEN
    BEGIN
      OPEN RESULT_CURSOR FOR
        SELECT TP.*
          FROM (SELECT TPM.*, ROWNUM ROWN
                  FROM (SELECT T.STCD,
                               TO_CHAR(ADD_MONTHS(T.IDTM, -1), 'yyyy-mm') DT,
                               TRIM(TO_CHAR(ROUND(T.ACCP, 1), '99999999990.9')) DRP,
                               TRIM(ST.STNM) STNM,
                               DIST.NAME,
                               ROW_NUMBER() OVER(PARTITION BY T.STCD ORDER BY T.IDTM DESC)

                          FROM DSE_ST_PSTAT_R T
                         INNER JOIN (SELECT *
                                      FROM TABLE(CAST(FUNC_SPLITSTRING(P_STCDS) AS
                                                      PLATFORM_STCD_TYPE))) T2 ON T.STCD =
                                                                                  T2.STCD
                                                                              AND T.STTDRCD = '5'
                         INNER JOIN ST_STBPRP_B ST ON T.STCD = ST.STCD
                          LEFT JOIN SYS_DISTRICT DIST ON DIST.ADCODE =
                                                         ST.ADDVCD
                         WHERE T.IDTM >= ADD_MONTHS(V_STIME, 1)
                           AND T.IDTM <= ADD_MONTHS(V_ETIME, 1)

                        ) TPM
                 WHERE ROWNUM <= P_PAGETO

                ) TP
         WHERE TP.ROWN > P_PAGEFROM;
    END;

  ELSIF P_PERIOD = 40 THEN
    BEGIN
      OPEN RESULT_CURSOR FOR
        SELECT TP.*
          FROM (SELECT TPM.*, ROWNUM ROWN
                  FROM (SELECT T.STCD,
                               CASE
                                  WHEN TO_NUMBER(TO_CHAR(T.IDTM, 'dd')) = 11 THEN
                                    TO_CHAR(T.IDTM, 'yyyy') || '年' ||
                                    TO_CHAR(T.IDTM, 'mm') || '月上旬'
                                 WHEN TO_NUMBER(TO_CHAR(T.IDTM, 'dd')) = 21 THEN
                                    TO_CHAR(T.IDTM, 'yyyy') || '年' ||
                                    TO_CHAR(T.IDTM, 'mm') || '月中旬'
                                 WHEN  TO_NUMBER(TO_CHAR(T.IDTM, 'mm')) > 1 and TO_NUMBER(TO_CHAR(T.IDTM, 'dd')) = 1 THEN
                                    TO_CHAR(T.IDTM, 'yyyy') || '年' ||
                                    TO_CHAR(add_months(T.IDTM,-1), 'mm') || '月下旬'
                                  WHEN  TO_NUMBER(TO_CHAR(T.IDTM, 'mm')) = 1 and TO_NUMBER(TO_CHAR(T.IDTM, 'dd')) = 1 THEN
                                    TO_CHAR(add_months(T.IDTM,-12), 'yyyy') || '年' ||
                                    TO_CHAR(add_months(T.IDTM,-1), 'mm') || '月下旬'
                               END DT,

                               TRIM(TO_CHAR(ROUND(T.ACCP, 1), '99999999990.9')) DRP,
                               TRIM(ST.STNM) STNM,
                               DIST.NAME,
                               ROW_NUMBER() OVER(PARTITION BY T.STCD ORDER BY T.IDTM DESC)

                          FROM DSE_ST_PSTAT_R T
                         INNER JOIN (SELECT *
                                      FROM TABLE(CAST(FUNC_SPLITSTRING(P_STCDS) AS
                                                      PLATFORM_STCD_TYPE))) T2 ON T.STCD =
                                                                                  T2.STCD
                                                                              AND T.STTDRCD = '4'
                         INNER JOIN ST_STBPRP_B ST ON T.STCD = ST.STCD
                          LEFT JOIN SYS_DISTRICT DIST ON DIST.ADCODE =
                                                         ST.ADDVCD

                         WHERE T.IDTM >= V_STIME
                           AND T.IDTM <= V_ETIME

                        ) TPM
                 WHERE ROWNUM <= P_PAGETO

                ) TP
         WHERE TP.ROWN > P_PAGEFROM;
    END;
    --按小时
  ELSIF P_PERIOD > 0 AND P_PERIOD < 24 THEN

    IF P_PERIOD = 1 THEN
      --1小时
      BEGIN

        OPEN RESULT_CURSOR FOR
          SELECT TP.*
            FROM (SELECT TPM.*, ROWNUM ROWN
                    FROM (SELECT T1.STCD,
                                 TO_CHAR(T1.TM, 'yyyy-mm-dd hh24') DT,
                                 TRIM(TO_CHAR(ROUND(T1.DRP, 1),
                                              '99999999990.9')) DRP,
                                 TRIM(ST.STNM) STNM,
                                 DIST.NAME,
                                 ROW_NUMBER() OVER(PARTITION BY T1.STCD ORDER BY T1.TM DESC)
                            FROM DSE_ST_PPTN_H T1
                           INNER JOIN (SELECT *
                                        FROM TABLE(CAST(FUNC_SPLITSTRING(P_STCDS) AS
                                                        PLATFORM_STCD_TYPE))) T2 ON T1.STCD =
                                                                                    T2.STCD
                           INNER JOIN ST_STBPRP_B ST ON T1.STCD = ST.STCD
                            LEFT JOIN SYS_DISTRICT DIST ON DIST.ADCODE =
                                                           ST.ADDVCD
                           WHERE T1.TM > V_STIME
                             AND T1.TM <= V_ETIME

                          ) TPM
                   WHERE ROWNUM <= P_PAGETO

                  ) TP
           WHERE TP.ROWN > P_PAGEFROM;
      END;
    ELSE
       begin
           OPEN RESULT_CURSOR FOR
      			select tb.dt,tb.stcd,tb.stnm,tb.name,tb.stlc,tb.drp,tb.rown from (
      					select dt,stcd,stnm,name,TRIM(stlc) stlc,drp,rown from (
      						SELECT b.stcd,
      						   d.NAME,
      						   b.STNM,
      						   b.STLC,
      							to_char(V_STIME+interv*P_PERIOD/24,'yyyy-mm-dd hh24')||'-'||
                    to_char(case when V_STIME+(interv+1)*P_PERIOD/24<V_ETIME then V_STIME+(interv+1)*P_PERIOD/24 else  V_ETIME end,'yyyy-mm-dd hh24') dt,
                  	TRIM(TO_CHAR(ROUND(t.DRP, 1),'99999999990.9')) DRP
      							,ROW_NUMBER() OVER(ORDER BY t.STCD,t.interv desc) AS rown
      						 from
      							( select h.STCD,
      							   	floor(((h.TM-1/24)-V_STIME)*24/P_PERIOD+0.01) interv,sum(DRP) drp
      									 from DSE_ST_PPTN_H h inner join
                           (SELECT *  FROM TABLE(CAST(FUNC_SPLITSTRING(P_STCDS) AS
                                       PLATFORM_STCD_TYPE))) t4  on t4.STCD=H.stcd
      									where h.TM>=V_STIME+1/24
      										and h.TM<=V_ETIME

                         	group by h.STCD,floor(((h.TM-1/24)-V_STIME)*24/P_PERIOD+0.01)
      							) t LEFT join ST_STBPRP_B b
      								on t.STCD=b.STCD
      							  LEFT	join SYS_DISTRICT d
      								on b.ADDVCD=d.ADCODE

      					) aaa where aaa.rown<=P_PAGETO
              )tb where tb.rown >P_PAGEFROM;

        end;
    END IF;

  END IF;

END PLATFORM_PPTN_YQCX_LS;


/

