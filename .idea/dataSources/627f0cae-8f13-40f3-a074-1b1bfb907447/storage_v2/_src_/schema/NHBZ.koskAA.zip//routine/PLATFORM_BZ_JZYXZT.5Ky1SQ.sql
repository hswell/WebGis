create procedure      PLATFORM_BZ_JZYXZT(STCDS    VARCHAR,
                                               ST       VARCHAR,
                                               ET       VARCHAR,
                                               PAGEFROM INT,
                                               PAGETO   INT,
                                               CUR1     OUT PLATFORM.CURSOR) is

  tbout        PLATFORM_BZ_RUNSTATE_TYPE := PLATFORM_BZ_RUNSTATE_TYPE(null);
  tb           PLATFORM_BZ_RUNSTATE_TABLE := PLATFORM_BZ_RUNSTATE_TABLE(null,
                                                                        NULL,
                                                                        null,
                                                                        null,
                                                                        null,
                                                                        null,
                                                                        null,
                                                                        null,
                                                                        null);
  STCDA        VARCHAR(12);
  AIRCREWNMA   VARCHAR(10); --机组编号
  KTMA         DATE; --开机时间
  K_IN_WATERA  numeric(8, 3); --开机内水位
  K_OUT_WATERA numeric(8, 3); --开机外水位
  GTMA         DATE; --关机时间
  G_IN_WATERA  numeric(8, 3); --关机内水位
  G_OUT_WATERA numeric(8, 3); --关机外水位
  FLAGA        CHAR(1); -- 判断是否插入完成 1:完成，0:未完成
  lv_l         number;
  NUM          NUMBER;
  STR          VARCHAR(2000);
  TM           VARCHAR(20);
  STCD         VARCHAR(12);
  STATE        VARCHAR(12);
  NSW          numeric(8, 3);
  WSW          numeric(8, 3);
  AIRCREWNM    VARCHAR(10);
  JZSTNAME     VARCHAR(10); -- 机组状态字段  如N1
  JZNAME       VARCHAR(10); --机组名称  如1#
  STSTR        VARCHAR(20);
  ETSTR        VARCHAR(20);
begin
  lv_l := 0;
  FOR STT IN (SELECT *
                FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                PLATFORM_STCD_TYPE))) LOOP
    BEGIN
      SELECT COUNT(D.ENNMCD)
        INTO NUM
        FROM DSE_BZ_PUMB D, V_TB1502_MEIDSBI V
       WHERE D.ENNMCD = V.ENNMCD
         AND TRIM(V.STCD) = TRIM(STT.STCD);
    END;
    STSTR := ST || ':00:00';
    ETSTR := ET || ':00:00';
    WHILE (NUM > 0) LOOP
      DECLARE
        TYPE ACURSOR IS REF CURSOR;
        DCURSOR ACURSOR;
      BEGIN
        TM        := NULL;
        STCD      := NULL;
        STATE     := NULL;
        NSW       := NULL;
        WSW       := NULL;
        JZSTNAME  := 'N' || NUM;
        JZNAME    := NUM || '#';
        AIRCREWNM := NUM || '#';
        STR       := 'SELECT TO_CHAR(T.TM,''YYYY-MM-DD HH24:MI:SS'')TM,T.STCD,T.' ||
                     JZSTNAME ||
                     ',T.NSW,T.WSW FROM DSE_BZ_RUNSTATE_R T WHERE TRIM(T.STCD) = TRIM(''' ||
                     STT.STCD || ''')  AND T.TM >= TO_DATE(''' || STSTR ||
                     ''', ''yyyy-mm-dd hh24:mi:ss'') AND T.TM < TO_DATE(''' ||
                     ETSTR ||
                     ''', ''yyyy-mm-dd hh24:mi:ss'')  ORDER BY T.STCD, T.TM ASC';
        OPEN DCURSOR FOR STR;
        LOOP
          FETCH DCURSOR
            INTO TM, STCD, STATE, NSW, WSW;
          BEGIN
            IF STATE = '0' THEN
              BEGIN
                SELECT AA.STCD,
                       AA.AIRCREWNM,
                       AA.KTM,
                       AA.K_IN_WATER,
                       AA.K_OUT_WATER,
                       AA.GTM,
                       AA.G_IN_WATER,
                       AA.G_OUT_WATER,
                       AA.FLAG
                  INTO STCDA,
                       AIRCREWNMA,
                       KTMA,
                       K_IN_WATERA,
                       K_OUT_WATERA,
                       GTMA,
                       G_IN_WATERA,
                       G_OUT_WATERA,
                       FLAGA
                  FROM (SELECT A.*
                          FROM TABLE(CAST(TBOUT AS PLATFORM_BZ_RUNSTATE_TYPE)) A
                         WHERE TRIM(STT.STCD) = TRIM(A.STCD)
                           AND A.AIRCREWNM = JZNAME
                           AND A.STCD IS NOT NULL
                           AND A.FLAG = '0'
                         ORDER BY A.KTM DESC) AA
                 WHERE ROWNUM = 1;
                IF STCDA IS NULL THEN
                  BEGIN
                    TB.STCD        := STT.STCD;
                    TB.AIRCREWNM   := JZNAME;
                    TB.GTM         := TO_DATE(TM, 'YYYY-MM-DD HH24:MI:SS');
                    TB.G_IN_WATER  := NSW;
                    TB.G_OUT_WATER := WSW;
                    TB.KTM         := NULL;
                    TB.K_IN_WATER  := NULL;
                    TB.K_OUT_WATER := NULL;
                    TB.FLAG        := '1';
                    lv_l           := lv_l + 1;
                    TBOUT.EXTEND(1);
                    TBOUT(lv_l) := TB;

                  EXCEPTION
                    WHEN OTHERS THEN
                      NULL;
                  END;
                ELSIF STCDA IS NOT NULL AND
                      TO_DATE(TM, 'YYYY-MM-DD HH24:MI:SS') > KTMA THEN
                  BEGIN
                    TB.STCD := STCDA;
                    TB.AIRCREWNM := AIRCREWNMA;
                    TB.KTM := KTMA;
                    TB.K_IN_WATER := K_IN_WATERA;
                    TB.K_OUT_WATER := K_OUT_WATERA;
                    TB.GTM := TO_DATE(TM, 'YYYY-MM-DD HH24:MI:SS');
                    TB.G_IN_WATER := NSW;
                    TB.G_OUT_WATER := WSW;
                    TB.FLAG := '1';
                    lv_l := lv_l;
                    TBOUT(lv_l) := TB;

                  END;
                END IF;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  BEGIN
                    TB.STCD        := STT.STCD;
                    TB.AIRCREWNM   := JZNAME;
                    TB.KTM         := NULL;
                    TB.K_IN_WATER  := NULL;
                    TB.K_OUT_WATER := NULL;
                    TB.GTM         := TO_DATE(TM, 'YYYY-MM-DD HH24:MI:SS');
                    TB.G_IN_WATER  := NSW;
                    TB.G_OUT_WATER := WSW;
                    TB.FLAG        := '1';
                    lv_l           := lv_l + 1;
                    TBOUT.EXTEND(1);
                    TBOUT(lv_l) := TB;

                  EXCEPTION
                    WHEN OTHERS THEN
                      NULL;
                  END;
              END;
            ELSIF STATE = '1' THEN
              BEGIN
                SELECT AA.STCD,
                       AA.AIRCREWNM,
                       AA.KTM,
                       AA.K_IN_WATER,
                       AA.K_OUT_WATER,
                       AA.GTM,
                       AA.G_IN_WATER,
                       AA.G_OUT_WATER,
                       AA.FLAG
                  INTO STCDA,
                       AIRCREWNMA,
                       KTMA,
                       K_IN_WATERA,
                       K_OUT_WATERA,
                       GTMA,
                       G_IN_WATERA,
                       G_OUT_WATERA,
                       FLAGA
                  FROM (SELECT A.*
                          FROM TABLE(CAST(TBOUT AS PLATFORM_BZ_RUNSTATE_TYPE)) A
                         WHERE TRIM(STT.STCD) = TRIM(A.STCD)
                           AND A.AIRCREWNM = JZNAME
                           AND A.STCD IS NOT NULL
                           AND A.FLAG = '0'
                         ORDER BY A.KTM DESC) AA
                 WHERE ROWNUM = 1;
                IF STCDA IS NULL THEN
                  BEGIN
                    tb.STCD        := STCD;
                    TB.KTM         := TO_DATE(TM, 'YYYY-MM-DD HH24:MI:SS');
                    TB.AIRCREWNM   := JZNAME;
                    TB.K_IN_WATER  := NSW;
                    TB.K_OUT_WATER := WSW;
                    TB.GTM         := NULL;
                    TB.G_IN_WATER  := NULL;
                    TB.G_OUT_WATER := NULL;
                    TB.FLAG        := '0';
                    lv_l           := lv_l + 1;
                    TBOUT.EXTEND(1);
                    TBOUT(lv_l) := TB;

                  EXCEPTION
                    WHEN OTHERS THEN
                      NULL;
                  END;
                END IF;
              EXCEPTION
                WHEN NO_DATA_FOUND THEN
                  BEGIN
                    tb.STCD        := STCD;
                    TB.KTM         := TO_DATE(TM, 'YYYY-MM-DD HH24:MI:SS');
                    TB.AIRCREWNM   := JZNAME;
                    TB.K_IN_WATER  := NSW;
                    TB.K_OUT_WATER := WSW;
                    TB.GTM         := NULL;
                    TB.G_IN_WATER  := NULL;
                    TB.G_OUT_WATER := NULL;
                    TB.FLAG        := '0';
                    lv_l           := lv_l + 1;
                    TBOUT.EXTEND(1);
                    TBOUT(lv_l) := TB;

                  EXCEPTION
                    WHEN OTHERS THEN
                      NULL;
                  END;
              END;
            END IF;
          END;
          exit when DCURSOR%notfound;
        END LOOP;
        CLOSE DCURSOR;
      END;
      NUM := NUM - 1;
    END LOOP;
  END LOOP;

  OPEN CUR1 FOR
    SELECT TT.*, ROWNUM
      FROM (SELECT TRIM(B.STNM) STNM,
                   D.NAME AS ADDVNM,
                   C.STCD,
                   C.AIRCREWNM,
                   TO_CHAR(C.KTM, 'YYYY-MM-DD HH24:MI:SS') KTM,
                   C.K_IN_WATER,
                   C.K_OUT_WATER,
                   TO_CHAR(C.GTM, 'YYYY-MM-DD HH24:MI:SS') GTM,
                   C.G_IN_WATER,
                   C.G_OUT_WATER,
                   ROWNUM ROWNUM_
              FROM TABLE(CAST(TBOUT AS PLATFORM_BZ_RUNSTATE_TYPE)) C
              LEFT JOIN ST_STBPRP_B B
                ON TRIM(C.STCD) = TRIM(B.STCD)
              LEFT JOIN SYS_DISTRICT D
                ON D.ADCODE = B.ADDVCD
             WHERE C.STCD IS NOT NULL
               AND C.KTM IS NOT NULL
             ORDER BY C.STCD, C.AIRCREWNM, C.KTM DESC) TT
     WHERE TT.ROWNUM_ > PAGEFROM
       AND TT.ROWNUM_ <= PAGETO;
end PLATFORM_BZ_JZYXZT;


/

