create function      FUNC_GIS_LatMERCATOR(LTTD NUMBER) return number is
  Result number;
  --createTime 2013-08-16
  --author chenya
  --纬度转墨卡托
  LV_Y number;
begin
  LV_Y:=ln(tan((90+LTTD)*ACOS(-1)/360))/(ACOS(-1)/180);
  Result:=LV_Y *20037508.34/180;
  return(Result);
end FUNC_GIS_LatMERCATOR;


/

