create procedure      PLATFORM_SZ_SZJS_2(
                                               VSTCD VARCHAR,--STCD
                                               STARTSTR VARCHAR,--开始时间
                                               ENDSTR   VARCHAR,--结束时间
                                               QTYPE NUMBER,--查询方式,0；查询历史，1：查询当前推24小时数据
                                               CUR OUT PLATFORM.CURSOR,
                                               CUR1 OUT PLATFORM.CURSOR,
                                               CUR2 OUT PLATFORM.CURSOR
) is
ST DATE;
ET DATE;
begin
  IF QTYPE = 1 THEN
    BEGIN
      ST := SYSDATE-1;
      ET := SYSDATE;
    END;
  ELSIF QTYPE = 0 THEN
    BEGIN
      ST := TO_DATE(STARTSTR,'YYYY-MM-DD HH24:MI:SS');
      ET := TO_DATE(ENDSTR,'YYYY-MM-DD HH24:MI:SS');
    END;
  END IF;
  --查询历史数据
  OPEN CUR FOR
       SELECT TO_CHAR(TT.TM,'YYYY-MM-DD HH24:MI:SS') TM,TT.STCD,TRIM(B.STNM) STNM,TT.LL,ROWNUM,
       CASE TT.STATE WHEN '1' THEN '开' WHEN '0' THEN '关' ELSE '故障' END STATENAME,
       TT.OUT_WATER,TT.IN_WATER,TT.STATE,TT.N1,TT.N2,TT.N3,TT.N4,TT.N5,TT.N6,TT.N7,TT.N8,TT.N9
        FROM dse_sz_runinfo_r TT ,(SELECT *
                          FROM TABLE(CAST(FUNC_SPLITSTRING(VSTCD) AS
                                          PLATFORM_STCD_TYPE))) T1,ST_STBPRP_B B
        WHERE TT.STCD = T1.STCD  AND TT.TM>ST AND TT.TM<=ET AND B.STCD = TT.STCD ORDER BY TT.TM ASC,TT.STCD desc;
  --查询闸门数量
  OPEN CUR1 FOR
       SELECT B.ZMNUM,R.STCD,S.STNM  FROM DSE_TB0001_REMARK_B R,TB0901_SLCMIN_044 B ,(SELECT *
                          FROM TABLE(CAST(FUNC_SPLITSTRING(VSTCD) AS
                                          PLATFORM_STCD_TYPE))) T1,ST_STBPRP_B S
        WHERE  R.STCD = T1.STCD AND R.ENNMCD = B.ENNMCD AND S.STCD = R.STCD;


  --查询闸门开关数据
  OPEN CUR2 FOR
       SELECT TO_CHAR(TT.TM,'YYYY-MM-DD HH24:MI:SS') TM,TT.STCD,TRIM(B.STNM) STNM,ROWNUM,
       CASE TT.STATE WHEN '1' THEN '开' WHEN '0' THEN '关' ELSE '故障' END STATENAME,
       TT.OUT_WATER,TT.IN_WATER,TT.STATE,TT.N1,TT.N2,TT.N3,TT.N4,TT.N5,TT.N6,TT.N7,TT.N8,TT.N9
        FROM dse_sz_runstate_r TT ,(SELECT *
                          FROM TABLE(CAST(FUNC_SPLITSTRING(VSTCD) AS
                                          PLATFORM_STCD_TYPE))) T1,ST_STBPRP_B B
        WHERE TT.STCD = T1.STCD  AND TT.TM>ST AND TT.TM<=ET AND B.STCD = TT.STCD ORDER BY TT.TM ASC,TT.STCD desc;
end PLATFORM_SZ_SZJS_2;


/

