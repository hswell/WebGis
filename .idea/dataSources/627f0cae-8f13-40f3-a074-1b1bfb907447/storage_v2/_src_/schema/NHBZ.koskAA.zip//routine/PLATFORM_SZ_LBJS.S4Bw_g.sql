create procedure      PLATFORM_SZ_LBJS(STCDS    VARCHAR, --测站编码串
                                             VALIDMIN INT, --测站数据有效时限(默认30分钟)
                                             PAGEFROM INT, --起始页
                                             PAGETO   INT, --终止页
                                             CURR     OUT PLATFORM.CURSOR --输出游标
                                             ) is
begin
  IF STCDS IS NOT NULL THEN
    BEGIN
      OPEN CURR FOR
        SELECT TT.*
          FROM (SELECT T.STCD,
                       TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') TM,
                       T.OUT_WATER,
                       T.IN_WATER,
                       CASE
                         WHEN T.TM >= (SYSDATE - 1 / 24 / 60 * VALIDMIN) THEN
                          '1'
                         ELSE
                          '0'
                       END ISVALID,
                       T.N1,
                       T.KD1,
                       T.LL1,
                       T.N2,
                       T.KD2,
                       T.LL2,
                       T.N3,
                       T.KD3,
                       T.LL3,
                       T.N4,
                       T.KD4,
                       T.LL4,
                       T.N5,
                       T.KD5,
                       T.LL5,
                       T.N6,
                       T.KD6,
                       T.LL6,
                       T.N7,
                       T.KD7,
                       T.LL7,
                       T.N8,
                       T.KD8,
                       T.LL8,
                       T.N9,
                       T.KD9,
                       T.LL9,
                       rtrim(S.STNM) STNM,
                       V.ZMNUM,
                       V1.KZTM,
                       V1.GZTM,
                       ROWNUM ROWNUM_
                  FROM DSE_SZ_RUNINFO_REAL T
                 INNER JOIN (SELECT *
                              FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                              PLATFORM_STCD_TYPE))) T1
                    ON T.STCD = T1.STCD
                 INNER JOIN ST_STBPRP_B S
                    ON T.STCD = S.STCD
                  LEFT JOIN V_TB0901_SLCMIN V
                    ON V.STCD = T.STCD
                  left join V_SZ_RUNSTATE_R V1
                    ON T.STCD = V1.STCD
                 ORDER BY T.STCD, T.TM DESC) TT
         WHERE TT.ROWNUM_ > PAGEFROM
           AND TT.ROWNUM_ <= PAGETO;
   END;
  ELSIF STCDS IS NULL THEN
  BEGIN
    OPEN CURR FOR
        SELECT TT.*
          FROM (SELECT T.STCD,
                       TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI:SS') TM,
                       T.OUT_WATER,
                       T.IN_WATER,
                       CASE
                         WHEN T.TM >= (SYSDATE - 1 / 24 / 60 * VALIDMIN) THEN
                          '1'
                         ELSE
                          '0'
                       END ISVALID,
                       T.N1,
                       T.KD1,
                       T.LL1,
                       T.N2,
                       T.KD2,
                       T.LL2,
                       T.N3,
                       T.KD3,
                       T.LL3,
                       T.N4,
                       T.KD4,
                       T.LL4,
                       T.N5,
                       T.KD5,
                       T.LL5,
                       T.N6,
                       T.KD6,
                       T.LL6,
                       T.N7,
                       T.KD7,
                       T.LL7,
                       T.N8,
                       T.KD8,
                       T.LL8,
                       T.N9,
                       T.KD9,
                       T.LL9,
                       S.STNM,
                       V.ZMNUM,
                       V1.KZTM,
                       V1.GZTM,
                       ROWNUM ROWNUM_
                  FROM DSE_SZ_RUNINFO_REAL T
                 INNER JOIN ST_STBPRP_B S
                    ON T.STCD = S.STCD
                  LEFT JOIN V_TB0901_SLCMIN V
                    ON V.STCD = T.STCD
                  left join V_SZ_RUNSTATE_R V1
                    ON T.STCD = V1.STCD
                 ORDER BY T.STCD, T.TM DESC) TT
         WHERE TT.ROWNUM_ > PAGEFROM
           AND TT.ROWNUM_ <= PAGETO;
  END;
  END IF;
  EXCEPTION
  WHEN OTHERS THEN
    NULL;
end PLATFORM_SZ_LBJS;


/

