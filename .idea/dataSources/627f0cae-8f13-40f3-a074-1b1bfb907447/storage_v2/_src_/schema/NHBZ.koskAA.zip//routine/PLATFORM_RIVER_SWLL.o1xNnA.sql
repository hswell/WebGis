create PROCEDURE      PLATFORM_RIVER_SWLL(VSTCD VARCHAR,
                                                CURR1 OUT PLATFORM.CURSOR) IS
BEGIN
  --返回河道的静态水位流量关系数据
  OPEN CURR1 FOR
    SELECT TT.*, ROWNUM
      FROM (SELECT TRIM(TO_CHAR(ROUND(Z, 2), '99999999990.99')) Z,
                   FUNC_NUMERIC(Q, 3) Q
              FROM ST_ZQRL_B
             WHERE STCD = VSTCD
             ORDER BY TO_NUMBER(Z) DESC) TT;

END PLATFORM_RIVER_SWLL;


/

