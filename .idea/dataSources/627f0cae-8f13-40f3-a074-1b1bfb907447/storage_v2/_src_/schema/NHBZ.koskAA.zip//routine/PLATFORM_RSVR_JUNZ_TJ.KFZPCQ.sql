create procedure      PLATFORM_RSVR_JUNZ_TJ(p_tm date) is

 v_mm int;
 v_day int;
 TJTM date;
begin
 if p_tm is null then
		begin
         TJTM:=TO_DATE(TO_CHAR(sysdate, 'YYYY-MM-dd') || ' 00:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
		end;
	else
		begin
		    TJTM:=TO_DATE(TO_CHAR(p_tm, 'YYYY-MM-dd') || ' 00:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
		end;
  end if;
 v_mm:=to_number(to_char(TJTM,'mm'));
 v_day:=to_number(to_char(TJTM,'dd'));


  declare V_STCD char(8);
	 V_TJSTATUS number(6,1); --统计标识
	 V_STCD_TJ char(8); --是否已经存在对于记录判断
	 V_AVRZ number(7,3);--平均水位
   V_AVINQ  number(9,3);--平均入流量
   V_AVOTQ number(9,3);--平均出流量
   V_AVW number(9,3);--平均蓄水量
   begin
       for CURSOR_RSVR_JUNZ_REAL in (SELECT r.STCD from dse_st_rsvr_real r inner join st_stbprp_b st on r.stcd=st.stcd and st.usfl='1' and st.sttp='RR' ) loop
        BEGIN

              V_STCD:=CURSOR_RSVR_JUNZ_REAL.STCD;

              --日均值  只会返回一条记录 使用max避免查询不到记录时into 异常情况
              select max(stcd),max(TJSTATUS) into V_STCD_TJ,V_TJSTATUS from DSE_ST_RSVRAV_R where  STTDRCD='1' and stcd=V_STCD and idtm=TJTM;
              if V_STCD_TJ is not null then
      					 begin
      						if V_TJSTATUS=1 then
      							begin

                      SELECT max(avz),max(avq),max(avotq),max(avw) into V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW from  table(func_rsvr_area_day_avz_avq_avw(V_STCD,TJTM));
      								update DSE_ST_RSVRAV_R set avrz=V_AVRZ,AVINQ=V_AVINQ,avotq=V_AVOTQ,avw=V_AVW where STTDRCD='1' and stcd=V_STCD and idtm=TJTM;
      							end;
                   end if;
      					end;
      				else
      					begin
      						 SELECT max(avz),max(avq),max(avotq),max(avw) into V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW from  table(func_rsvr_area_day_avz_avq_avw(V_STCD,TJTM));
      						 insert into DSE_ST_RSVRAV_R(stcd,idtm,sttdrcd,AVRZ,AVINQ,AVOTQ,AVW,tjstatus)
                         values(V_STCD,TJTM,'1',V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW,1);
      					end;
              end if;

              --统计旬均值
    				if 	v_day=1 or v_day=11 or v_day=21 then
    					  begin
                   V_STCD_TJ:=null;
                   V_TJSTATUS:=null;
                   select max(stcd),max(TJSTATUS) into V_STCD_TJ,V_TJSTATUS from DSE_ST_RSVRAV_R where  STTDRCD='4' and stcd=V_STCD and idtm=TJTM;
                   if V_STCD_TJ is not null then
          					 begin
          						if V_TJSTATUS=1 then
          							begin

                          SELECT max(avz),max(avq),max(avotq),max(avw) into V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW from  table(func_rsvr_area_xun_avz_avq_avw(V_STCD,TJTM));
          									update DSE_ST_RSVRAV_R set avrz=V_AVRZ,AVINQ=V_AVINQ,avotq=V_AVOTQ,avw=V_AVW  where STTDRCD='4' and stcd=V_STCD and idtm=TJTM;
          							end;
                       end if;
          					end;
          				 else
          					 begin
          						  SELECT max(avz),max(avq),max(avotq),max(avw) into V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW from  table(func_rsvr_area_xun_avz_avq_avw(V_STCD,TJTM));
          						  insert into DSE_ST_RSVRAV_R(stcd,idtm,sttdrcd,AVRZ,AVINQ,AVOTQ,AVW,tjstatus)
                         values(V_STCD,TJTM,'4',V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW,1);
          				 	 end;
                   end if;
    					end;
           end if;
            --统计月均值
				  if 	v_day=1 then
					  begin
						      V_STCD_TJ:=null;
                  V_TJSTATUS:=null;
                   select max(stcd),max(TJSTATUS) into V_STCD_TJ,V_TJSTATUS from DSE_ST_RSVRAV_R where  STTDRCD='5' and stcd=V_STCD and idtm=TJTM;
                   if V_STCD_TJ is not null then
          					 begin
          						if V_TJSTATUS=1 then
          							begin

                          SELECT max(avz),max(avq),max(avotq),max(avw) into V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW from  table(func_rsvr_area_mm_avz_avq_avw(V_STCD,TJTM));
          								update DSE_ST_RSVRAV_R set avrz=V_AVRZ,AVINQ=V_AVINQ where STTDRCD='5' and stcd=V_STCD and idtm=TJTM;
          							end;
                       end if;
          					end;
          				 else
          					 begin
          						  SELECT max(avz),max(avq),max(avotq),max(avw) into V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW from  table(func_rsvr_area_mm_avz_avq_avw(V_STCD,TJTM));
          						 insert into DSE_ST_RSVRAV_R(stcd,idtm,sttdrcd,AVRZ,AVINQ,AVOTQ,AVW,tjstatus)
                         values(V_STCD,TJTM,'5',V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW,1);
          				 	 end;
                   end if;
					  end;
          end if;
          --统计年均值
				  if v_mm=1 and	v_day=1  then
					  begin
						      V_STCD_TJ:=null;
                  V_TJSTATUS:=null;
                   select max(stcd),max(TJSTATUS) into V_STCD_TJ,V_TJSTATUS from DSE_ST_RSVRAV_R where  STTDRCD='6' and stcd=V_STCD and idtm=TJTM;
                   if V_STCD_TJ is not null then
          					 begin
          						if V_TJSTATUS=1 then
          							begin

                          SELECT max(avz),max(avq),max(avotq),max(avw) into V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW from  table(func_rsvr_area_y_avz_avq_avw(V_STCD,TJTM));
          								update DSE_ST_RSVRAV_R set avrz=V_AVRZ,AVINQ=V_AVINQ,avotq=V_AVOTQ,avw=V_AVW  where STTDRCD='6' and stcd=V_STCD and idtm=TJTM;
          							end;
                       end if;
          					end;
          				 else
          					 begin
          						  SELECT max(avz),max(avq),max(avotq),max(avw) into V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW from  table(func_rsvr_area_y_avz_avq_avw(V_STCD,TJTM));
          						  insert into DSE_ST_RSVRAV_R(stcd,idtm,sttdrcd,AVRZ,AVINQ,AVOTQ,AVW,tjstatus)
                         values(V_STCD,TJTM,'6',V_AVRZ,V_AVINQ,V_AVOTQ,V_AVW,1);
          				 	 end;
                   end if;
					  end;
          end if;



          COMMIT;
          EXCEPTION
            WHEN OTHERS THEN
              ROLLBACK;
        END;
    END loop;

   end;



end PLATFORM_RSVR_JUNZ_TJ;


/

