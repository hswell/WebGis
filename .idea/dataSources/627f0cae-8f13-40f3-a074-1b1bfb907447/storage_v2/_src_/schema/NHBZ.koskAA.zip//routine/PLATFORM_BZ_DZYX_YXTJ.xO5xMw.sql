create procedure      PLATFORM_BZ_DZYX_YXTJ(STCDS    VARCHAR,
                                                  ST       VARCHAR,
                                                  ET       VARCHAR,
                                                  PAGEFROM INT,
                                                  PAGETO   INT,
                                                  CUR1     OUT PLATFORM.CURSOR
                                                  --,CUR2  OUT PLATFORM.CURSOR
                                                  ) is
  /**
  *DESCRIPTION:多站运行统计
  *DATE:2013年8月5日17:00:47
  */
  tbout        PLATFORM_BZ_RUNSTATE_TYPE := PLATFORM_BZ_RUNSTATE_TYPE(null);
  tb           PLATFORM_BZ_RUNSTATE_TABLE := PLATFORM_BZ_RUNSTATE_TABLE(null,
                                                                        NULL,
                                                                        null,
                                                                        null,
                                                                        null,
                                                                        null,
                                                                        null,
                                                                        null,
                                                                        null);
  STCDA        VARCHAR(12);
  AIRCREWNMA   VARCHAR(10); --机组编号
  KTMA         DATE; --开机时间
  K_IN_WATERA  numeric(8, 3); --开机内水位
  K_OUT_WATERA numeric(8, 3); --开机外水位
  GTMA         DATE; --关机时间
  G_IN_WATERA  numeric(8, 3); --关机内水位
  G_OUT_WATERA numeric(8, 3); --关机外水位
  FLAGA        CHAR(1); -- 判断是否插入完成 1:完成，0:未完成
  lv_l         number;
  NUM          NUMBER;
  TM           VARCHAR(20);
  STSTR        VARCHAR(20);
  ETSTR        VARCHAR(20);
begin
  lv_l := 0;
  FOR STT IN (SELECT *
                FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                PLATFORM_STCD_TYPE))) LOOP
    BEGIN
      SELECT COUNT(D.ENNMCD)
        INTO NUM
        FROM DSE_BZ_PUMB D, V_TB1502_MEIDSBI V
       WHERE D.ENNMCD = V.ENNMCD
         AND TRIM(V.STCD) = TRIM(STT.STCD);
    END;
    STSTR := ST || ':00:00';
    ETSTR := ET || ':00:00';

    FOR RTT IN (SELECT T.STCD,T.NSW,T.WSW,T.STATE,TO_CHAR(T.TM,'YYYY-MM-DD HH24:MI:SS')TM
                  FROM DSE_BZ_RUNSTATE_R T
                 WHERE STT.STCD = T.STCD AND T.TM >= TO_DATE(STSTR, 'YYYY-MM-DD HH24:MI:SS')
                   AND T.TM <= TO_DATE(ETSTR, 'YYYY-MM-DD HH24:MI:SS')
                 ORDER BY STCD, TM) LOOP
      BEGIN
        IF RTT.STATE = '0' THEN
          BEGIN
            SELECT AA.STCD,
                   AA.AIRCREWNM,
                   AA.KTM,
                   AA.K_IN_WATER,
                   AA.K_OUT_WATER,
                   AA.GTM,
                   AA.G_IN_WATER,
                   AA.G_OUT_WATER,
                   AA.FLAG
              INTO STCDA,
                   AIRCREWNMA,
                   KTMA,
                   K_IN_WATERA,
                   K_OUT_WATERA,
                   GTMA,
                   G_IN_WATERA,
                   G_OUT_WATERA,
                   FLAGA
              FROM (SELECT A.*
                      FROM TABLE(CAST(TBOUT AS PLATFORM_BZ_RUNSTATE_TYPE)) A
                     WHERE TRIM(STT.STCD) = TRIM(A.STCD)
                       AND A.STCD IS NOT NULL
                       AND A.FLAG = '0'
                     ORDER BY A.KTM DESC) AA
             WHERE ROWNUM = 1;
            IF STCDA IS NULL THEN
              BEGIN
                TB.STCD        := RTT.STCD;
                TB.AIRCREWNM   := NULL;
                TB.GTM         := TO_DATE(RTT.TM, 'YYYY-MM-DD HH24:MI:SS');
                TB.G_IN_WATER  := RTT.NSW;
                TB.G_OUT_WATER := RTT.WSW;
                TB.KTM         := NULL;
                TB.K_IN_WATER  := NULL;
                TB.K_OUT_WATER := NULL;
                TB.FLAG        := '1';
                lv_l           := lv_l + 1;
                TBOUT.EXTEND(1);
                TBOUT(lv_l) := TB;

              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            ELSIF STCDA IS NOT NULL AND
                  TO_DATE(RTT.TM, 'YYYY-MM-DD HH24:MI:SS') > KTMA THEN
              BEGIN
                TB.STCD := STCDA;
                TB.AIRCREWNM := AIRCREWNMA;
                TB.KTM := KTMA;
                TB.K_IN_WATER := K_IN_WATERA;
                TB.K_OUT_WATER := K_OUT_WATERA;
                TB.GTM := TO_DATE(RTT.TM, 'YYYY-MM-DD HH24:MI:SS');
                TB.G_IN_WATER := RTT.NSW;
                TB.G_OUT_WATER := RTT.WSW;
                TB.FLAG := '1';
                lv_l := lv_l;
                TBOUT(lv_l) := TB;

              END;
            END IF;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              BEGIN
                TB.STCD        := RTT.STCD;
                TB.AIRCREWNM   := NULL;
                TB.KTM         := NULL;
                TB.K_IN_WATER  := NULL;
                TB.K_OUT_WATER := NULL;
                TB.GTM         := TO_DATE(RTT.TM, 'YYYY-MM-DD HH24:MI:SS');
                TB.G_IN_WATER  := RTT.NSW;
                TB.G_OUT_WATER := RTT.WSW;
                TB.FLAG        := '1';
                lv_l           := lv_l + 1;
                TBOUT.EXTEND(1);
                TBOUT(lv_l) := TB;

              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
          END;
        ELSIF RTT.STATE = '1' THEN
          BEGIN
            SELECT AA.STCD,
                   AA.AIRCREWNM,
                   AA.KTM,
                   AA.K_IN_WATER,
                   AA.K_OUT_WATER,
                   AA.GTM,
                   AA.G_IN_WATER,
                   AA.G_OUT_WATER,
                   AA.FLAG
              INTO STCDA,
                   AIRCREWNMA,
                   KTMA,
                   K_IN_WATERA,
                   K_OUT_WATERA,
                   GTMA,
                   G_IN_WATERA,
                   G_OUT_WATERA,
                   FLAGA
              FROM (SELECT A.*
                      FROM TABLE(CAST(TBOUT AS PLATFORM_BZ_RUNSTATE_TYPE)) A
                     WHERE TRIM(STT.STCD) = TRIM(A.STCD)
                       AND A.STCD IS NOT NULL
                       AND A.FLAG = '0'
                     ORDER BY A.KTM DESC) AA
             WHERE ROWNUM = 1;
            IF STCDA IS NULL THEN
              BEGIN
                tb.STCD        := RTT.STCD;
                TB.KTM         := TO_DATE(RTT.TM, 'YYYY-MM-DD HH24:MI:SS');
                TB.AIRCREWNM   := NULL;
                TB.K_IN_WATER  := RTT.NSW;
                TB.K_OUT_WATER := RTT.WSW;
                TB.GTM         := NULL;
                TB.G_IN_WATER  := NULL;
                TB.G_OUT_WATER := NULL;
                TB.FLAG        := '0';
                lv_l           := lv_l + 1;
                TBOUT.EXTEND(1);
                TBOUT(lv_l) := TB;

              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            END IF;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              BEGIN
                tb.STCD        := RTT.STCD;
                TB.KTM         := TO_DATE(RTT.TM, 'YYYY-MM-DD HH24:MI:SS');
                TB.AIRCREWNM   := NULL;
                TB.K_IN_WATER  := RTT.NSW;
                TB.K_OUT_WATER := RTT.WSW;
                TB.GTM         := NULL;
                TB.G_IN_WATER  := NULL;
                TB.G_OUT_WATER := NULL;
                TB.FLAG        := '0';
                lv_l           := lv_l + 1;
                TBOUT.EXTEND(1);
                TBOUT(lv_l) := TB;

              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
          END;
        END IF;
      END;
    END LOOP;

  END LOOP;

   --OPEN CUR2 FOR SELECT * FROM TABLE(CAST(TBOUT AS PLATFORM_BZ_RUNSTATE_TYPE)) S;

  OPEN CUR1 FOR
    SELECT TT.*,
           ROUND(TT.LJKT * 60 * 60 * TT.INSTANTANEOUSQ, 0) PSL,
          -- ROUND(TT.LJKT * 60 * 60 * TT.DSDRFL, 0) PSL,--暂时用设计流量
           ROUND(TT.LJKT * TT.KJRL, 3) HDL,
           ROWNUM
      FROM (SELECT b.STCD,
                   TRIM(B.STNM)STNM,
                   b.areacd AREACD,
                   b.cacd CACD,
                   V.DSINCP*1000 ||'/'||V.UNNB||'台' AS ZJRL,
                   SL.KJNUM,
                   case when v.unnb>0 then ROUND(V.DSINCP / V.UNNB * SL.KJNUM,3) else null end KJRL,
                   C.LJKT,
                   C.DISTANCE,
                   R.INSTANTANEOUSQ,
                   V.DSDRFL,
                   ROWNUM ROWNUM_
              FROM
              ST_STBPRP_B B
              INNER JOIN (SELECT *
                                              FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                                              PLATFORM_STCD_TYPE))) ST1
                                    ON b.STCD = ST1.STCD
              LEFT JOIN
                --on 1=1
               (SELECT S.STCD,
                           ROUND(SUM(S.GTM - S.KTM) * 24, 3) AS LJKT,
                           ROUND(ABS((AVG(S.K_IN_WATER) + AVG(S.G_IN_WATER)) / 2 -
                                     (AVG(S.K_OUT_WATER) + AVG(S.G_OUT_WATER)) / 2),
                                 3) AS DISTANCE
                      FROM TABLE(CAST(TBOUT AS PLATFORM_BZ_RUNSTATE_TYPE)) S
                     WHERE S.STCD IS NOT NULL
                       AND S.KTM IS NOT NULL
                     GROUP BY S.STCD) C
              ON b.stcd =trim(c.stcd)
              LEFT JOIN (SELECT TS.STCD,
                               (TS.N1 + TS.N2 + TS.N3 + TS.N4 + TS.N5 +
                               TS.N6 + TS.N7 + TS.N8 + TS.N9 + TS.N10 +
                               TS.N11 + TS.N12) KJNUM
                          FROM (SELECT T.STCD,
                                       CASE
                                         WHEN AVG(N1) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N1,
                                       CASE
                                         WHEN AVG(N2) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N2,
                                       CASE
                                         WHEN AVG(N3) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N3,
                                       CASE
                                         WHEN AVG(N4) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N4,
                                       CASE
                                         WHEN AVG(N5) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N5,
                                       CASE
                                         WHEN AVG(N6) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N6,
                                       CASE
                                         WHEN AVG(N7) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N7,
                                       CASE
                                         WHEN AVG(N8) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N8,
                                       CASE
                                         WHEN AVG(N9) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N9,
                                       CASE
                                         WHEN AVG(N10) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N10,
                                       CASE
                                         WHEN AVG(N11) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N11,
                                       CASE
                                         WHEN AVG(N12) > 0 THEN
                                          1
                                         ELSE
                                          0
                                       END N12
                                  FROM dse_bz_runstate_r T
                                 INNER JOIN (SELECT *
                                              FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                                              PLATFORM_STCD_TYPE))) ST
                                    ON T.STCD = ST.STCD
                                 WHERE T.TM >=
                                       TO_DATE(STSTR, 'YYYY-MM-DD HH24:MI:SS')
                                   AND T.TM <=
                                       TO_DATE(ETSTR, 'YYYY-MM-DD HH24:MI:SS')
                                 GROUP BY T.STCD) TS) SL
                ON SL.STCD = trim(c.STCD)
              LEFT JOIN V_TB1502_MEIDSBI V
                ON V.stcd = trim(b.STCD)

              LEFT JOIN (SELECT T.STCD,
                               ROUND(AVG(T.INSTANTANEOUSQ), 3) INSTANTANEOUSQ
                          FROM DSE_BZ_RUNINFO_R T
                         INNER JOIN (SELECT *
                                      FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                                      PLATFORM_STCD_TYPE))) K
                            ON T.STCD = K.STCD
                         WHERE T.TM >
                               TO_DATE(STSTR, 'YYYY-MM-DD HH24:MI:SS')
                           AND T.TM <=
                               TO_DATE(ETSTR, 'YYYY-MM-DD HH24:MI:SS')
                         GROUP BY T.STCD) R
                ON trim(b.STCD) = R.STCD
             ORDER BY C.STCD DESC) TT
     WHERE TT.ROWNUM_ > PAGEFROM
       AND TT.ROWNUM_ <= PAGETO+120;

end PLATFORM_BZ_DZYX_YXTJ;


/

