create view V_SZ_RUNSTATE_R as
select
/**
  *AUTHOR:CHENHX
  *CTEATEDATE:2013年7月12日18:00:46
  *DESCRIPTION:查询水闸最新开关闸时间
  **/
       ttt1.stcd,
       to_char(ttt1.tm,'YYYY-MM-DD HH24:MI:SS') as kztm,
       case when ttt1.tm>ttt2.tm then null
         else
       to_char(ttt2.tm,'YYYY-MM-DD HH24:MI:SS') end as gztm
       from (select tt1.*
            from (select
                    t.stcd,
                    t.tm,
                    t.state,
                    row_number()over(partition by t.stcd order by tm desc)rown
                    from DSE_SZ_RUNSTATE_R t
                    where t.state = '1')tt1 where tt1.rown = 1)ttt1
                    full join
                    (select tt2.* from
                    (select t.stcd,t.tm,t.state,
                    row_number()over(partition by t.stcd order by tm desc)rown from DSE_SZ_RUNSTATE_R t
                    where t.state = '0')tt2 where tt2.rown = 1)ttt2
                    on ttt1.stcd = ttt2.stcd


/

