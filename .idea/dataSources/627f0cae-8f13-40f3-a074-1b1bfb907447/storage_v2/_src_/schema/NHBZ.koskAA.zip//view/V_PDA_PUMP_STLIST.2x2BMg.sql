create view V_PDA_PUMP_STLIST as
select AA.STCD,
       AA.STNM,
       AA.TM,
       AA.LGTD,
       AA.LTTD,
       AA.STAREA,
       getAdnm(AA.ADDVCD) STPQ,
       AA.STHDAY,
       case when AA.isOpen=0 then 1 else 0 end STINDEX,
       AA.STLIST || '|关联闸门ID:' || re.szstcd || '|闸门状态:' ||
       FUNC_ZM_JZZT(re.szstcd) STLIST,
       AA.NSW ORDER1,
       AA.WSW ORDER2
  from (SELECT A1.STCD,
               A1.STNM,
               nvl(B.TM, sysdate) as TM,
               NVL(A1.LGTD, 0) AS LGTD,
               NVL(A1.LTTD, 0) AS LTTD,
               A1.STAREA,
               A1.STPQ,
               A1.ADDVCD,
               '3' as STHDAY,
               case when B.STLIST is null then
                   getXqName() ||
                   '|内水位:未上报|-|外水位:未上报|-|状态:|机组台数:|机组状态:|A相电压(KV):|B相电压(KV):|C相电压(KV):|A相电流(A):|B相电流(A):|C相电流(A):|功率(KW):|故障:1:|装机容量(KW):|设计流量(m3/s): ' else B.STLIST || '|装机容量:' ||tb.dsincp ||  '|设计流量(m3/s):' || tb.dsdrfl end as STLIST,
               A1.STINDEX,
               B.NSW,
               B.WSW,
               c.isOpen
          FROM (SELECT A.*
                  FROM ST_STBPRP_B A
                 WHERE A.STAREA = getXqName()
                   AND A.STTP = 'DP') A1
         inner JOIN (select B1.STCD,
                           B1.TM,
                           case when (sysdate - B1.tm) * 24 > 12 or
                                    B1.tm is null then 0 else B1.NSW END NSW,
                           case when (sysdate - B1.tm) * 24 > 12 or
                                    B1.tm is null then 0 else B1.WSW END WSW,
                           case
                               when (sysdate - B1.tm) * 24 > 12 or
                                    B1.tm is null then
                                null
                               else
                                getXqName() || '|内水位(m):' ||
                                to_char(B1.NSW, 'fm99990.00') || '|-|外水位(m):' ||
                                nvl(to_char(B1.WSW, 'fm99990.00'), '-') ||
                                '|-|' || '状态:' || case
                                    when (to_number(sum(decode(AIRCREWNM,
                                                               '1#',
                                                               AIRCREWSTATE,
                                                               0))) +
                                         to_number(sum(decode(AIRCREWNM,
                                                               '2#',
                                                               AIRCREWSTATE,
                                                               0))) +
                                         to_number(sum(decode(AIRCREWNM,
                                                               '3#',
                                                               AIRCREWSTATE,
                                                               0))) +
                                         to_number(sum(decode(AIRCREWNM,
                                                               '4#',
                                                               AIRCREWSTATE,
                                                               0))) +
                                         to_number(sum(decode(AIRCREWNM,
                                                               '5#',
                                                               AIRCREWSTATE,
                                                               0))) +
                                         to_number(sum(decode(AIRCREWNM,
                                                               '6#',
                                                               AIRCREWSTATE,
                                                               0))) +
                                         to_number(sum(decode(AIRCREWNM,
                                                               '7#',
                                                               AIRCREWSTATE,
                                                               0))) +
                                         to_number(sum(decode(AIRCREWNM,
                                                               '8#',
                                                               AIRCREWSTATE,
                                                               0))) +
                                         to_number(sum(decode(AIRCREWNM,
                                                               '9#',
                                                               AIRCREWSTATE,
                                                               0)))) > 0 then
                                     1
                                    else
                                     0
                                end || '|机组台数:' ||
                                (select count(*)
                                   from DSE_BZ_RUNINFO_REAL
                                  where stcd = b1.stcd
                                  group by stcd) || '|机组状态:' ||
                                sum(decode(AIRCREWNM, '1#', AIRCREWSTATE, '')) || ':' ||
                                sum(decode(AIRCREWNM, '2#', AIRCREWSTATE, '')) || ':' ||
                                sum(decode(AIRCREWNM, '3#', AIRCREWSTATE, '')) || ':' ||
                                sum(decode(AIRCREWNM, '4#', AIRCREWSTATE, '')) || ':' ||
                                sum(decode(AIRCREWNM, '5#', AIRCREWSTATE, '')) || ':' ||
                                sum(decode(AIRCREWNM, '6#', AIRCREWSTATE, '')) || ':' ||
                                sum(decode(AIRCREWNM, '7#', AIRCREWSTATE, '')) || ':' ||
                                sum(decode(AIRCREWNM, '8#', AIRCREWSTATE, '')) || ':' ||
                                sum(decode(AIRCREWNM, '9#', AIRCREWSTATE, '')) ||
                                '|A相电压(KV):' ||

                                sum(decode(AIRCREWNM, '1#', VOLTAGEA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '2#', VOLTAGEA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '3#', VOLTAGEA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '4#', VOLTAGEA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '5#', VOLTAGEA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '6#', VOLTAGEA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '7#', VOLTAGEA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '8#', VOLTAGEA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '9#', VOLTAGEA, '')) ||
                                '|B相电压(KV):' ||

                                sum(decode(AIRCREWNM, '1#', VOLTAGEB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '2#', VOLTAGEB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '3#', VOLTAGEB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '4#', VOLTAGEB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '5#', VOLTAGEB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '6#', VOLTAGEB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '7#', VOLTAGEB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '8#', VOLTAGEB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '9#', VOLTAGEB, ''))

                                || '|C相电压(KV):' ||

                                sum(decode(AIRCREWNM, '1#', VOLTAGEC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '2#', VOLTAGEC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '3#', VOLTAGEC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '4#', VOLTAGEC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '5#', VOLTAGEC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '6#', VOLTAGEC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '7#', VOLTAGEC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '8#', VOLTAGEC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '9#', VOLTAGEC, ''))

                                || '|A相电流(A):' ||

                                sum(decode(AIRCREWNM, '1#', ECA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '2#', ECA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '3#', ECA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '4#', ECA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '5#', ECA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '6#', ECA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '7#', ECA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '8#', ECA, '')) || ':' ||
                                sum(decode(AIRCREWNM, '9#', ECA, '')) ||
                                '|B相电流(A):' ||

                                sum(decode(AIRCREWNM, '1#', ECB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '2#', ECB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '3#', ECB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '4#', ECB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '5#', ECB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '6#', ECB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '7#', ECB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '8#', ECB, '')) || ':' ||
                                sum(decode(AIRCREWNM, '9#', ECB, '')) ||
                                '|C相电流(A):' ||

                                sum(decode(AIRCREWNM, '1#', ECC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '2#', ECC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '3#', ECC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '4#', ECC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '5#', ECC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '6#', ECC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '7#', ECC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '8#', ECC, '')) || ':' ||
                                sum(decode(AIRCREWNM, '9#', ECC, '')) ||
                                '|功率(KW):' || B1.POWERACTIVE || '|故障:0'
                           end as stlist

                      from DSE_BZ_RUNINFO_REAL B1
                     group by B1.STCD, B1.TM, B1.NSW, B1.WSW, B1.POWERACTIVE) B
            ON A1.STCD = B.STCD
            left join (select stcd,sum(aircrewstate) isOpen from DSE_BZ_RUNINFO_REAL group by stcd) c on a1.stcd=c.stcd
              left join TB1502_MEIDSBI_044 tb
            on A1.stcd = tb.ennmcd ) AA
  left join dse_bzsz_remark re
    on AA.stcd = re.bzstcd
 order by aa.tm desc


/

