create function      fun_split
(
   --字符串
   p_list varchar2,
   --分割符
   p_sep varchar2 := ','
   --返回类型
)  return type_split pipelined


/**
功能：传入一个字符传，然后使用某个分隔符分割，返回一个结果集
如
select * from table(fun_split('a,b,c',','));
*/
 is

   l_idx  pls_integer;

   v_list  varchar2(32767) := p_list;

begin

   loop

      l_idx := instr(v_list,p_sep);

      if l_idx > 0 then

          pipe row(substr(v_list,1,l_idx-1));

          v_list := substr(v_list,l_idx+length(p_sep));

      else

          pipe row(v_list);

          exit;

      end if;

   end loop;

   return;

end fun_split;


/

