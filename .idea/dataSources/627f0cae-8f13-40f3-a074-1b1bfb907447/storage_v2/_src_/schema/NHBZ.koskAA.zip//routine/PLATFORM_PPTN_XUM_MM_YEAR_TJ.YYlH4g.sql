create procedure      PLATFORM_PPTN_XUM_MM_YEAR_TJ(
p_tm date
)
 is

 --旬，月，年 降雨量统计  zouwei
   v_mm int;
   v_day int;
   v_hour int;--分钟24小时格式

   v_tm date;
   XUN_8_START_TIME date;
	 XUN_8_END_TIME date;

   M_8_START_TIME date; --月统计开始时间
	 M_8_END_TIME date; ----月统计结束时间

   YEAR_8_START_TIME date; --年统计开始时间
	 YEAR_8_END_TIME date; ----年统计结束时间
begin
     if p_tm is not null then
        begin
             v_tm:=p_tm;
        end;
     else
         begin
             v_tm:=sysdate;
         end;
     end if;
    -- v_tm:=sysdate;
     v_mm:=to_number(to_char(v_tm,'mm'));
     v_day:=to_number(to_char(v_tm,'dd'));
     v_hour:=to_number(to_char(v_tm,'hh24'));



    --上旬
	if (v_day >1 and v_day <11) or(v_day=1 and  v_hour >8)or  (v_day =11 and v_hour <=8) then
		begin
        XUN_8_START_TIME :=TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
		   	XUN_8_END_TIME := TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-11 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
		end;

	--中旬
	elsif (v_day >11 and v_day <21 ) or  (v_day =11 and v_hour > 8) or (v_day =21 and v_hour <= 8) then
		begin
		    XUN_8_START_TIME :=TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-11 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
		   	XUN_8_END_TIME := TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-21 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
		end;
	--下旬
	elsif (v_day >21 and v_day <31 ) or (v_day =21 and v_hour > 8) or(v_day =31 and v_hour <=8) then
		begin
        XUN_8_START_TIME :=TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-21 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
		   	XUN_8_END_TIME :=add_months(TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss'),1) ;
		end;
	--下旬
	elsif v_day =1 and 	v_hour <=8 then
		begin
		   XUN_8_START_TIME:=add_months(TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-21 08:00:00', 'yyyy-mm-dd hh24:mi:ss'),-1) ;
       XUN_8_END_TIME :=TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
		end;
  end if;


  if v_day >1 then
		begin
		    M_8_START_TIME:=TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss');
        M_8_END_TIME:=add_months(TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss'),1 );
		end;
	else
		begin
			if v_hour <=8 then --0-7 计算上一个月的1日
				begin
           M_8_END_TIME:=TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss');
           M_8_START_TIME:=add_months(M_8_END_TIME,-1);
				end;
			else
				begin
           M_8_START_TIME:=TO_DATE(TO_CHAR(v_tm, 'YYYY-MM') || '-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss');
           M_8_END_TIME:=add_months(M_8_START_TIME,1);
				end;
      end if;
		end;
  end if;
  --年统计时间
  if v_mm>1 or (v_mm=1 and v_day>1) or (v_mm=1 and v_day=1 and v_hour<>8) then
		begin
		   YEAR_8_START_TIME :=TO_DATE(TO_CHAR(v_tm, 'YYYY') || '-01-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss');
		   YEAR_8_END_TIME:=add_months(YEAR_8_START_TIME,12);
		end;
	elsif v_mm=1 and v_day=1 and v_hour=8 then
		begin
       YEAR_8_END_TIME :=TO_DATE(TO_CHAR(v_tm, 'YYYY') || '-01-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss');
		   YEAR_8_START_TIME:=add_months(YEAR_8_START_TIME,-12);
		end;
  end if;


 declare V_STCD char(8);
	 V_ACCP number(6,1); --累计降水量
	 V_TJSTATUS number(6,1); --统计标识
	 V_DAYDRP number(6,1); --统计旬累计雨量
	 V_STCD_TJ char(8); --是否已经存在对于记录判断
   begin
       for CURSOR_PPTN_REAL in (SELECT r.STCD from dse_st_pptn_real r inner join st_stbprp_b st on r.stcd=st.stcd and st.usfl='1') loop
        BEGIN

              V_STCD:=CURSOR_PPTN_REAL.STCD;
              if v_day=1 or  v_day=11 or  v_day=21 then
              --统计旬累计降雨量 satrt ---
              begin
                   select STCD,ACCP,TJSTATUS into V_STCD_TJ,V_ACCP,V_TJSTATUS  from DSE_ST_PSTAT_R where STTDRCD='4' and STCD=V_STCD and IDTM =XUN_8_END_TIME;
				           if V_TJSTATUS=1 then --系统自动统计值 可以修改
          							begin
          								 select sum(drp) into V_DAYDRP from dse_st_pptn_r where stcd=V_STCD and tm >XUN_8_START_TIME and tm <=XUN_8_END_TIME ;
          								 if V_DAYDRP is null then
          									  begin
          										   V_DAYDRP:=0;
          									  end;
                           end if;

          								 if 	V_ACCP<>V_DAYDRP then
          									 begin
          										  update 	DSE_ST_PSTAT_R set accp=V_DAYDRP  where STTDRCD='4' and STCD=V_STCD and IDTM =XUN_8_END_TIME;
          									 end;
                           end if;

          							end;
                    end if;
                   exception
                    when NO_DATA_FOUND then
                      select sum(drp) into V_DAYDRP from dse_st_pptn_r where stcd=V_STCD and tm >XUN_8_START_TIME and tm <=XUN_8_END_TIME ;
          						if 	V_DAYDRP is null then
          							begin
          								 V_DAYDRP:=0;
          							end;
                      end if;
          					  insert into DSE_ST_PSTAT_R(stcd,idtm,sttdrcd,accp,tjstatus)values(V_STCD,XUN_8_END_TIME,'4',V_DAYDRP,1);


             end;

             end if;
        --统计旬累计降雨量 END ---

				--统计月累计降雨 start--
         if v_day=1 then
              begin
                    V_STCD_TJ:=null;
                    V_ACCP:=null;
                    V_TJSTATUS:=null;
                    V_DAYDRP:=null;

                    select STCD,ACCP,TJSTATUS into V_STCD_TJ,V_ACCP,V_TJSTATUS  from DSE_ST_PSTAT_R where STTDRCD='5' and STCD=V_STCD and IDTM =M_8_END_TIME;
                    if V_TJSTATUS=1 then --系统自动统计值 可以修改
          							begin
          								 select sum(drp) into V_DAYDRP from dse_st_pptn_r where stcd=V_STCD and tm >M_8_START_TIME and tm <=M_8_END_TIME ;
          								 if V_DAYDRP is null then
          									  begin
          										   V_DAYDRP:=0;
          									  end;
                           end if;

          								 if 	V_ACCP<>V_DAYDRP then
          									 begin
          										  update 	DSE_ST_PSTAT_R set accp=V_DAYDRP  where STTDRCD='5' and STCD=V_STCD and IDTM =M_8_END_TIME;
          									 end;
                           end if;

          							end;
                    end if;
                   exception
                    when NO_DATA_FOUND then
                      select sum(drp) into V_DAYDRP from dse_st_pptn_r where stcd=V_STCD and tm >M_8_START_TIME and tm <=M_8_END_TIME ;
          						if 	V_DAYDRP is null then
          							begin
          								 V_DAYDRP:=0;
          							end;
                      end if;
          					  insert into DSE_ST_PSTAT_R(stcd,idtm,sttdrcd,accp,tjstatus)values(V_STCD,M_8_END_TIME,'5',V_DAYDRP,1);


              end;
           end if;

        --统计月累计降雨 end--

        --统计年累计降雨量 start--
            if v_day=1 and   v_mm=1  then
               begin
                  V_STCD_TJ:=null;
                  V_ACCP:=null;
                  V_TJSTATUS:=null;
                  V_DAYDRP:=null;

                  select STCD,ACCP,TJSTATUS into V_STCD_TJ,V_ACCP,V_TJSTATUS  from DSE_ST_PSTAT_R where STTDRCD='6' and STCD=V_STCD and IDTM =YEAR_8_END_TIME;
                  if V_TJSTATUS=1 then --系统自动统计值 可以修改
        							begin
        								 select sum(drp) into V_DAYDRP from dse_st_pptn_r where stcd=V_STCD and tm >YEAR_8_START_TIME and tm <=YEAR_8_END_TIME ;
        								 if V_DAYDRP is null then
        									  begin
        										   V_DAYDRP:=0;
        									  end;
                         end if;

        								 if V_ACCP<>V_DAYDRP then
        									 begin
        										  update 	DSE_ST_PSTAT_R set accp=V_DAYDRP  where STTDRCD='6' and STCD=V_STCD and IDTM =YEAR_8_END_TIME;
        									 end;
                         end if;

        							end;
                  end if;
                 exception
                  when NO_DATA_FOUND then
                    select sum(drp) into V_DAYDRP from dse_st_pptn_r where stcd=V_STCD and tm >YEAR_8_START_TIME and tm <=YEAR_8_END_TIME ;
        						if 	V_DAYDRP is null then
        							begin
        								 V_DAYDRP:=0;
        							end;
                    end if;
        					  insert into DSE_ST_PSTAT_R(stcd,idtm,sttdrcd,accp,tjstatus)values(V_STCD,YEAR_8_END_TIME,'6',V_DAYDRP,1);


            end;

          end if;

         --统计年累计降雨量 end--
          COMMIT;
          EXCEPTION
            WHEN OTHERS THEN
              ROLLBACK;
        END;
    END loop;

   end;


end PLATFORM_PPTN_XUM_MM_YEAR_TJ;


/

