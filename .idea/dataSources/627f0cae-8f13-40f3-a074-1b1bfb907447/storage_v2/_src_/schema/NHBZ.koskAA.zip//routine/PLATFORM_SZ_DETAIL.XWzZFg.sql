create PROCEDURE      PLATFORM_SZ_DETAIL(VSTCD VARCHAR,
                                               ST    VARCHAR,
                                               ET    VARCHAR,
                                               CURR1 OUT PLATFORM.CURSOR) IS
  VST DATE;
  VET DATE;
BEGIN
  VST := TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss');
  VET := TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss');

  --水闸
  OPEN CURR1 FOR
    SELECT TTT.*, ROWNUM
      FROM (SELECT TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(OUT_WATER, 2), '99999999990.99')) OUT_WATER,
                   TRIM(TO_CHAR(ROUND(IN_WATER, 2), '99999999990.99')) IN_WATER,
                   STATE,
                   --状态 1：开 0 关 2 故障
                   DECODE(STATE, '1', '开', '0', '关', '故障') STATENAME,
                   FUNC_NUMERIC(LL, 3) LL
              FROM DSE_SZ_RUNINFO_R
             WHERE TM >= VST
               AND TM <= VET
               AND STCD = VSTCD
             ORDER BY TM DESC) TTT;

END PLATFORM_SZ_DETAIL;


/

