create procedure      PLATFORM_PPTN_H_D_X_M_Y(
P_STCD varchar,
P_TM   date,
P_OLD_DRP number,
P_NEW_DRP number
) is

--统计小时 日 旬 月 年累计雨量  zouwei

OLD_DRP number(5,1);
NEW_DRP number(5,1);
--新增雨量与历史雨量的差
DRP_VAL numeric(6,1);

d_hour int;--小时24小时格式
d_min int;--分钟


CHK_STCD varchar(16);--判断是否存在测站
CHK_DRP  numeric(6,1);--存在的当前雨量
V_DRP   numeric(6,1);--更新的雨量值

TIME_H date;--小时 整时
TM_DAY date;-- 日时间

XUN_TIME DATE;--旬时间
XUN_TIME_1 DATE; --当前时间月的1日时间
XUN_TIME_11 DATE;--当前时间月的11日时间
XUN_TIME_21 DATE;--当前时间月的21日时间
XUN_TIME_NEXT_MONTH_1 DATE;--当前时间下月的1日时间

MONTH_TIME DATE;--月时间
MONTH_TIME_1 DATE;--当前时间当月时间
MONTH_TIME_NEXT_1 DATE;--当前时间下月时间

YEAR_TIME DATE;--年时间
YEAR_TIME_1 DATE;--当前时间年时间
YEAR_TIME_NEXT_1 DATE;--当前时间下一年时间

begin
  if P_STCD is null or P_TM is null  then
		return ;
  end if;
  OLD_DRP:=P_OLD_DRP;
  NEW_DRP:=P_NEW_DRP;
	if OLD_DRP is null then
		 OLD_DRP:=0;
  end if;
	if NEW_DRP is null then
		 NEW_DRP:=0;
  end if;

  DRP_VAL:=NEW_DRP-OLD_DRP;


	d_hour:=to_number(to_char(P_TM,'hh24'));
  d_min:=to_number(to_char(P_TM,'mi'));

	 --统计一小时累计降雨量 start--

	 if d_min=0 then--处理整时的时候
         TIME_H:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM-dd hh24') || ':00:00', 'yyyy-mm-dd hh24:mi:ss');
	 else  --整编小时
		     TIME_H:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM-dd hh24') || ':00:00', 'yyyy-mm-dd hh24:mi:ss')+1/24;
   end if;


    --判断小时表是否存在记录
	select max(stcd),nvl(max(drp),0) into CHK_STCD,CHK_DRP from DSE_ST_PPTN_H  where STCD =P_STCD and TM =TIME_H;

	V_DRP :=CHK_DRP+DRP_VAL;
	if V_DRP is null then
	    begin
			   V_DRP:=0;
	    end;
  end if;

	IF CHK_STCD is null then--当前记录不存在
		BEGIN --执行insert
  			INSERT INTO DSE_ST_PPTN_H(STCD,TM,DRP)
  		      	VALUES(P_STCD,TIME_H,V_DRP);
		END;
	ELSE
		BEGIN --执行更新
         UPDATE DSE_ST_PPTN_H SET DRP=V_DRP where STCD =P_STCD and TM =TIME_H;
		END ;
  end if;

 	 --统计一小时累计降雨量 end--


   --统计日累计降雨量 start --

   if (d_hour <=7) or ( d_hour=8 and d_min=0) then
	   begin
          TM_DAY:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM-DD')||' 08:00:00', 'yyyy-mm-dd hh24:mi:ss') ;
	   end;
	else --08点 到23点
	   begin
			    TM_DAY:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM-DD')||' 08:00:00', 'yyyy-mm-dd hh24:mi:ss')+1 ;
	   end;
   end if;

    CHK_STCD:=null;--判断是否存在测站
    CHK_DRP:=null;--存在的当前雨量
    V_DRP:=null;--更新的雨量值

   select max(stcd),nvl(max(accp),0) into CHK_STCD,CHK_DRP from Dse_St_Pstat_r  where  STTDRCD='1' and STCD =P_STCD and IDTM =TM_DAY;

	V_DRP :=CHK_DRP+DRP_VAL;
	if V_DRP is null then
	    begin
			   V_DRP:=0;
	    end;
  end if;

  IF CHK_STCD is null then--当前记录不存在
		BEGIN --执行insert
  			INSERT INTO Dse_St_Pstat_r(STCD,IDTM,STTDRCD,accp)
  		      	VALUES(P_STCD,TM_DAY,'1',V_DRP);
		END;
	ELSE
		BEGIN --执行更新
         UPDATE Dse_St_Pstat_r SET accp=V_DRP where  STTDRCD='1' and STCD =P_STCD and IDTM =TM_DAY;
		END ;
  end if;
   --统计日累计降雨量 end--

   --统计旬累计降雨量 start--

  XUN_TIME_1:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM')||'-01 8:00:00', 'yyyy-mm-dd hh24:mi:ss');
  XUN_TIME_11:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM')||'-11 8:00:00', 'yyyy-mm-dd hh24:mi:ss');
  XUN_TIME_21:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM')||'-21 8:00:00', 'yyyy-mm-dd hh24:mi:ss');
  XUN_TIME_NEXT_MONTH_1:=add_months(TO_DATE(TO_CHAR(P_TM, 'YYYY-MM') || '-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss'),1) ;

  if P_TM<= XUN_TIME_1 then
      XUN_TIME:=XUN_TIME_1;
  elsif  P_TM>XUN_TIME_1 and  P_TM<=XUN_TIME_11 then
      XUN_TIME:=XUN_TIME_11;
  elsif  P_TM>XUN_TIME_11 and  P_TM<=XUN_TIME_21 then
      XUN_TIME:=XUN_TIME_21;
  elsif  P_TM>XUN_TIME_21 and  P_TM<=XUN_TIME_NEXT_MONTH_1 then
      XUN_TIME:=XUN_TIME_NEXT_MONTH_1;
  end if;

   CHK_STCD:=null;--判断是否存在测站
   CHK_DRP:=null;--存在的当前雨量
   V_DRP:=null;--更新的雨量值

  select max(stcd),nvl(max(accp),0) into CHK_STCD,CHK_DRP from Dse_St_Pstat_r  where  STTDRCD='4' and STCD =P_STCD and IDTM =XUN_TIME;

	V_DRP :=CHK_DRP+DRP_VAL;
	if V_DRP is null then
	    begin
			   V_DRP:=0;
	    end;
  end if;

  IF CHK_STCD is null then--当前记录不存在
		BEGIN --执行insert
  			INSERT INTO Dse_St_Pstat_r(STCD,IDTM,STTDRCD,accp)
  		      	VALUES(P_STCD,XUN_TIME,'4',V_DRP);
		END;
	ELSE
		BEGIN --执行更新
         UPDATE Dse_St_Pstat_r SET accp=V_DRP where  STTDRCD='4' and STCD =P_STCD and IDTM =XUN_TIME;
		END ;
  end if;
  --统计旬累计降雨量 end--

  --统计月累计降雨量 start--
    MONTH_TIME_1:=TO_DATE(TO_CHAR(P_TM, 'YYYY-MM')||'-01 8:00:00', 'yyyy-mm-dd hh24:mi:ss');--当前时间当月时间
    MONTH_TIME_NEXT_1:=add_months(MONTH_TIME_1,1) ;

    IF P_TM<= MONTH_TIME_1 THEN
       MONTH_TIME:=MONTH_TIME_1;
    ELSIF P_TM>MONTH_TIME_1 AND P_TM<= MONTH_TIME_NEXT_1 THEN
       MONTH_TIME:=MONTH_TIME_NEXT_1;
    END IF;

   CHK_STCD:=null;--判断是否存在测站
   CHK_DRP:=null;--存在的当前雨量
   V_DRP:=null;--更新的雨量值

  select max(stcd),nvl(max(accp),0) into CHK_STCD,CHK_DRP from Dse_St_Pstat_r  where  STTDRCD='5' and STCD =P_STCD and IDTM =MONTH_TIME;

	V_DRP :=CHK_DRP+DRP_VAL;
	if V_DRP is null then
	    begin
			   V_DRP:=0;
	    end;
  end if;

  IF CHK_STCD is null then--当前记录不存在
		BEGIN --执行insert
  			INSERT INTO Dse_St_Pstat_r(STCD,IDTM,STTDRCD,accp)
  		      	VALUES(P_STCD,MONTH_TIME,'5',V_DRP);
		END;
	ELSE
		BEGIN --执行更新
         UPDATE Dse_St_Pstat_r SET accp=V_DRP where  STTDRCD='5' and STCD =P_STCD and IDTM =MONTH_TIME;
		END ;
  end if;
  --统计月累计降雨量 end--

  --统计年累计降雨量 start--
    YEAR_TIME_1:=TO_DATE(TO_CHAR(P_TM, 'YYYY')||'-01-01 8:00:00', 'yyyy-mm-dd hh24:mi:ss');--当前时间当年时间;
    YEAR_TIME_NEXT_1 :=add_months(YEAR_TIME_1,12);--当前时间下一年时间
    IF P_TM<= YEAR_TIME_1 THEN
       YEAR_TIME:=YEAR_TIME_1;
    ELSIF P_TM>YEAR_TIME_1 AND P_TM<= YEAR_TIME_NEXT_1 THEN
       YEAR_TIME:=YEAR_TIME_NEXT_1;
    END IF;


     CHK_STCD:=null;--判断是否存在测站
   CHK_DRP:=null;--存在的当前雨量
   V_DRP:=null;--更新的雨量值

  select max(stcd),nvl(max(accp),0) into CHK_STCD,CHK_DRP from Dse_St_Pstat_r  where  STTDRCD='6' and STCD =P_STCD and IDTM =YEAR_TIME;

	V_DRP :=CHK_DRP+DRP_VAL;
	if V_DRP is null then
	    begin
			   V_DRP:=0;
	    end;
  end if;

  IF CHK_STCD is null then--当前记录不存在
		BEGIN --执行insert
  			INSERT INTO Dse_St_Pstat_r(STCD,IDTM,STTDRCD,accp)
  		      	VALUES(P_STCD,YEAR_TIME,'6',V_DRP);
		END;
	ELSE
		BEGIN --执行更新
         UPDATE Dse_St_Pstat_r SET accp=V_DRP where  STTDRCD='6' and STCD =P_STCD and IDTM =YEAR_TIME;
		END ;
  end if;
  --统计年累计降雨量 end--



end PLATFORM_PPTN_H_D_X_M_Y;


/

