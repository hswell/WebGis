create procedure      PLATFORM_RIVER_ZQRL(STCDS    VARCHAR,
                                               PAGEFROM INT,
                                               PAGETO   INT,
                                               CURR1    OUT PLATFORM.CURSOR) is
begin

  OPEN CURR1 FOR
     SELECT * FROM (
      SELECT T1.stcd,to_char(T1.Bgtm,'yyyy-mm-dd HH24:MI:SS') Bgtm,T1.ptno,T1.z,T1.q,trim(T1.LNNM) LNNM,to_char(T1.moditime,'yyyy-mm-dd HH24:MI') moditime ,
      trim(T1.COMMENTS) COMMENTS,trim(T2.STNM) STNM,ROW_NUMBER() OVER(ORDER BY T1.STCD desc) AS ROWNUM_  FROM ST_ZQRL_B T1
      INNER JOIN (SELECT * FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS PLATFORM_STCD_TYPE))) T4 ON T4.STCD =T1.STCD,ST_STBPRP_B T2
      WHERE T1.STCD=T2.STCD
     ) TT WHERE TT.ROWNUM_>PAGEFROM and TT.ROWNUM_ <= PAGETO ;

end PLATFORM_RIVER_ZQRL;


/

