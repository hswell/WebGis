create TYPE        "PLATFORM_SZ_RUNSTATE1"                                          as object
(
  -- Author  : DSE_TICHSTAR
  -- Created : 2013/7/17 11:29:09
  -- Purpose :
  -- Attributes
  STCD char(8),  --站码
  KTM DATE, --开闸时间
  K_IN_WATER numeric(8,3),--开闸内水位
  K_OUT_WATER numeric(8,3),--开闸外水位
  GTM DATE, --关闸时间
  G_IN_WATER numeric(8,3),--关闸内水位
  G_OUT_WATER numeric(8,3),--关闸外水位
  FLAG CHAR(1) -- 判断是否插入完成 1:完成，0:未完成
)
/

