create PROCEDURE      PLATFORM_BZ_DETAIL(VSTCD VARCHAR,
                                               ST    VARCHAR,
                                               ET    VARCHAR,
                                               CURR1 OUT PLATFORM.CURSOR,
                                               CURR2 OUT PLATFORM.CURSOR) IS
  VST DATE;
  VET DATE;
    VUNNB        number;
  VNUM         number;
BEGIN
  VST := TO_DATE(ST, 'yyyy-mm-dd hh24:mi:ss');
  VET := TO_DATE(ET, 'yyyy-mm-dd hh24:mi:ss');

  OPEN CURR1 FOR
    SELECT TTT.*, ROWNUM
      FROM (SELECT DISTINCT TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
                            TRIM(TO_CHAR(ROUND(FOREBAYZ, 2),
                                         '99999999990.99')) FOREBAYZ,
                            -- TRIM(TO_CHAR(ROUND(OPZ, 2), '99999999990.99')) OPZ,
                            TRIM(TO_CHAR(ROUND(NSW, 2), '99999999990.99')) NSW,
                            TRIM(TO_CHAR(ROUND(WSW, 2), '99999999990.99')) WSW,
                            --STATE,
                            --状态 1：开 0 关 2 故障
                            DECODE(FUNC_BZ_BZZT(STCD, TM),
                                   '1',
                                   '开',
                                   '0',
                                   '关',
                                   '故障') BZSTATE
                           -- AIRCREWNM
            --FUNC_BZ_JZZT(STCD, TM) JZZT
            --  FUNC_NUMERIC(LL, 3) LL
              FROM DSE_BZ_RUNINFO_R
             WHERE TM >= VST
               AND TM <= VET
               AND STCD = VSTCD
             ORDER BY TM DESC) TTT;
  --jzList


    --LIUX 2014-10-27
  select count(UNNB) into VNUM  from tb1502_meidsbi_044 t where t.ennmcd = VSTCD;
  if(VNUM)>0 THEN
   SELECT T.UNNB INTO VUNNB FROM TB1502_MEIDSBI_044 T WHERE T.ENNMCD = VSTCD;
  END IF;

--海口泵站特殊处理
  IF VSTCD ='98765006' THEN
     OPEN CURR2 FOR
      SELECT VSTCD as STCD,
             TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
             t.N1 AS "排涝1#机组",
             t.N2 AS "排涝2#机组",
             t.N3 AS "引水1#机组",
             t.N4 AS "引水2#机组",
             t.N5 AS "机组5#",
             t.N6 AS "机组6#",
             t.N7 AS "机组7#",
             t.N8 AS "机组8#",
             t.N9 AS "机组9#",
             t.N10 AS "机组10#",
             t.N11 AS "机组11#",
             t.N12 AS "机组12#",
             VUNNB AS VUNNB
        FROM DSE_BZ_RUNSTATE_R T
       WHERE t.TM >= VST
         AND t.TM <= VET
         AND t.STCD = VSTCD
       ORDER BY TM;
     ELSE
     OPEN CURR2 FOR
     SELECT
             VSTCD as STCD,
             TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
             t.N1 AS "机组1#",
             t.N2 AS "机组2#",
             t.N3 AS "机组3#",
             t.N4 AS "机组4#",
             t.N5 AS "机组5#",
             t.N6 AS "机组6#",
             t.N7 AS "机组7#",
             t.N8 AS "机组8#",
             t.N9 AS "机组9#",
             t.N10 AS "机组10#",
             t.N11 AS "机组11#",
             t.N12 AS "机组12#",
             VUNNB AS VUNNB
        FROM DSE_BZ_RUNSTATE_R T
       WHERE t.TM >= VST
         AND t.TM <= VET
         AND t.STCD = VSTCD
       ORDER BY TM;
   end if;
END PLATFORM_BZ_DETAIL;


/

