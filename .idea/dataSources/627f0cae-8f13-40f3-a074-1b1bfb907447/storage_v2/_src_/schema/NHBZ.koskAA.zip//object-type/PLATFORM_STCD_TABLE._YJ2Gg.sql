create TYPE        "PLATFORM_STCD_TABLE"                                          AS OBJECT
(
  STCD VARCHAR(30),
  STDT NUMERIC(8, 0)
)
/

