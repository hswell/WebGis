create PROCEDURE      PLATFORM_SSJK_RIVER(VSTNM    VARCHAR,
                                                VADDVCD  VARCHAR,
                                                VQY      VARCHAR,
                                                VTYPE    INTEGER,
                                                ISWARING VARCHAR,
                                                VMAPTYPE VARCHAR,
                                                CURR     OUT PLATFORM.CURSOR) IS
  RED      VARCHAR(10);
  ORANGE   VARCHAR(10);
  NORMAL   VARCHAR(10);
  RANGE    NUMBER(5, 1);
BEGIN
  SELECT REDCOLOR, ORANGECOLOR, ORANGERANGE, NORMALCOLOR
    INTO RED, ORANGE, RANGE, NORMAL
    FROM DSE_WARNING_PARAM;
  --河道水文（水位）站测报的河道水情实时信息
  --ISWARING 用于判断是否报警，''所有，1报警，0非报警。
  OPEN CURR FOR
    SELECT *
      FROM (SELECT NVL(T2.STNM, T1.STCD) STNM,
                   T1.STCD,
                   'ZZ' STTP,
                   CASE
                     WHEN VMAPTYPE = '2' THEN
                      FUNC_GIS_LONMERCATOR(T2.LGTD)
                     ELSE
                      T2.LGTD
                   END LGTD,
                   CASE
                     WHEN VMAPTYPE = '2' THEN
                      FUNC_GIS_LATMERCATOR(T2.LTTD)
                     ELSE
                      T2.LTTD
                   END LTTD,
                   T4.MAXSCALE,
                   T4.MINSCALE,
                   T4.SHOWLABELSCALE,
                   T4.VIFL,
                   TO_CHAR(T1.TM, 'yyyy-mm-dd hh24:mi') TM,
                   TRIM(TO_CHAR(ROUND(T1.Z, 2), '99999999990.99')) Z,
                   TRIM(TO_CHAR(ROUND(T3.WRZ, 2), '99999999990.99')) WRZ,
                   FUNC_NUMERIC(T1.Q, 3) Q,
                   CASE
                     WHEN T1.Z IS NULL OR T3.WRZ IS NULL THEN
                      NULL
                     WHEN T1.Z >= T3.WRZ OR T3.WRZ - T1.Z <= RANGE THEN
                      TRIM(TO_CHAR(ROUND(T1.Z - T3.WRZ, 2), '99999999990.99'))
                     ELSE
                      NULL
                   END CWRZ,
                   CASE
                     WHEN T1.Z IS NULL OR T3.WRZ IS NULL THEN
                      NORMAL
                     WHEN T1.Z >= T3.WRZ THEN
                      RED
                     WHEN T3.WRZ - T1.Z <= RANGE THEN
                      ORANGE
                     ELSE
                      NORMAL
                   END COLOR,
                   CASE
                     WHEN T1.Z IS NULL OR T3.WRZ IS NULL THEN
                      0
                     WHEN T1.Z >= T3.WRZ THEN
                      1
                     WHEN T3.WRZ - T1.Z <= RANGE THEN
                      2
                     ELSE
                      0
                   END WARNING,
                   CASE
                   -- WHEN T1.Z >= T3.WRZ OR (T3.WRZ - T1.Z) <= RANGE THEN
                     WHEN T1.Z >= T3.WRZ THEN
                      '1'
                     ELSE
                      '0'
                   END WARNINGBJ,
                   --WRZ为空时，按rz排序
                   -- ORDER BY NVL(T1.Z - T3.WRZ, Z) DESC;
                   CASE
                     WHEN T1.Z >= T3.WRZ OR T3.WRZ - T1.Z <= RANGE THEN
                      Z - T3.WRZ + 9999999
                     ELSE
                      T1.Z
                   END ORDERBYINDEX,
                   --是否测了雨量
                   DECODE(T5.STCD, NULL, 0, 1) YQ,
                   DECODE(T1.WPTN, '4', '↓', '5', '↑', '6', '→', '--') WPTN,
                   TO_CHAR(getadnm(T2.ADDVCD)) ADNM
              FROM DSE_ST_RIVER_REAL T1
            -- LEFT JOIN ST_STBPRP_B T2 ON T1.STCD = T2.STCD
              LEFT JOIN ST_RVFCCH_B T3 ON T1.STCD = T3.STCD
              LEFT JOIN DSE_ST_LABEL_SET T4 ON RTRIM(T4.STCD) =
                                               RTRIM(T1.STCD)
                                           AND T4.LAYERID = 1
              LEFT JOIN DSE_ST_PPTN_REAL T5 ON T1.STCD = T5.STCD,
             ST_STBPRP_B T2
             WHERE T1.STCD = T2.STCD
               and t2.usfl = '1'
               and (VSTNM IS NULL OR T2.STNM LIKE '%' || VSTNM || '%')
               AND (VADDVCD IS NULL OR T2.ADDVCD LIKE VADDVCD || '%')
               AND (T2.RVNM LIKE '%' || CASE VTYPE WHEN 1 THEN NVL(VQY, '') ELSE ''
                    END || '%' OR T2.HNNM LIKE '%' || CASE VTYPE WHEN 2 THEN
                    NVL(VQY, '') ELSE ''
                    END || '%' OR T2.BSNM LIKE '%' || CASE VTYPE WHEN 3 THEN
                    NVL(VQY, '') ELSE '' END || '%' OR '10' = '1' || CASE WHEN
                    VQY IS NULL THEN '0' ELSE '' END))
     WHERE WARNINGBJ LIKE '%' || ISWARING || '%'

     ORDER BY ORDERBYINDEX DESC;
END PLATFORM_SSJK_RIVER;


/

