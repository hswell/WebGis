create trigger TRIG_DSE_BZ_RUNINFO_R_ORIG
    before insert or update
    on DSE_BZ_RUNINFO_R_ORIG
    for each row
declare
  N1      VARCHAR(1); --1#机组状态
  N2      VARCHAR(1); --2#机组状态
  N3      VARCHAR(1); --3#机组状态
  N4      VARCHAR(1); --4#机组状态
  N5      VARCHAR(1); --5#机组状态
  N6      VARCHAR(1); --6#机组状态
  N7      VARCHAR(1); --7#机组状态
  N8      VARCHAR(1); --8#机组状态
  N9      VARCHAR(1); --9#机组状态
  N10     VARCHAR(1); --10#机组状态
  N11     VARCHAR(1); --11#机组状态
  N12     VARCHAR(1); --12#机组状态
  STCD    CHAR(8); --测站编号
  JZNUM   NUMBER(2); --机组个数
  JZSTATE VARCHAR(1); --机组状态
  ZTSNSW  NUMBER(8,2); --猪头山3站内水位
  ZTSWSW  NUMBER(8,2); --猪头山3站外水位
begin
  SELECT Q.STCD,
         Q.N1,
         Q.N2,
         Q.N3,
         Q.N4,
         Q.N5,
         Q.N6,
         Q.N7,
         Q.N8,
         Q.N9,
         Q.N10,
         Q.N11,
         Q.N12
    INTO STCD, N1, N2, N3, N4, N5, N6, N7, N8, N9, N10, N11, N12
    FROM (SELECT T.STCD,
                 NVL(S1.N1, '0') N1,
                 NVL(S1.N2, '0') N2,
                 NVL(S1.N3, '0') N3,
                 NVL(S1.N4, '0') N4,
                 NVL(S1.N5, '0') N5,
                 NVL(S1.N6, '0') N6,
                 NVL(S1.N7, '0') N7,
                 NVL(S1.N8, '0') N8,
                 NVL(S1.N9, '0') N9,
                 NVL(S1.N10, '0') N10,
                 NVL(S1.N11, '0') N11,
                 NVL(S1.N12, '0') N12,
                 ROW_NUMBER() OVER(ORDER BY S1.TM DESC) RN
            FROM ST_STBPRP_B T
            LEFT JOIN (SELECT *
                        FROM DSE_BZ_RUNSTATE_R S
                       WHERE S.TM <= :NEW.TM) S1
              ON T.STCD = S1.STCD
           WHERE T.STCD = :NEW.STCD) Q
   WHERE Q.RN = 1;

  SELECT COUNT(B.ENNMCD)
    INTO JZNUM
    FROM DSE_BZ_PUMB B, v_tb1502_meidsbi V
   WHERE B.ENNMCD = V.ENNMCD
     AND V.STCD = :NEW.STCD;

  JZSTATE := '0';
  DECLARE
    I INT := 1;

  BEGIN
    WHILE I <= JZNUM LOOP
      SELECT CASE I
               WHEN 1 THEN
                N1
               WHEN 2 THEN
                N2
               WHEN 3 THEN
                N3
               WHEN 4 THEN
                N4
               WHEN 5 THEN
                N5
               WHEN 6 THEN
                N6
               WHEN 7 THEN
                N7
               WHEN 8 THEN
                N8
               WHEN 9 THEN
                N9
               WHEN 10 THEN
                N10
               WHEN 11 THEN
                N11
               WHEN 12 THEN
                N12
               ELSE
                '0'
             END
        INTO JZSTATE
        FROM DUAL;
      --猪头山3站水位取猪头山1站的水位
      
      if(:NEW.STCD ='98765043') THEN 
          SELECT NSW INTO ZTSNSW  FROM (SELECT NSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98751461')  WHERE ROWNUM = 1;
          SELECT WSW INTO ZTSWSW  FROM (SELECT WSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98751461')  WHERE ROWNUM = 1;
          IF(ZTSNSW IS NOT NULL AND ZTSWSW IS NOT NULL) THEN 
            :NEW.NSW := ZTSNSW;
            :NEW.WSW := ZTSWSW;
          END IF;
      END IF;
      --上围旧站取新站的水位
      if(:NEW.STCD ='98765189') THEN 
          SELECT NSW INTO ZTSNSW  FROM (SELECT NSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98765072')  WHERE ROWNUM = 1;
          SELECT WSW INTO ZTSWSW  FROM (SELECT WSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98765072')  WHERE ROWNUM = 1;
          IF(ZTSNSW IS NOT NULL AND ZTSWSW IS NOT NULL) THEN 
            :NEW.NSW := ZTSNSW;
            :NEW.WSW := ZTSWSW;
          END IF;
      END IF;
      
        --大圳埔排站取东莞生态园大圳埔的水位
      if(:NEW.STCD ='98765012') THEN 
          SELECT NSW INTO ZTSNSW  FROM (SELECT NSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98765055')  WHERE ROWNUM = 1;
          SELECT WSW INTO ZTSWSW  FROM (SELECT WSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98765055')  WHERE ROWNUM = 1;
          IF(ZTSNSW IS NOT NULL AND ZTSWSW IS NOT NULL) THEN 
            :NEW.NSW := ZTSNSW;
            :NEW.WSW := ZTSWSW;
          END IF;
      END IF;
      
        --屋厦桥新站取屋厦桥旧站的水位
      if(:NEW.STCD ='98765143') THEN 
          SELECT NSW INTO ZTSNSW  FROM (SELECT NSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98765077')  WHERE ROWNUM = 1;
         -- SELECT WSW INTO ZTSWSW  FROM (SELECT WSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98765077')  WHERE ROWNUM = 1;
          IF(ZTSNSW IS NOT NULL ) THEN 
            :NEW.NSW := ZTSNSW;
            :NEW.WSW := null;
          END IF;
      END IF;
      
         --东引樟村泵站取下桥板桥的水位
      if(:NEW.STCD ='98765003') THEN 
          SELECT NSW INTO ZTSNSW  FROM (SELECT NSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98765040')  WHERE ROWNUM = 1;
          SELECT WSW INTO ZTSWSW  FROM (SELECT WSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98765040')  WHERE ROWNUM = 1;
          IF(ZTSNSW IS NOT NULL ) THEN 
            :NEW.NSW := ZTSNSW;
            :NEW.WSW := null;
          END IF;
      END IF;
      
        --松木湖大道取消外江水位
      if(:NEW.STCD ='98765211') THEN 
            :NEW.WSW := null;
      END IF;
      
        --松山湖上屯取消外江水位
      if(:NEW.STCD ='98765206') THEN 
            :NEW.WSW := null;
      END IF;
      
       --鸡嘴取消外江水位
      if(:NEW.STCD ='98765147') THEN 
            :NEW.WSW := null;
      END IF;
       --上围新站、旧站取消外江水位
      if(:NEW.STCD ='98765072' or :NEW.STCD ='98765189') THEN 
            :NEW.WSW := null;
      END IF;
         --东江大道万江雨水楼取消外江水位
      if(:NEW.STCD ='98765061') THEN 
            :NEW.WSW := null;
      END IF;
      ---end
      if(:NEW.WSW = 25.3 or :NEW.WSW = 27.3 ) THEN
         :NEW.WSW := null;
      END IF;

      if(:NEW.NSW = 25.3 or :NEW.NSW = 27.3) THEN
         :NEW.NSW := null;
      END IF;
      
      --5051,5052,5053 公用一个内外水位
      if(:NEW.STCD ='98765051' or :new.stcd = '98765053') THEN 
          SELECT NSW INTO ZTSNSW  FROM (SELECT NSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98765052')  WHERE ROWNUM = 1;
         IF(ZTSNSW IS NOT NULL ) THEN 
            :NEW.NSW := ZTSNSW;
          END IF;
      END IF;
      
      if(:NEW.STCD ='98765051' or :new.stcd = '98765052') THEN 
          SELECT WSW INTO ZTSWSW  FROM (SELECT WSW FROM DSE_BZ_RUNINFO_REAL WHERE STCD = '98765053')  WHERE ROWNUM = 1;
         IF(ZTSWSW IS NOT NULL ) THEN 
            :NEW.WSW := ZTSWSW;
          END IF;
      END IF;
      --end;
    
      INSERT INTO DSE_BZ_RUNINFO_R
        (STCD, TM, AIRCREWNM, PIPENM, AIRCREWSTATE, NSW, WSW)
      VALUES
        (:NEW.STCD, :NEW.TM, I || '#', '1#', JZSTATE, :NEW.NSW, :NEW.WSW);
      I := I + 1;

    END LOOP;
  END;

end TRIG_DSE_BZ_RUNINFO_R_ORIG;


/

