create TYPE        "PLATFORM_RIVER_RSVR_TABLE"                                          as object
(
  STCD char(8),  --站码
  TM   date,     --日期
  AVZ numeric(7,3), --河道水库站平均水位
  AVQ numeric(9,3),--河道站平均流量，水库站平均入库流量
  AVOTQ numeric(9,3),--水库站平均出库流量
  AVW numeric(9,3)--水库站平均库容
)
/

