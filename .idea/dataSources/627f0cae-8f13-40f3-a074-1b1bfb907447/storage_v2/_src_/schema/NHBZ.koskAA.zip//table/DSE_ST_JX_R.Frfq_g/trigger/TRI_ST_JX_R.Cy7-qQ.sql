create trigger TRI_ST_JX_R
    before insert or update
    on DSE_ST_JX_R
    for each row
BEGIN
 insert into dse_st_weather_r
   (stcd,
    tm,
    drphour,
    drpday,
    wd,
    wdhighhour,
    wdlowhour,
    wdhighday,
    wdlowday,
    wind2min,
    windr2min,
    wind10min,
    windr10min,
    wind10minh,
    windr10minh,
    windmaxh,
    windrmaxh,
    wind10minday,
    windr10minday,
    windmaxday,
    windrmaxday)
values
(:NEW.STCD,
 :NEW.TM,
 :NEW.DRP1H,
 :NEW.DRPDAY,
 :NEW.NOWTEMP,
 :NEW.MAX_TEMP_HOUR,
 :NEW.MIN_TEMP_HOUR,
 :NEW.MAX_TEMP_DAY,
 :NEW.MIN_TEMP_DAY,
 :NEW.ZMIFS,
 :NEW.ZMIFX,
 :NEW.TMIFS,
 :NEW.TMIFX,
 :NEW.TMIFS_HOUR,
 :NEW.TMIFX_HOUR,
 :NEW.MAX_XSFS_HOUR,
 :NEW.MAX_XSFX_HOUR,
 :NEW.TMIFS_DAY,
 :NEW.TMIFX_DAY,
 :NEW.MAX_XSFS_DAY,
 :NEW.MAX_XSFX_DAY);

END TRI_ST_JX_R;


/

