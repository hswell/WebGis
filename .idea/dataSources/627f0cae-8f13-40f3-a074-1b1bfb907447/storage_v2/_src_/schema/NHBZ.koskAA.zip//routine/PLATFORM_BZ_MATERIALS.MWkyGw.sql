create procedure      PLATFORM_BZ_MATERIALS(szcode  varchar,
                                             gcname   varchar,
                                             PAGEFROM  INT,
                                             PAGETO    INT,
                                             cursor1 OUT PLATFORM.CURSOR) is
begin
    open cursor1 for
       select t1.* from (
            select t.ennmcd,t.ennm,t.ogid,t.entyced,
                   decode(t.entyced,'A','河流','B','水库','C','水文测站/控制站','D','堤防(段)',
                        'E','海堤(段)','F','蓄滞(行)洪区','G','湖泊','H','圩垸','K','水闸','M','跨河工程','N','治河工程',
                        'P','穿堤建筑物','W','城市防洪','V','险点险段','J','泵站','Q','墒情监测站点','R','地下水监测站点','S','灌区') entycname,t.vlfl,t.atid,t.sdfl,t.rma,t.mdps,t.mddt
                 ,row_number() over(order by t.mddt) rn
             from TB0001_PRNMSR_044 t,TB1501_MEIDSCIN_044 t2
         where  t.ennmcd=t2.ennmcd
                and t.ennmcd like '%'||szcode||'%' and  t.ennm like '%'||gcname||'%'

       ) t1 where t1.rn >PAGEFROM and t1.rn <=PAGETO ;
end PLATFORM_BZ_MATERIALS;


/

