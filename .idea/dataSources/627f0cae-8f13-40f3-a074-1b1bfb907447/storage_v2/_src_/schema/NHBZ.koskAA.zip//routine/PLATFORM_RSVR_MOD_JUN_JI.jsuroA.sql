create procedure      PLATFORM_RSVR_MOD_JUN_JI
 is
 -- =============================================
-- Author:		zouwei
-- Create date: 2013-10-09
-- Description:	水库水位均值极值数据修复 三天之内的数据
-- =============================================
startTime date;
endTime  date;
start_qt date;

begin

    endTime:=to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss');

	  endTime:=endTime-1;
	  startTime:=endTime-3;

	 start_qt:=startTime;

	 WHILE start_qt <= endTime loop

			  platform_rsvr_jiz_tj(start_qt);

			  PLATFORM_rsvr_JUNZ_TJ(start_qt);

			  start_qt := start_qt+1;
		END loop;
end PLATFORM_RSVR_MOD_JUN_JI;


/

