create PROCEDURE      PRO_ST_STBPRP_B_INFO(
       CUR1 out platform.CURSOR,
       CUR2 out platform.CURSOR,
       CUR3 out platform.CURSOR,
       CUR4 out platForm.CURSOR,
       CUR5 out platForm.CURSOR
) IS

BEGIN
  --雨量站
  OPEN CUR1 FOR
  select st.STCD,rtrim(st.STNM)||'/'||rtrim(st.STCD)||'('||(select sc.name from SYS_DISTRICT sc where sc.ADCODE=st.ADDVCD)||')' STNM,rtrim(st.RVNM)RVNM,rtrim(st.HNNM)HNNM,rtrim(st.BSNM)BSNM,st.LGTD,st.LTTD,st.ADDVCD,st.ATCUNIT from
   DSE_ST_PPTN_REAL p inner join ST_STBPRP_B st on p.STCD=st.STCD
   where st.USFL='1';

  --河道站
   OPEN CUR2 FOR
  select st.STCD,rtrim(st.STNM)||'/'||rtrim(st.STCD)||'('||(select sc.name from SYS_DISTRICT sc where sc.ADCODE=st.ADDVCD)||')' STNM,rtrim(st.RVNM)RVNM,rtrim(st.HNNM)HNNM,rtrim(st.BSNM)BSNM,st.LGTD,st.LTTD,st.ADDVCD,st.ATCUNIT from
  ST_STBPRP_B st  where (st.STTP='ZZ' or st.STTP='ZQ' or st.STTP='ZP') and st.USFL='1';

  --水库站
   OPEN CUR3 FOR
  select st.STCD,rtrim(st.STNM)||'/'||rtrim(st.STCD)||'('||(select sc.name from SYS_DISTRICT sc where sc.ADCODE=st.ADDVCD)||')' STNM,rtrim(st.RVNM)RVNM,rtrim(st.HNNM)HNNM,rtrim(st.BSNM)BSNM,st.LGTD,st.LTTD,st.ADDVCD,st.ATCUNIT from
   ST_STBPRP_B st  where (st.STTP='RR'  or st.STTP='RP') and st.USFL='1';

 --泵站
  OPEN CUR4 FOR
  select st.STCD,rtrim(st.STNM)||'/'||rtrim(st.STCD)||'('||(select sc.name from SYS_DISTRICT sc where sc.ADCODE=st.ADDVCD)||')' STNM,rtrim(st.RVNM)RVNM,rtrim(st.HNNM)HNNM,rtrim(st.BSNM)BSNM,st.LGTD,st.LTTD,st.ADDVCD,st.ATCUNIT from
   ST_STBPRP_B st  where (st.STTP='DP'  or st.STTP='DP') and st.USFL='1';

   --水闸
  OPEN CUR5 FOR
  select st.STCD,rtrim(st.STNM)||'/'||rtrim(st.STCD)||'('||(select sc.name from SYS_DISTRICT sc where sc.ADCODE=st.ADDVCD)||')' STNM,rtrim(st.RVNM)RVNM,rtrim(st.HNNM)HNNM,rtrim(st.BSNM)BSNM,st.LGTD,st.LTTD,st.ADDVCD,st.ATCUNIT from
   ST_STBPRP_B st  where (st.STTP='DD'  or st.STTP='DD') and st.USFL='1';

END PRO_ST_STBPRP_B_INFO;


/

