create function      getAdcdPid(adcd  in varchar2) return varchar2
as
code  varchar2(15) ;
issj int ;
begin
       code:=rtrim(adcd);
  if (code is not null and length(code) >= 1 ) then
    while(length(code)>6 and substr(code,length(code)-2,length(code))='000') loop
         code:=substr(code,1,length(code)-3);
     end loop;
       while(length(code)<7 and substr(code,length(code)-1,length(code))='00') loop
         code:=substr(code,1,length(code)-2);
     end loop;

   end if;

   if(length(code) <=6) then
          select count(*) into issj  from  AD_CD_B   where  adcd =substr(code,1,4)+'00000000000';
          if(issj>0) then
               code:= substr(code,1,length(code)-2);
          else
                code:= -1;
            end if ;
  else
       code:= substr(code,1,length(code)-3);
    end if;



    if(code<>-1) then
          code:=replace(rpad(code,15),' ','0')   ;
      end if;


       select count(*) into issj  from  AD_CD_B   where  adcd =code;
          if(issj=0) then
           code:= -1;
            end if ;


  return code;
end getAdcdPid;


/

