create procedure      PLATFORM_BZ_SSJS_SSXX2(STCDS VARCHAR,
                                                   CURR  OUT PLATFORM.CURSOR,
                                                   CURR1 OUT PLATFORM.CURSOR,
                                                   CURR2 OUT PLATFORM.CURSOR) is
begin
  OPEN CURR FOR
    select t.stcd,
           to_char(t.tm, 'yyyy-mm-dd hh24:mi:ss') tm,
           t.aircrewnm || '机组' aircrewnm,
           t.aircrewstate,
           t.instantaneousq,
           t.wsw,
           t.nsw,
           p.power,
           p.waterpump_modal,
           p.d_runoff,
           p.d_raise,
           p.bzlx,
           p.djlx,
           p.elec_modal,
           to_char(maxw.tm, 'hh24:mi:ss') as wtm,
           maxw.wsw mwsw,
           to_char(maxn.tm, 'hh24:mi:ss') as ntm,
           maxn.nsw mnsw
      from DSE_BZ_PUMB p
      left join v_tb1502_meidsbi v
        on p.ENNMCD = v.stcd
      left join DSE_BZ_RUNINFO_REAL t
        on (v.stcd = T.STCD and t.aircrewnm = p.aircrewnm)
      left join (select *
                   from (select stcd, tm, wsw
                           from dse_bz_runinfo_r
                          where stcd = STCDS
                            and tm >= to_date(to_char(sysdate, 'yyyy-mm-dd') ||
                                              ' 00:00:00',
                                              'yyyy-mm-dd hh24:mi:ss')
                          order by wsw desc nulls last)
                  where rownum = 1) maxw
        on 1 = 1
      left join (select *
                   from (select stcd, tm, nsw
                           from dse_bz_runinfo_r
                          where stcd = STCDS
                            and tm >= to_date(to_char(sysdate, 'yyyy-mm-dd') ||
                                              ' 00:00:00',
                                              'yyyy-mm-dd hh24:mi:ss')
                          order by nsw desc nulls last)
                  where rownum = 1) maxn
        on 1 = 1
     where t.stcd = STCDS
     order by to_number(substr(t.aircrewnm, 0, instr(t.aircrewnm, '#') - 1));

  OPEN CURR1 FOR
    SELECT v.ENNMCD,
           v.INFNDT,
           v.DSINCP * 1000 DSINCP,
           v.ACINCP,
           v.UNNB,
           v.PMTP,
           v.DDFWLV,
           v.DDPWLV,
           v.PMPNMTEL,
           v.DSDRFL,
           v.IDDFWLV,
           v.IDDPWLV,
           v.DSIRDRFL
      FROM V_TB1502_MEIDSBI V
     WHERE V.stcd = STCDS;

/*  OPEN CURR2 FOR
    select b.STNM, to_char(t.TM, 'yyyy-mm-dd hh24:mi:ss') as TM, t.STATE
      FROM dse_sz_runstate_r t, St_Stbprp_b b
     WHERE t.stcd = b.stcd
       and T.STCD =
           (SELECT r.szstcd FROM DSE_BZSZ_REMARK r WHERE r.bzstcd = STCDS);
*/
  OPEN CURR2 FOR

    SELECT T.ZMNUM, R.N1 || R.N2 || R.N3 AS ZMSTATE,FUNC_BZ_JZZT(STCDS,NULL) AS BZSTATE
      FROM ST_STBPRP_B L
      LEFT JOIN DSE_BZSZ_REMARK B
      ON L.STCD = B.BZSTCD
     LEFT JOIN TB0901_SLCMIN_044 T
        ON B.SZSTCD = T.ENNMCD
      LEFT JOIN DSE_SZ_RUNINFO_REAL R
        ON B.SZSTCD = R.STCD
     WHERE L.STCD = STCDS;

end PLATFORM_BZ_SSJS_SSXX2;


/

