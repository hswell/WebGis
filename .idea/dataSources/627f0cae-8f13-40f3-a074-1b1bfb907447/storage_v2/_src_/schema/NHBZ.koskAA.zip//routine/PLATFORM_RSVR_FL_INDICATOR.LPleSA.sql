create PROCEDURE      PLATFORM_RSVR_FL_INDICATOR(STCDS    VARCHAR,
                                                       ST       VARCHAR,
                                                       ET       VARCHAR,
                                                       PAGEFROM INT,
                                                       PAGETO   INT,
                                                       CURSOR1  OUT PLATFORM.CURSOR) IS
BEGIN

  OPEN CURSOR1 FOR
    SELECT *
      FROM (SELECT T2.STCD,
                   T2.STNM,
                   T2.STLC,
                   T3.BGMD,
                   T3.EDMD,
                   T3.FSLTDZ,
                   T3.FSTP,
                   DECODE(T3.FSTP, '1', '主汛期', '2', '后汛期','3','过渡期','4','其它') FSTPNAME,
                   T3.FSLTDW,
                   T3.MODITIME,
                   ROW_NUMBER() OVER(ORDER BY T2.STCD) AS RN
              FROM  ST_STBPRP_B T2
             INNER JOIN (SELECT * FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS PLATFORM_STCD_TYPE))) T4
                         ON T4.STCD =T2.STCD,
             ST_RSVRFSR_B T3
             WHERE  T2.STCD = T3.STCD AND T2.STTP='RR'
               AND TO_NUMBER(T3.BGMD) >= TO_NUMBER(ST)
               AND TO_NUMBER(T3.EDMD) <= TO_NUMBER(ET)) T4
     WHERE T4.RN > PAGEFROM
       AND T4.RN <= PAGETO;

END PLATFORM_RSVR_FL_INDICATOR;


/

