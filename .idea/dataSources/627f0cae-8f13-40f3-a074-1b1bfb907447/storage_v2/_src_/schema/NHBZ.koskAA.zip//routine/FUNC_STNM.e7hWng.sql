create function      FUNC_STNM(vstcd in varchar2)  return varchar2
as
vstnm varchar2(30) ;

begin
     if(vstcd is not null and length(vstcd) >0) then
         select trim(stnm) into vstnm from  st_stbprp_b where stcd=vstcd and ROWNUM=1;
     end if;
     return vstnm;

end FUNC_STNM;


/

