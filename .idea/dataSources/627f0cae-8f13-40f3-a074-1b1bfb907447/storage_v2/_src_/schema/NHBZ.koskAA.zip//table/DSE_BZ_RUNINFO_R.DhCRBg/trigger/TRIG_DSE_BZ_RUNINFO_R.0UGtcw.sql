create trigger TRIG_DSE_BZ_RUNINFO_R
    before insert or update
    on DSE_BZ_RUNINFO_R
    for each row
DECLARE
  TEMPTIME DATE;
  YCXXTIME DATE; --预测信息最新记录时间
  NJQPSW   NUMBER(8,2);--泵站内江起排水位
  WPTN     VARCHAR(1) ;--内江水位水势(4:落,5:涨,6:平)
  NJYCYJZ  NUMBER(8,2);--内江预测警示值(米)
  ISWARN   VARCHAR(1) ;--是否预警(0:否,1:是)
  CYCYJ    NUMBER(8,2);--超预测预警值(米)
  O_NJSW   NUMBER(8,2);--最近一条内江水位值
  --liuxian
  ANGELVALUE varchar2(10); --叶片安装角度
  MODALVALUE varchar2(20); --机组型号
  PVALUE   NUMBER(8,2); --内外水位差 （扬程）
  QVALUE       NUMBER(8,2); --流量
    vnm int;
  vnm2 int;

  
BEGIN
  --更新实时表
  SELECT MAX(TM)
    INTO TEMPTIME
    FROM DSE_BZ_RUNINFO_REAL
   WHERE STCD = :NEW.STCD
     AND AIRCREWNM = :NEW.AIRCREWNM
     AND PIPENM = :NEW.PIPENM;
   
  -- 预测最新记录时间
  SELECT MAX(T.TM) INTO YCXXTIME FROM DSE_BZ_YCXX_B T WHERE STCD = :NEW.STCD;
  --起排水位和预测警示值
  SELECT MAX(NSW),MAX(NJYCYJZ) INTO NJQPSW,NJYCYJZ FROM DSE_BZ_RUNINFO_RULE
  WHERE STCD = :NEW.STCD;
  
  
  ISWARN := '0';
  WPTN   := '';
  CYCYJ  := null;
  
  IF YCXXTIME IS NULL THEN
    BEGIN
      INSERT INTO DSE_BZ_YCXX_B(STCD,TM,NSW,WSW,NJYCYJZ,WPTN,ISWARN,CYCYJ,NJQPSW)
      VALUES(:NEW.STCD,:NEW.TM,:NEW.NSW,:NEW.WSW,NJYCYJZ,WPTN,ISWARN,CYCYJ,NJQPSW);
    END;
  ELSIF YCXXTIME < :NEW.TM THEN
    BEGIN
      IF NJYCYJZ IS NOT NULL THEN
        BEGIN
          SELECT T.NSW INTO O_NJSW FROM DSE_BZ_YCXX_B T WHERE T.STCD = :NEW.STCD AND T.TM = YCXXTIME;
          IF :NEW.NSW > O_NJSW THEN
            BEGIN
              WPTN := '5';
              IF :NEW.NSW > NJYCYJZ THEN
                BEGIN
                  ISWARN := '1';
                  CYCYJ  := :NEW.NSW-NJYCYJZ;
                END;
              END IF;
            END;
          ELSIF :NEW.NSW < O_NJSW THEN
            BEGIN
              WPTN := '4';
              ISWARN := '0';
              CYCYJ  := :NEW.NSW-NJYCYJZ;
            END;
          ELSE
            BEGIN
              WPTN := '6';
              ISWARN := '0';
              CYCYJ  := :NEW.NSW-NJYCYJZ;
            END;
          END IF;
          INSERT INTO DSE_BZ_YCXX_B(STCD,TM,NSW,WSW,NJYCYJZ,WPTN,ISWARN,CYCYJ,NJQPSW)
          VALUES(:NEW.STCD,:NEW.TM,:NEW.NSW,:NEW.WSW,NJYCYJZ,WPTN,ISWARN,CYCYJ,NJQPSW);
        END;
      END IF;
    END;
  END IF;
  
  --liux  流量换算
  --获取叶片安放角度

  select count(t.angel) into vnm  FROM tb1501_meidscin_044 t WHERE T.ENNMCD = :NEW.STCD ;
  select count(t.waterpump_modal) into vnm2  FROM dse_bz_pumb t WHERE T.ENNMCD =:NEW.STCD AND T.aircrewnm =:NEW.aircrewnm;
  if vnm >0 and vnm2 >0 then
    begin
      SELECT nvl(trim(t.angel),9) INTO  ANGELVALUE  FROM tb1501_meidscin_044 t WHERE T.ENNMCD = :NEW.STCD ;
      --获取机组水泵型号
      SELECT nvl(TRIM(t.waterpump_modal),9) INTO MODALVALUE FROM dse_bz_pumb t WHERE T.ENNMCD =:NEW.STCD AND T.aircrewnm =:NEW.aircrewnm ;
      --计算扬程
      PVALUE:=:NEW.WSW - :NEW.NSW;
       IF ANGELVALUE != '9'  and MODALVALUE != '9'  and PVALUE is not null then
         begin
           select FUNC_PUMP_GET_Q_BY_PRAISE(MODALVALUE,ANGELVALUE,PVALUE) into QVALUE from dual;
        -- 改变当前流量值
           :NEW.INSTANTANEOUSQ := QVALUE;
         end;
      end if;   
    end;
  end if;
  
  --如果状态是0 则将瞬时流量置为0;
  IF :NEW.AIRCREWSTATE =0 THEN 
     QVALUE:=NULL;
     :NEW.INSTANTANEOUSQ := QVALUE;
  END IF;
 --liux
 
  IF TEMPTIME IS NULL THEN
    BEGIN
      INSERT INTO DSE_BZ_RUNINFO_REAL
        (STCD,
         TM,
         AIRCREWNM,
         PIPENM,
         VOLTAGEA,
         VOLTAGEB,
         VOLTAGEC,
         ECA,
         ECB,
         ECC,
         POWERACTIVE,
         POWERREACTIVE,
         EDACTIVE,
         EDREACTIVE,
         POWERFACTOR,
         UPBUSHING,
         DOWNBUSHING,
         POWERBUSHING,
         STATORTEMPERATURE,
         AIRCREWSTATE,
         INSTANTANEOUSQ,
         COUNTQ,
         FOREBAYZ,
         --  OPZ,
         NSW,
         WSW,
         DISTANCE)
      VALUES
        (:NEW.STCD,
         :NEW.TM,
         :NEW.AIRCREWNM,
         :NEW.PIPENM,
         :NEW.VOLTAGEA,
         :NEW.VOLTAGEB,
         :NEW.VOLTAGEC,
         :NEW.ECA,
         :NEW.ECB,
         :NEW.ECC,
         :NEW.POWERACTIVE,
         :NEW.POWERREACTIVE,
         :NEW.EDACTIVE,
         :NEW.EDREACTIVE,
         :NEW.POWERFACTOR,
         :NEW.UPBUSHING,
         :NEW.DOWNBUSHING,
         :NEW.POWERBUSHING,
         :NEW.STATORTEMPERATURE,
         :NEW.AIRCREWSTATE,
         -- :NEW.AIRCREWLR,
         --:NEW.INSTANTANEOUSQ,
         QVALUE,
         :NEW.COUNTQ,
         :NEW.FOREBAYZ,
         --:NEW.OPZ,
         :NEW.NSW,
         :NEW.WSW,
         :NEW.DISTANCE);
    END;
  ELSIF TEMPTIME <= :NEW.TM THEN
    BEGIN
      UPDATE DSE_BZ_RUNINFO_REAL
         SET TM                = :NEW.TM,
             VOLTAGEA          = :NEW.VOLTAGEA,
             VOLTAGEB          = :NEW.VOLTAGEB,
             VOLTAGEC          = :NEW.VOLTAGEC,
             ECA               = :NEW.ECA,
             ECB               = :NEW.ECB,
             ECC               = :NEW.ECC,
             POWERACTIVE       = :NEW.POWERACTIVE,
             POWERREACTIVE     = :NEW.POWERREACTIVE,
             EDACTIVE          = :NEW.EDACTIVE,
             EDREACTIVE        = :NEW.EDREACTIVE,
             POWERFACTOR       = :NEW.POWERFACTOR,
             UPBUSHING         = :NEW.UPBUSHING,
             DOWNBUSHING       = :NEW.DOWNBUSHING,
             POWERBUSHING      = :NEW.POWERBUSHING,
             STATORTEMPERATURE = :NEW.STATORTEMPERATURE,
             AIRCREWSTATE      = :NEW.AIRCREWSTATE,
            -- INSTANTANEOUSQ    = :NEW.INSTANTANEOUSQ,
            INSTANTANEOUSQ    = QVALUE,
             COUNTQ            = :NEW.COUNTQ,
             FOREBAYZ          = :NEW.FOREBAYZ,
             --  OPZ               = :NEW.OPZ,
             NSW      = :NEW.NSW,
             WSW      = :NEW.WSW,
             DISTANCE = :NEW.DISTANCE
       WHERE STCD = :NEW.STCD
         AND AIRCREWNM = :NEW.AIRCREWNM
         AND PIPENM = :NEW.PIPENM;
    END;
  END IF;

END TRIG_DSE_BZ_RUNINFO_R;


/

