create procedure      PLATFORM_BZ_JZYXXX(STCDS     VARCHAR,
                                               SAIRCREWNM VARCHAR,
                                               ST        VARCHAR,
                                               ET        VARCHAR,
                                               PAGEFROM  INT,
                                               PAGETO    INT,
                                               CURR      OUT PLATFORM.CURSOR) is
  VST DATE;
  VET DATE;
begin
  VST := TO_DATE(ST, 'YYYY-MM-DD HH24:MI:SS');
  VET := TO_DATE(ET, 'YYYY-MM-DD HH24:MI:SS');
  OPEN CURR FOR
    SELECT TT.*, TT.ROWNUM_
      FROM (SELECT TO_CHAR(T.TM, 'YYYY-MM-DD HH24:MI') TM,
                   CASE T.AIRCREWSTATE
                     WHEN '1' THEN
                      '开'
                     ELSE
                      '关'
                   END AIRCREWSTATE,
                   T.VOLTAGEA,
                   T.VOLTAGEB,
                   T.VOLTAGEC,
                   T.ECA,
                   T.ECB,
                   T.ECC,
                   T.POWERACTIVE,
                   T.EDACTIVE,
                   T.POWERFACTOR,
                   T.UPBUSHING,
                   T.DOWNBUSHING,
                   T.POWERBUSHING,
                   T.STATORTEMPERATURE,
                   T.NSW,
                   T.WSW,
                   ROWNUM ROWNUM_
              FROM DSE_BZ_RUNINFO_R T
             WHERE T.STCD = STCDS
               AND T.AIRCREWNM = SAIRCREWNM
               AND T.TM >= VST
               AND T.TM <= VET
             ORDER BY t.TM DESC) TT
     WHERE TT.ROWNUM_ > PAGEFROM
       AND TT.ROWNUM_ <= PAGETO;

end PLATFORM_BZ_JZYXXX;


/

