create PROCEDURE      PLATFORM_PPTN_INDICATOR(STCDS    VARCHAR,
                                                    PERIOD   INT,
                                                    PAGEFROM INT,
                                                    PAGETO   INT,
                                                    CURSOR1  OUT PLATFORM.CURSOR) IS
BEGIN
  OPEN CURSOR1 FOR
    SELECT *
      FROM (SELECT T1.STCD,
                   TRIM(T3.STNM) STNM,
                   TRIM(T3.STLC) STLC,
                   T1.STDT,
                   T2.STTHRESHOLD,
                   'PP' AS STINDEX,
                   ROW_NUMBER() OVER(ORDER BY T1.STCD, T1.STDT) AS RN
              FROM (SELECT * FROM TABLE(FUNC_PPTN_YJZB_TABLE)) T1
              LEFT JOIN DSE_WARN_RULE_B T2 ON T1.STCD = T2.STCD
                                          AND T1.STDT = T2.STDT,
             ST_STBPRP_B T3
             INNER JOIN (SELECT *
                          FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                          PLATFORM_STCD_TYPE))) T4 ON T4.STCD =
                                                                      T3.STCD
             WHERE T1.STCD = T3.STCD
               AND (PERIOD = 0 OR T1.STDT = PERIOD)

            ) TT
     WHERE TT.RN > PAGEFROM
       AND TT.RN <= PAGETO;

END PLATFORM_PPTN_INDICATOR;


/

