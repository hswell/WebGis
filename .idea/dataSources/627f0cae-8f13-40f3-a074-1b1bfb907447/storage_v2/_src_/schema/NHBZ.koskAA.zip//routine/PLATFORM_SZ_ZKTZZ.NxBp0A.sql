create procedure      PLATFORM_SZ_ZKTZZ(szcode    varchar,
                         bgtm     varchar,
                         entm     varchar,
                         zkname    varchar,
                         PAGEFROM INT,
                         PAGETO   INT,
                         cursor1  OUT PLATFORM.CURSOR) is
begin
  open cursor1 for
    select * from (
       select t1.ennm,t.ATID,t.ENDSTP,t.ENNMCD,t.EXQS,t.GTBDSTTP,t.GTMTEL,t.GTNB,t.GTORHG,t.GTORNB,t.GTORNM ,t.GTORSZ,
              t.GTTP,t.GTTPEL,t.HDGRNB,t.HDGRTP,t.MDDT,t.MDPS,t.PWSPCN,t.RMA,t.SDFL,t.STLFPW
             ,to_char(t.Infndt, 'yyyy-mm-dd') INFNDT,ROW_NUMBER() over(order by t.mddt) rn
       from TB0909_SLIGVL_044 t ,TB0001_PRNMSR_044 t1
       where  t.ennmcd=t1.ennmcd  and t1.ennm like '%'||szcode||'%'
              and t.INFNDT>=to_date(bgtm,'yyyy-mm-dd HH24:MI:SS')
              and t.INFNDT<=to_date(entm,'yyyy-mm-dd HH24:MI:SS')
              and t.GTORNM like '%'||zkname||'%'
     ) t1 where t1.rn>PAGEFROM and t1.rn<=PAGETO;

end PLATFORM_SZ_ZKTZZ;


/

