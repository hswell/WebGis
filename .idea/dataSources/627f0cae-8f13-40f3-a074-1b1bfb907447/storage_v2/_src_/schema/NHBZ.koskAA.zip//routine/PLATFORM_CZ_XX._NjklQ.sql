create PROCEDURE      PLATFORM_CZ_XX(ADDCODE  VARCHAR,
                                           CSNAME   VARCHAR,
                                           VSTTP VARCHAR,
                                           VAREACD VARCHAR,
                                           VCACD VARCHAR,
                                           PAGEFROM INT,
                                           PAGETO   INT,
                                           CURSOR1  OUT PLATFORM.CURSOR) IS
BEGIN
  OPEN CURSOR1 FOR
    SELECT *
      FROM (SELECT T.STCD,
                   TRIM(T.STNM) STNM,
                   TRIM(T.RVNM) RVNM,
                   TRIM(T.HNNM) HNNM,
                 --  TRIM(T.BSNM) BSNM,
                   T.CACD,
                   T.AREACD,
                   T.LGTD,
                   T.LTTD,
                   TRIM(T.STLC) STLC,
                   T.ADDVCD,
                   T.DTMNM,
                   T.DTMEL,
                   T.DTPR,
                   T.STTP,
                   T.FRGRD,
                   T.ESSTYM,
                   T.BGFRYM,
                   T.ATCUNIT,
                   T.ADMAUTH,
                   T.LOCALITY,
                   T.STBK,
                   T.STAZT,
                   T.DSTRVM,
                   T.DRNA,
                   T.PHCD,
                   T.USFL,
                   T.COMMENTS,
                   T.MODITIME,
                   T1.CODE,
                   TRIM(T1.NAME) ADDNAME,
                   ROW_NUMBER() OVER(ORDER BY STCD) RN
              FROM ST_STBPRP_B T
              LEFT JOIN SYS_DISTRICT T1 ON T.ADDVCD = T1.ADCODE
             WHERE (TRIM(ADDCODE) = '-1' OR T1.CODE LIKE  ADDCODE || '%')
               AND (TRIM(CSNAME) = '-1' OR T.STNM LIKE '%' || CSNAME || '%')
               AND (TRIM(VSTTP) = '-1' OR T.STTP =VSTTP )
               AND (TRIM(VAREACD) = '-1' OR T.AREACD = VAREACD)
               AND (TRIM(VCACD) = '-1' OR T.CACD = VCACD)) TT
     WHERE TT.RN > PAGEFROM
       AND TT.RN <= PAGETO;

END PLATFORM_CZ_XX;


/

