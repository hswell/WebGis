create procedure      PLATFORM_BZ_XTYXJS(STCDS    VARCHAR, --?????
                                               PAGEFROM INT, --???
                                               PAGETO   INT, --???
                                               CURR     OUT PLATFORM.CURSOR) is
  /**
  *AUTHOR:TICHSTAR
  *DESCRIPTION:????????????
  *DATE:2013?7?23?10:20:50
  */
begin
  OPEN CURR FOR
    SELECT TT.*
      FROM (SELECT T.STCD,
                   rtrim(B.STNM) STNM,
                   S.NAME,
                   V.UNNB,
                   T.JZSTATE,
                   T.NSW,
                   T.WSW,
                   T.TXSJ,
                   T.INSTANTANEOUSQ,
                   V.DSINCP*1000 DSINCP,
                   V.DSDRFL,
                   RE.SZSTCD,
                   FUNC_ZM_JZZT(RE.SZSTCD) ZMSTATE,
                   KKK.TM KTM,
                   GGG.TM GTM,
                   row_number() over (order by t.jzstate desc,t.stcd asc) ROWNUM_
              FROM (SELECT DISTINCT (D.STCD),
                                    D.NSW,
                                    D.WSW,
                                    ceil((sysdate-D.TM)*24*60)   TXSJ,
                                    SUM(D.INSTANTANEOUSQ) AS INSTANTANEOUSQ,
                                    FUNC_BZ_JZZT(D.STCD, NULL) JZSTATE
                      FROM DSE_BZ_RUNINFO_REAL D GROUP BY(D.STCD,D.NSW,D.WSW,D.TM)) T

             INNER JOIN (SELECT *
                          FROM TABLE(CAST(FUNC_SPLITSTRING('100000') AS
                                          PLATFORM_STCD_TYPE))) ST
                ON T.STCD = ST.STCD
             INNER JOIN ST_STBPRP_B B
                ON T.STCD = B.STCD
             INNER JOIN V_TB1502_MEIDSBI V
                ON T.STCD = V.STCD
             -- start 2013?10?25?16:10:53??????????
             LEFT JOIN DSE_BZSZ_REMARK RE
                ON T.STCD = RE.BZSTCD
             -- end

              LEFT JOIN SYS_DISTRICT S
                ON B.ADDVCD = S.ADCODE
              LEFT JOIN (SELECT K.STCD, TO_CHAR(K.TM,'YYYY-MM-DD HH24:MI:SS')TM
                          FROM (SELECT KK.STCD,
                                       KK.TM,
                                       ROW_NUMBER() OVER(PARTITION BY KK.STCD ORDER BY KK.TM DESC) RNUM
                                  FROM DSE_BZ_RUNSTATE_R KK
                                 WHERE KK.STATE = '1') K
                         WHERE K.RNUM = 1) KKK
                ON KKK.STCD = T.STCD
                LEFT JOIN (SELECT G.STCD, TO_CHAR(G.TM,'YYYY-MM-DD HH24:MI:SS')TM
                          FROM (SELECT GG.STCD,
                                       GG.TM,
                                       ROW_NUMBER() OVER(PARTITION BY GG.STCD ORDER BY GG.TM DESC) RNUM
                                  FROM DSE_BZ_RUNSTATE_R GG
                                 WHERE GG.STATE = '0') G
                         WHERE G.RNUM = 1) GGG
                ON GGG.STCD = T.STCD ) TT
     WHERE TT.ROWNUM_ > PAGEFROM
       AND TT.ROWNUM_ <= PAGETO;
end PLATFORM_BZ_XTYXJS;


/

