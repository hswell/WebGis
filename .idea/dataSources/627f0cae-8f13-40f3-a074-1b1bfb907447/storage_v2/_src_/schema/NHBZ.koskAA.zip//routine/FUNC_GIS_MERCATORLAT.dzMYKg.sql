create function      FUNC_GIS_MercatorLat(y NUMBER) return number is
  Result number;
  --createTime 2013-08-16
  --author chenya
  --墨卡托转纬度
  LV_Y number;
begin
  LV_Y   := y / 20037508.34 * 180;
  Result := 180 / ACOS(-1) *
            (2 * atan(exp(LV_Y * ACOS(-1) / 180)) - ACOS(-1) / 2);
  return(Result);
end FUNC_GIS_MercatorLat;


/

