create PROCEDURE      PLATFORM_RIVER_PMT(VSTCD VARCHAR,
                                               CURR1 OUT PLATFORM.CURSOR,
                                               CURR2 OUT PLATFORM.CURSOR) IS
BEGIN
  --返回河道的防洪指标及实时水位流量
  OPEN CURR1 FOR
    SELECT WRZ, GRZ, LAZ FROM ST_RVFCCH_B T WHERE STCD = VSTCD;

  OPEN CURR2 FOR
    SELECT TO_CHAR(TM, 'yyyy-mm-dd hh24:mi') TM,
           TRIM(TO_CHAR(ROUND(Z, 2), '99999999990.99')) Z,
           FUNC_NUMERIC(Q, 3) Q
      FROM DSE_ST_RIVER_REAL
     WHERE STCD = VSTCD;
END PLATFORM_RIVER_PMT;


/

