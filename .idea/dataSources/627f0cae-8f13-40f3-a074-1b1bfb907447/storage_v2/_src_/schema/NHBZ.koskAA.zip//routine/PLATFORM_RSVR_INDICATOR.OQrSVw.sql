create PROCEDURE      PLATFORM_RSVR_INDICATOR(STCDS    VARCHAR,
                                                    PAGEFROM INT,
                                                    PAGETO   INT,
                                                    CURR1    OUT PLATFORM.CURSOR) AS
  --水库防洪指标参数
BEGIN
  OPEN CURR1 FOR
    SELECT TT.*
      FROM (SELECT T2.STCD,
                   T2.STNM,
                   --T2.STLC,
                   DAMEL,
                   TRIM(TO_CHAR(ROUND(CKFLZ, 2), '99999999990.99')) CKFLZ,
                   TRIM(TO_CHAR(ROUND(DSFLZ, 2), '99999999990.99')) DSFLZ,
                   TRIM(TO_CHAR(ROUND(NORMZ, 2), '99999999990.99')) NORMZ,
                   TRIM(TO_CHAR(ROUND(DDZ, 2), '99999999990.99')) DDZ,
                   TRIM(TO_CHAR(ROUND(TTCP, 2), '99999999990.99')) TTCP,
                   TRIM(TO_CHAR(ROUND(HHRZ, 2), '99999999990.99')) HHRZ,
                   TRIM(TO_CHAR(ROUND(HLRZ, 2), '99999999990.99')) HLRZ,
                   TRIM(TO_CHAR(ROUND(LAZ, 2), '99999999990.99')) LAZ,
                   TRIM(TO_CHAR(ROUND(ACTCP, 2), '99999999990.99')) ACTCP,
                   ROW_NUMBER() OVER(ORDER BY T2.STCD) AS ROWNUM_
              FROM ST_STBPRP_B T2
             INNER JOIN (SELECT *
                          FROM TABLE(CAST(FUNC_SPLITSTRING(STCDS) AS
                                          PLATFORM_STCD_TYPE))) T4 ON T4.STCD =
                                                                      T2.STCD
              LEFT JOIN ST_RSVRFCCH_B T3 ON T2.STCD = T3.STCD
             WHERE T2.Sttp='RR' ) TT
     WHERE ROWNUM_ > PAGEFROM
       AND ROWNUM_ <= PAGETO
     ORDER BY TT.STCD;

END PLATFORM_RSVR_INDICATOR;


/

