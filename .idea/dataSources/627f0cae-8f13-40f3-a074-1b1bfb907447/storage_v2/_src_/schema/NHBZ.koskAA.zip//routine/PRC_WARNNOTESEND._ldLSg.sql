create PROCEDURE      PRC_WARNNOTESEND(vstwarnID   NUMBER,
                                             vstcd     varchar2,
                                             vyjtype     NUMBER,
                                             vsender     varchar2,
                                             vmsgcontent varchar2) is

  snum   int;
  vmsgid number(16);
begin
  if (vmsgcontent is not null) then
    select COUNT(1)
      into snum
      from MessageInfo_R r
     where r.WarnID = vstwarnID
       and r.MsgTypeID = vyjtype;
    if (snum > 0) then
      update MessageInfo_R
         set Msgcontent = vmsgcontent, Sender = vsender, SendTM = sysdate
       where WarnID = vstwarnID
         and MsgTypeID = vyjtype
         and MediaID = '10';
      select msgid
        into vmsgid
        from MessageInfo_R r
       where r.WarnID = vstwarnID
         and r.MsgTypeID = vyjtype
         and r.MediaID = '10';
    else
      vmsgid := DSE_DX_SEQUENCE.Nextval;
      insert into MessageInfo_R
        (msgid,
         MsgTypeID,
         WarnID,
         Msgcontent,
         Sender,
         MediaID,
         SendTM,
         Iszdy)
      values
        (vmsgid,
         vyjtype,
         vstwarnID,
         vmsgcontent,
         vsender,
         '10',
         sysdate,
         '0');
    end if;

    for lcur_per in (select distinct w.stcd,
                                     w.yjryid,
                                     d.deptnm,
                                     p.name,
                                     p.mblphn
                       from dse_warn_dept_b w,
                            dept_b          d,
                            person_b        p
                      where w.yjbmid = d.deptcd
                        and w.yjryid = p.personcd
                        and w.stcd = vstcd
                        and w.yjtype = vyjtype) loop
      insert into MessageSend_R
        (id,
         MsgID,
         ObjectCD,
         ObjectType,
         issend,
         mobile,
         Iszdy,
         Uname,
         Deptname)
      values
        (DSE_KEY_SEQUENCE.Nextval,
         vmsgid,
         lcur_per.yjryid,
         vyjtype,
         '0',
         lcur_per.mblphn,
         '0',
         lcur_per.name,
         lcur_per.deptnm);

    end loop;

  end if;

end prc_WarnNoteSend;


/

